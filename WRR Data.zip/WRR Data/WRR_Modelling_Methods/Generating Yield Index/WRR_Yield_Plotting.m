%% Paper Plotting & Yield Calculation

%% Guide to Script:
%1. Manual calibration example for Well 2
%2. Plotting parameter sets from automated calibration at Well 2
%3. Calculating dHp from calibrated set to use in Yield Calculations for
%Well 2
%4. Using literature-derived parameters in original AquiMod model for
%comparison (Well 2)
%5. WR (Well 1) - Plotting Calibrated Set & dHp Calculation
%6. WC (Well 3) Plotting of Calibration & dHp Calculation
%7. Yield Calculations and Plots

%Clear Workspace
clc
close all
clear all

L = 2; %linewidth
M = 6; %marker size
set(0, 'DefaultAxesFontSize', 16);

%linecolors (greys)
colA = [0 0 0];
colB = [0.5 0.5 0.5];
colC = [0.7 0.7 0.7];
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% 1. WB (Well 2) - Manual Calibration Example

%Set Aquifer Parameters
h0 = 3; %from manual; % Initial groundwater level above aquifer base prior to pumping [m]
Sy = 0.01; 
k = 9e-05; %(tau in manuscript)
k_wei = 20;
lambda = 18;
b = 0; %height of base of well above base of aquifer

%% Load Recharge + Observed Bottle Well Data - WB
% Rainfall area of roughly 40 x 40 km
% Evaporation area of roughly 55 x 55 km

%Add Necessary Folders to Path (NOTE: Directory updating on different computer) 
%path

% Load Rainfall Data for Recharge, Load Well Bottle Data for Pumping (from pressure transducer) 
load rainfall_endmay.mat 
load NPD_corr.mat 
% r is rainfall (from TAMSAT)
% ev is evaporation (from AFDM VIC hydrologic model)
% r and ev in [mm]
% Well level in [m]
ev_day = ev_day(~isnat(ev_day)); % Removing NaT

% Calculating average rainfall and evaporation
P = mean(r,1);
P = mean(P,2);
P = P(:); % Mean for 1 day
P = P/1000; % convert rainfall to [m]

AE = mean(ev,1);
AE = mean(AE,2);
AE = AE(:); % Mean for 1 day
AE = AE/1000; % convert evap to [m]

% Extracting only peaks of well level
[WBpk.depth,i] = findpeaks(WB.depth);
WBpk.date = WB.date(i);
[WBpk.depth,i] = findpeaks(WBpk.depth);
WBpk.date = WBpk.date(i);

% Extracting relevant rainfall data to match well data range
P = P(r_day>WB.date(1));
r_day = r_day(r_day>WB.date(1));

P = P(r_day<=ev_day(end));

r_day = r_day(r_day<=ev_day(end));

% Extracting relevant evap
AE = AE(ev_day>WB.date(1));
ev_day = ev_day(ev_day>WB.date(1));

% AE = AE(ev_day<WB_pr_date_corr(end));
% ev_day = ev_day(ev_day<WB_pr_date_corr(end));

%% Load Pumping Data saved from genpump.m file 
load abs_nn1.mat

%Allocate Relevant Pumping Data to Variables to use in Model
stdate = abs.stdate;
enddate = abs.enddate;
pumpdate = abs.startdate;
pumprate = abs.pumprate;
pumpdur = abs.pumpdur;
startdata = abs.startdata;
enddata = abs.enddata;

WBstartdata = startdata; %For fig 6
WBenddata = enddata;


%% Regional AquiMod Model WB (Well 2)
params=input_params(Sy,h0,k,lambda,k_wei);
[Hg,recharge,qg] = gwm(P,AE,r_day,params);

%Plot regional model with calibrated values
figure(1)
grid on
plot(r_day,Hg)
xlabel('Time [days]')
ylabel('Head [m]')
hold on

%plot observed data for WB
B = 0; %height of pump above aquifer base 
plot(WB.date,WB.depth+B,'b.', 'LineWidth', 2, 'MarkerSize', 2);
hold on

%% Calculate avg difference in head between daily Hg and each pumping peak (dHp for calibration)
day = 1;
count = 1;
count2 = 1; 

%modify startdata to height above aquifer base
startdata = startdata + B;

%loop
for x = 1:length(pumpdate)
    
    if floor(datenum(pumpdate(count)))-(day-1) == floor(datenum(stdate)); %if the date is the same
        
        if day >= 1 && day <= floor(datenum(pumpdate(end)))
        dH(day, count2) = Hg(day) - startdata(count);
        H(day,count2) = startdata(count) %allocates the start data to days as rows
        count2 = count2 + 1;
        end
        count = count + 1;
    
    else %new day
        day = day + floor(datenum(pumpdate(count)))-floor(datenum(pumpdate(count-1))); %days advance the number of days its been since last pump peak
        count2 = 1; %reset count2 to 1
        
        if day >= 1 && day <= floor(datenum(pumpdate(end))) %currently includes all days but could be modified for shorter calibration window
        dH(day, count2) = Hg(day) - startdata(count);
        H(day,count2) = startdata(count) %allocates the start data to days as rows
        count2 = count2 + 1;
        end
        count = count + 1;
    end
    
end

%retain only startdata that are used to calculate head difference
H(dH==0) = NaN;

dH(dH==0) = NaN; %convert zeros to NaN

%also only take the minimum distance for each day
for x = 1:size(dH,1) %number of rows
    dH(x,1) = min(dH(x,:));
    H(x,1) = max(H(x,:)); %retains maximum starthead for each day
end

%cut other numbers out leaving 1st column
dH = dH(:,1);
H=H(:,1);

%calculate the average distance between observations and the regional model
%from gwm.m
dHmean = mean(dH,'omitnan'); %This is the dHp value used in automated calibration

%% plot calibration points with manual cal
r_day_plot = r_day(1:length(H));
caltarg = H + dHmean;
leg2 = plot(r_day_plot, caltarg, '.r')
hold on

%% 2. Plotting parameter sets from automated calibration at Well 2 (Figure 2)

top10 = [0.00928387130382249,9.64078208352426e-05,3.22782798515805,18.3365134701248;0.00948605217901783,9.61223127146807e-05,3.64037367200399,17.8532046475544;0.00927394881614942,9.67608431367860e-05,3.29106982034781,17.0869445492285;0.00914007593019153,9.66801577831544e-05,4.00462165816681,18.4983198330565;0.00907897178370590,9.69622286814286e-05,3.27321307623195,17.5415753955612;0.00942705773682682,9.61674725264506e-05,3.98380142496285,17.4285169207436;0.00920949801685674,9.69041038645278e-05,3.76135764404236,17.2315782500056;0.00954264989886184,9.61570109381180e-05,3.63772897787349,17.5488007547367;0.00887378373882321,9.72503527629193e-05,3.47521707377714,18.4382199857893;0.00943035686762665,9.66245227683171e-05,3.22921985904826,16.8299636288679];

SyList = top10(:,1);
kList = top10(:,2);
k_weiList = top10(:,3);
lambdaList = top10(:,4);

figure(2)
grid on
leg1 = plot(WB.date,WB.depth+B,'b.', 'LineWidth', 2, 'MarkerSize', 2); 
ylabel('Head [m]')
hold on


%% Plot leg3
for i = 2:length(SyList)+1
    %Plot regional model with calibrated values
    
    if i == length(SyList)+1 %to plot top calibration at the end for visibility
        
        Sy = SyList(1);
        k = kList(1);
        k_wei = k_weiList(1);
        lambda = lambdaList(1);
        
        params=input_params(Sy,h0,k,lambda,k_wei);
        [Hg,recharge,qg] = gwm(P,AE,r_day,params);
        
        figure(2)
        leg3 = plot(r_day,Hg,'-k','linewidth',L)
        hold on
        
        %STORE WB INFO FOR FIG 5
        WB_r_day = r_day;
        WB_Hg = Hg;
    else
        
        Sy = SyList(i);
        k = kList(i);
        k_wei = k_weiList(i);
        lambda = lambdaList(i);
        
        params=input_params(Sy,h0,k,lambda,k_wei);
        [Hg,recharge,qg] = gwm(P,AE,r_day,params);
        figure(2)
        plot(r_day,Hg,'linewidth',L,'Color',[0.85 0.85 0.85])
        hold on
    end
    
end

%% 3. Calculation of dHp for Yield Calculations (WB)
%Calculating an updated value for dHp based on January - March dry season,
%using best parameter set from automated calibration, to use in yield
%calculations and plots (see Supplementary Material for explanation)

Sy = SyList(1);
k = kList(1);
k_wei = k_weiList(1);
lambda = lambdaList(1);

params=input_params(Sy,h0,k,lambda,k_wei);
[Hg,recharge,qg] = gwm(P,AE,r_day,params);

day = 1; %count of days
count = 1; %count through startdata
count2 = 1; %count through position in dH for each day

%modify startdata to height above aquifer base
startdata = startdata; %no need to add B - already done for manual cal
enddata = enddata + B;

%loop
for x = 1:length(pumpdate)
    
    if floor(datenum(pumpdate(count)))-(day-1) == floor(datenum(stdate)); %if the date is the same
        
        if day >= 1 && day <= floor(datenum(pumpdate(end)))
        dHpeaks(day, count2) = Hg(day) - startdata(count);
        %dHtroughs(day,count2) = Hg(day) - enddata(count);
        count2 = count2 + 1;
        end
        count = count + 1;
    
    else %new day
        day = day + floor(datenum(pumpdate(count)))-floor(datenum(pumpdate(count-1))); %days advance the number of days its been since last pump peak
        count2 = 1; %reset count2 to 1
        
        if day >= 1 && day <= floor(datenum(pumpdate(end))) %currently includes all days but could be modified for shorter calibration window
        dHpeaks(day, count2) = Hg(day) - startdata(count);
        %dHtroughs(day,count2) = Hg(day) - enddata(count);
        count2 = count2 + 1;
        end
        count = count + 1;
    end
    
end

%calculate the average distance between observations and the regional model
%from gwm.m
%dH = dH(:,
%only include peaks that are at the top of the recovery
%dH(dH>0.4) = 0; %save unused values as zero for calibration post
%processing - NOT used for WC
dHpeaks(dHpeaks==0) = NaN; %convert zeros to NaN

%also only take the minimum distance for each day for peaks
for x = 1:size(dHpeaks,1) %number of rows
    dHpeaks(x,1) = min(dHpeaks(x,:));
end

% %and take max distance for troughs
% for x = 1:size(dHtroughs,1) %number of rows
%     dHtroughs(x,1) = max(dHtroughs(x,:));
% end

%cut other numbers out leaving 1st column
dHpeaks = dHpeaks(:,1);
% dHtroughs = dHtroughs(:,1);

%FOR WC - cut out the first 18 days of observed data for fitting (rain not
%recorded in meteorological data so manual calibration has ignored).
% dH = dH(18:end);
dHpeaks = dHpeaks(165:end); %JUST MEASURING IN JAN-FEB 2018

dHpeakmeanWB = mean(dHpeaks,'omitnan')
% dHtroughmaxWB = max(dHtroughs)
dHtroughmaxWB = max((startdata-enddata));

%% 4. Using literature-derived parameters in original AquiMod model for comparison
h0 = 3; %from manual; % Initial groundwater level above aquifer base prior to pumping [m]
Sy = 0.1; %lowest suggested level by Lohmann 
K = 25 ; %k is replaced by hydraulic conductivity K in original model as it uses length and width of aquifer!
k_wei = 3.5;
lambda = 3.5;
b = 0; %height of base of well above base of aquifer

%plot uncalibrated (researched parameter values) AquiMod model
params=input_params_OG(Sy,h0,K,lambda,k_wei);
[Hg,recharge,qg] = gwm_OG(P,AE,r_day,params);

%Plot regional model with calibrated values
figure(2)
grid on
leg4 = plot(r_day,Hg, '--', 'LineWidth', L)

%% Plot Calibration Target (leg2)
leg2 = plot(r_day_plot, caltarg, '.r','MarkerSize', M)
hold on

legend([leg1 leg2 leg3 leg4],{'Observed Groundwater Level', 'Calibration Points', 'Calibrated AquiMod Model','Uncalibrated AquiMod Model'}, 'FontSize', 16)
ylim([0 9]);

%% 5. WR (Well 1) - Plotting Calibrated Set 
%manual calibration is in its own manual cal file

%% Load Rainfall Data - WR
load rainfall_endmay.mat 
load NPD_corr.mat 
% r is rainfall (from TAMSAT)
% ev is evaporation (from AFDM VIC hydrologic model)
% r and ev in [mm]
% Well level in [m]
ev_day = ev_day(~isnat(ev_day)); % Removing NaT

% Calculating average rainfall and evaporation
P = mean(r,1);
P = mean(P,2);
P = P(:); % Mean for 1 day
P = P/1000; % convert rainfall to [m]

AE = mean(ev,1);
AE = mean(AE,2);
AE = AE(:); % Mean for 1 day
AE = AE/1000; % convert evap to [m]

% Extracting only peaks of well level
[WRpk.depth,i] = findpeaks(WR.depth);
WRpk.date = WR.date(i);
[WRpk.depth,i] = findpeaks(WRpk.depth);
WRpk.date = WRpk.date(i);

% Extracting relevant rainfall data to match well data range
P = P(r_day>WR.date(1));
r_day = r_day(r_day>WR.date(1));

P = P(r_day<=ev_day(end));

r_day = r_day(r_day<=ev_day(end));

% Extracting relevant evap
AE = AE(ev_day>WR.date(1));
ev_day = ev_day(ev_day>WR.date(1));

% AE = AE(ev_day<WB_pr_date_corr(end));
% ev_day = ev_day(ev_day<WB_pr_date_corr(end));

%% Load Pumping Data saved from genpump.m file 
%(which originally inputted to geninput1.m for SPIDERR model):
load abs_nn1WR.mat

%Allocate Relevant Pumping Data to Variables to use in Model
stdate = abs.stdate;
enddate = abs.enddate;
pumpdate = abs.startdate;
pumprate = abs.pumprate;
pumpdur = abs.pumpdur;
startdata = abs.startdata;
enddata = abs.enddata;

B = 0;

WRstartdata = startdata; %For fig 6
WRenddata = enddata;


%% PLOTTING - FIGURE 3

%load parameters
top10 = [0.0782621157681867,0.000761632767480204,4.98968952976277,19.2435163604261;0.0773613983015019,0.000759699780420353,3.93808990229348,21.5841634533905;0.0776056909080641,0.000760618578753960,4.29154319639961,20.6448644772879;0.0708213679033230,0.000736585739215261,3.91876537389717,21.6319193459281;0.0825069226042322,0.000775472050339522,3.73407820010035,18.3830374399845;0.0736680005384997,0.000747803952041616,4.96838882347967,21.2352129954467;0.0699665091852476,0.000732336258331342,4.75197254625297,20.3180950185843;0.0702007489108297,0.000732688598737443,4.50167204984012,20.2661749414456;0.0772768856988408,0.000757435986552276,12.0708849812945,19.1584050183270;0.0791761797741086,0.000764060551641140,11.8514068888320,17.9246716778124];

h0 = 1.35;

SyList = top10(:,1);
kList = top10(:,2);
k_weiList = top10(:,3);
lambdaList = top10(:,4);

figure(3)
grid on
leg1 = plot(WR.date,WR.depth+B,'b.', 'LineWidth', L, 'MarkerSize', 2); 
hold on

for i = 2:length(SyList)+1
    %Plot regional model with calibrated values
    
    if i == length(SyList)+1 %to plot top calibration at the end for visibility
        
        Sy = SyList(1);
        k = kList(1);
        k_wei = k_weiList(1);
        lambda = lambdaList(1);
        
        params=input_params(Sy,h0,k,lambda,k_wei);
        [Hg,recharge,qg] = gwm(P,AE,r_day,params);
        
        figure(3)
        leg2 = plot(r_day,Hg,'-k', 'LineWidth', L)
        hold on
        
        WR_r_day = r_day;
        WR_Hg = Hg;
    else
        
        Sy = SyList(i);
        k = kList(i);
        k_wei = k_weiList(i);
        lambda = lambdaList(i);
        
        params=input_params(Sy,h0,k,lambda,k_wei);
        [Hg,recharge,qg] = gwm(P,AE,r_day,params);
        figure(3)
        plot(r_day,Hg,'linewidth',L,'Color',[0.85 0.85 0.85])
        hold on
    end
    
end

%% Calculation of dHp for Yield (WR)
%FOR FIGURE 6 in AquiMod_3_Wells_2021_Plotting.m - CALCULATE Avg. Dist from Peaks-Hg and Troughs-Hg
Sy = SyList(1);
k = kList(1);
k_wei = k_weiList(1);
lambda = lambdaList(1);

params=input_params(Sy,h0,k,lambda,k_wei);
[Hg,recharge,qg] = gwm(P,AE,r_day,params);

day = 1; %count of days
count = 1; %count through startdata
count2 = 1; %count through position in dH for each day

%modify startdata to height above aquifer base
startdata = startdata + B;
enddata = enddata + B;

%loop
for x = 1:length(pumpdate)
    
    if floor(datenum(pumpdate(count)))-(day-1) == floor(datenum(stdate)); %if the date is the same
        
        if day >= 1 && day <= floor(datenum(pumpdate(end)))
        dHpeaks(day, count2) = Hg(day) - startdata(count);
%         dHtroughs(day,count2) = Hg(day) - enddata(count);
        count2 = count2 + 1;
        end
        count = count + 1;
    
    else %new day
        day = day + floor(datenum(pumpdate(count)))-floor(datenum(pumpdate(count-1))); %days advance the number of days its been since last pump peak
        count2 = 1; %reset count2 to 1
        
        if day >= 1 && day <= floor(datenum(pumpdate(end))) %currently includes all days but could be modified for shorter calibration window
        dHpeaks(day, count2) = Hg(day) - startdata(count);
%         dHtroughs(day,count2) = Hg(day) - enddata(count);
        count2 = count2 + 1;
        end
        count = count + 1;
    end
    
end

%calculate the average distance between observations and the regional model
%from gwm.m

%only include peaks that are at the top of the recovery
dHpeaks(dHpeaks>0.4) = 0; %save unused values as zero for calibration post
%processing - NOT used for WC
dHpeaks(dHpeaks==0) = NaN; %convert zeros to NaN

%also only take the minimum distance for each day for peaks
for x = 1:size(dHpeaks,1) %number of rows
    dHpeaks(x,1) = min(dHpeaks(x,:));
end

% %and take max distance for troughs
% for x = 1:size(dHtroughs,1) %number of rows
%     dHtroughs(x,1) = max(dHtroughs(x,:));
% end

%cut other numbers out leaving 1st column
dHpeaks = dHpeaks(:,1);
% dHtroughs = dHtroughs(:,1);
dHpeaks = dHpeaks(165:end); %JUST MEASURING IN JAN-FEB 2018
%FOR WC - cut out the first 18 days of observed data for fitting (rain not
%recorded in meteorological data so manual calibration has ignored).
% dH = dH(18:end);

dHpeakmeanWR = mean(dHpeaks,'omitnan'); %mean because this is theoretical likely daily available water level
% dHtroughmaxWR = max(dHtroughs); %max because this is the theoretical optimum
dHtroughmaxWR = max((startdata-enddata));
%% FIGURE 3 - Plot against uncalibrated AquiMod
%% Reset Aquifer Parameters to plot uncalibrated AquiMod
h0 = 1.35; %from manual; % Initial groundwater level above aquifer base prior to pumping [m]
Sy = 0.1; %lowest suggested level by Lohmann 
K = 25; %k is replaced by hydraulic conductivity K in original model as it uses length and width of aquifer!
k_wei = 3.5;
lambda = 3.5;
b = 0; %height of base of well above base of aquifer

%plot uncalibrated (researched parameter values) AquiMod model
params=input_params_OG(Sy,h0,K,lambda,k_wei);
[Hg,recharge,qg] = gwm_OG(P,AE,r_day,params);

%Plot regional model with calibrated values
figure(3)
grid on
leg3 = plot(r_day,Hg, '--', 'LineWidth', L)
ylabel('Head [m]')
%plot calibration points loaded from manual cal file
load('WR_dH.mat', 'dH', 'H', 'caltarg', 'r_day_plot_WR')
leg15 = plot(r_day_plot_WR, caltarg, '.r','MarkerSize', M)

legend([leg1 leg15 leg2 leg3],{'Observed Groundwater Level', 'Calibration Points', 'Calibrated AquiMod Model','Uncalibrated AquiMod Model'}, 'FontSize', 16)


%% 6. WC (Well 3) Plotting of Calibration & Yield Calculation

%% Load Rainfall Data - WC
load rainfall_endmay.mat 
load NPD_corr.mat 
% r is rainfall (from TAMSAT)
% ev is evaporation (from AFDM VIC hydrologic model)
% r and ev in [mm]
% Well level in [m]
ev_day = ev_day(~isnat(ev_day)); % Removing NaT

% Calculating average rainfall and evaporation
P = mean(r,1);
P = mean(P,2);
P = P(:); % Mean for 1 day
P = P/1000; % convert rainfall to [m]

AE = mean(ev,1);
AE = mean(AE,2);
AE = AE(:); % Mean for 1 day
AE = AE/1000; % convert evap to [m]

% Extracting only peaks of well level
[WCpk.depth,i] = findpeaks(WC.depth);
WCpk.date = WC.date(i);
[WCpk.depth,i] = findpeaks(WCpk.depth);
WCpk.date = WCpk.date(i);

% Extracting relevant rainfall data to match well data range
P = P(r_day>WC.date(1));
r_day = r_day(r_day>WC.date(1));

P = P(r_day<=ev_day(end));

r_day = r_day(r_day<=ev_day(end));

% Extracting relevant evap
AE = AE(ev_day>WC.date(1));
ev_day = ev_day(ev_day>WC.date(1));

% AE = AE(ev_day<WB_pr_date_corr(end));
% ev_day = ev_day(ev_day<WB_pr_date_corr(end));

%% Load Pumping Data saved from genpump.m file 
%(which originally inputted to geninput1.m for SPIDERR model):
load abs_nn1WC.mat

%Allocate Relevant Pumping Data to Variables to use in Model
stdate = abs.stdate;
enddate = abs.enddate;
pumpdate = abs.startdate;
pumprate = abs.pumprate;
pumpdur = abs.pumpdur;
startdata = abs.startdata;
enddata = abs.enddata;

WCstartdata = startdata; %For fig 6
WCenddata = enddata;


B = -1; %DIFFERENT!

%% PLOTTING - FIGURE 3

%load parameters
top10 = [0.0376931949965332,0.000249536573120808,3.81803978188160,12.5542357850392;0.0370260034900043,0.000249193573141525,4.78526675176236,12.5529218242766;0.0360754678371656,0.000248576372335842,3.31914449447999,13.9752914120326;0.0354586535960876,0.000247516737156958,6.56602052912988,13.8909307474014;0.0365769572623101,0.000248359404434551,9.54732053656588,12.8029147968480;0.0353989774881556,0.000247350465149638,4.94086136845015,14.6724625323314;0.0355552690980044,0.000248286341323685,7.45577711663607,12.7970398966790;0.0375337594413243,0.000249152156323307,4.99228413462164,13.4917281514628;0.0354293702032119,0.000247919241378804,8.31959917485537,13.6407807993107;0.0366774992342645,0.000248303790362060,10.1093053029678,13.5967260208647];

h0 = 2.05;

SyList = top10(:,1);
kList = top10(:,2);
k_weiList = top10(:,3);
lambdaList = top10(:,4);

figure(4)
grid on
leg1 = plot(WC.date,WC.depth+B,'b.', 'LineWidth', L, 'MarkerSize', 2); 
xlabel('Time [days]')
ylabel('Head [m]')
hold on

for i = 2:length(SyList)+1
    %Plot regional model with calibrated values
    
    if i == length(SyList)+1 %to plot top calibration at the end for visibility
        
        Sy = SyList(1);
        k = kList(1);
        k_wei = k_weiList(1);
        lambda = lambdaList(1);
        
        params=input_params(Sy,h0,k,lambda,k_wei);
        [Hg,recharge,qg] = gwm(P,AE,r_day,params);
        
        figure(4)
        leg2 = plot(r_day,Hg,'-k', 'LineWidth', L)
        hold on
        
        WC_r_day = r_day;
        WC_Hg = Hg;
    else
        
        Sy = SyList(i);
        k = kList(i);
        k_wei = k_weiList(i);
        lambda = lambdaList(i);
        
        params=input_params(Sy,h0,k,lambda,k_wei);
        [Hg,recharge,qg] = gwm(P,AE,r_day,params);
        figure(4)
        plot(r_day,Hg,'linewidth',L,'Color',[0.85 0.85 0.85])
        hold on
    end
    
end

%% Calculation for Yield (WC)
%FOR FIGURE 6 in AquiMod_3_Wells_2021_Plotting.m - CALCULATE Avg. Dist from Peaks-Hg and Troughs-Hg
Sy = SyList(1);
k = kList(1);
k_wei = k_weiList(1);
lambda = lambdaList(1);

params=input_params(Sy,h0,k,lambda,k_wei);
[Hg,recharge,qg] = gwm(P,AE,r_day,params);

day = 1; %count of days
count = 1; %count through startdata
count2 = 1; %count through position in dH for each day

%modify startdata to height above aquifer base
startdata = startdata + B;
enddata = enddata + B;

%loop
for x = 1:length(pumpdate)
    
    if floor(datenum(pumpdate(count)))-(day-1) == floor(datenum(stdate)); %if the date is the same
        
        if day >= 1 && day <= floor(datenum(pumpdate(end)))
        dHpeaks(day, count2) = Hg(day) - startdata(count);
%         dHtroughs(day,count2) = Hg(day) - enddata(count);
        count2 = count2 + 1;
        end
        count = count + 1;
    
    else %new day
        day = day + floor(datenum(pumpdate(count)))-floor(datenum(pumpdate(count-1))); %days advance the number of days its been since last pump peak
        count2 = 1; %reset count2 to 1
        
        if day >= 1 && day <= floor(datenum(pumpdate(end))) %currently includes all days but could be modified for shorter calibration window
        dHpeaks(day, count2) = Hg(day) - startdata(count);
%         dHtroughs(day,count2) = Hg(day) - enddata(count);
        count2 = count2 + 1;
        end
        count = count + 1;
    end
    
end

%calculate the average distance between observations and the regional model
%from gwm.m
%dH = dH(:,
%only include peaks that are at the top of the recovery
%dH(dH>0.4) = 0; %save unused values as zero for calibration post
%processing - NOT used for WC
dHpeaks(dHpeaks==0) = NaN; %convert zeros to NaN

%also only take the minimum distance for each day for peaks
for x = 1:size(dHpeaks,1) %number of rows
    dHpeaks(x,1) = min(dHpeaks(x,:));
end

% %and take max distance for troughs
% for x = 1:size(dHtroughs,1) %number of rows
%     dHtroughs(x,1) = max(dHtroughs(x,:));
% end

%cut other numbers out leaving 1st column
dHpeaks = dHpeaks(:,1);
% dHtroughs = dHtroughs(:,1);

%FOR WC - cut out the first 18 days of observed data for fitting (rain not
%recorded in meteorological data so manual calibration has ignored).
dHpeaks = dHpeaks(165:end);

dHpeakmeanWC = mean(dHpeaks,'omitnan')

% dHtroughmaxWC = max(dHtroughs)

dHtroughmaxWC = max((startdata-enddata));

%% Reset Aquifer Parameters to plot uncalibrated AquiMod
h0 = 2.1; %from manual; % Initial groundwater level above aquifer base prior to pumping [m]
Sy = 0.1; %lowest suggested level by Lohmann 
K = 25; %k is replaced by hydraulic conductivity K in original model as it uses length and width of aquifer!
k_wei = 3.5;
lambda = 3.5;
b = 0; %height of base of well above base of aquifer

%plot uncalibrated (researched parameter values) AquiMod model
params=input_params_OG(Sy,h0,K,lambda,k_wei);
[Hg,recharge,qg] = gwm_OG(P,AE,r_day,params);

%Plot regional model with calibrated values
figure(4)
grid on
leg3 = plot(r_day,Hg, '--', 'LineWidth', L)


%plot calibration points loaded from manual cal file
load('WC_dH.mat', 'dH', 'H', 'caltarg', 'r_day_plot_WC')
leg15 = plot(r_day_plot_WC, caltarg, '.r','MarkerSize', M)



legend([leg1 leg15 leg2 leg3],{'Observed Groundwater Level', 'Calibration Points', 'Calibrated AquiMod Model','Uncalibrated AquiMod Model'}, 'FontSize', 16)



%% 7. Conversion and plots of yield
%% FIGURE 5
%plot of 3 calibrated models against time as a percentage of max min level

%Normalise
%WB
WB_norm = ((WB_Hg-0)./(max(WB_Hg)-0)).*100; %using max head because actual well depth is not known accurately

%WR
WR_norm = ((WR_Hg-0)./(max(WR_Hg)-0)).*100;

%WB
WC_norm = ((WC_Hg-0)./(max(WC_Hg)-0)).*100;

figure(5)
%Plot regional model with calibrated values
grid on
leg1=plot(WR_r_day,WR_norm, 'LineWidth', L)
xlabel('Time [days]')
ylabel('Water Table Level [%]')
hold on
leg2=plot(WB_r_day,WB_norm, 'LineWidth', L)
leg3=plot(WC_r_day,WC_norm, 'LineWidth', L)
legend([leg1 leg2 leg3],{'Well 1', 'Well 2','Well 3'})


%% FIGURE 6 - Do this again but with colour change according to yield index

%WR
B=0;
WRlev0 = dHpeakmeanWR+B; %dHp (+ any height if pump not at well base) = height at which yield = 0%
WRlevlow = WRlev0+dHtroughmaxWR; %dHp + dHddmax (elevation above which yield will be 100%)

aboveline = (WR_Hg>=WRlevlow);
bottomline = (WR_Hg>=WRlev0);

WR_Hg_mid = WR_Hg;
WR_Hg_top = WR_Hg;
WR_Hg_bot = WR_Hg;

WR_Hg_mid(aboveline) = NaN;
WR_Hg_mid(~bottomline)= NaN;
WR_Hg_bot(bottomline) = NaN;
WR_Hg_top(~aboveline) = NaN;

%normalise
WR_Hg_mid = ((WR_Hg_mid-0)./(max(WR_Hg)-0)).*100;
WR_Hg_bot = ((WR_Hg_bot-0)./(max(WR_Hg)-0)).*100;
WR_Hg_top = ((WR_Hg_top-0)./(max(WR_Hg)-0)).*100;

figure(6)
leg1=plot(WR_r_day,WR_Hg_mid,'-','linewidth',L,'color', [1,0.5,0]) 
hold on
plot(WR_r_day,WR_Hg_top,'-','linewidth',L,'color', [0.2,1,0.2]);
plot(WR_r_day,WR_Hg_bot,'-r','linewidth',L);


%WB
B = 0;
WBlev0 = dHpeakmeanWB+B; %dHp (+ any height if pump not at well base) = height at which yield = 0%
WBlevlow = WBlev0+dHtroughmaxWB; %dHp + dHddmax (elevation above which yield will be 100%)

aboveline = (WB_Hg>=WBlevlow);
bottomline = (WB_Hg>=WBlev0);

WB_Hg_mid = WB_Hg;
WB_Hg_top = WB_Hg;
WB_Hg_bot = WB_Hg;

WB_Hg_mid(aboveline) = NaN;
WB_Hg_mid(~bottomline)= NaN;
WB_Hg_bot(bottomline) = NaN;
WB_Hg_top(~aboveline) = NaN;

%normalise
WB_Hg_mid = ((WB_Hg_mid-0)./(max(WB_Hg)-0)).*100;
WB_Hg_bot = ((WB_Hg_bot-0)./(max(WB_Hg)-0)).*100;
WB_Hg_top = ((WB_Hg_top-0)./(max(WB_Hg)-0)).*100;

figure(6)
leg2=plot(WB_r_day,WB_Hg_mid,'--','linewidth',L,'color', [1,0.5,0]) 
hold on
plot(WB_r_day,WB_Hg_top,'--','linewidth',L,'color', [0.2,1,0.2]);
plot(WB_r_day,WB_Hg_bot,'--r','linewidth',L);

%WC
B=0;
WClev0 = dHpeakmeanWC+B; %dHp (+ any height if pump not at well base) = height at which yield = 0%
WClevlow = WClev0+dHtroughmaxWC; %dHp + dHddmax (elevation above which yield will be 100%)

aboveline = (WC_Hg>=WClevlow);
bottomline = (WC_Hg>=WClev0);

WC_Hg_mid = WC_Hg;
WC_Hg_top = WC_Hg;
WC_Hg_bot = WC_Hg;

WC_Hg_mid(aboveline) = NaN;
WC_Hg_mid(~bottomline)= NaN;
WC_Hg_bot(bottomline) = NaN;
WC_Hg_top(~aboveline) = NaN;

%normalise
WC_Hg_mid = ((WC_Hg_mid-0)./(max(WC_Hg)-0)).*100;
WC_Hg_bot = ((WC_Hg_bot-0)./(max(WC_Hg)-0)).*100;
WC_Hg_top = ((WC_Hg_top-0)./(max(WC_Hg)-0)).*100;

figure(6)
leg3= plot(WC_r_day,WC_Hg_mid,'-.','linewidth',L,'color', [1,0.5,0]) 
hold on
plot(WC_r_day,WC_Hg_top,'-.','linewidth',L,'color', [0.2,1,0.2]);
plot(WC_r_day,WC_Hg_bot,'-.r','linewidth',L);
grid on
xlabel('Time [days]')
ylabel('Water Table Level [%]')
legend([leg1 leg2 leg3],{'Well 1', 'Well 2','Well 3'})


%% FIGURE 7 - Adapt to a continuous colour scheme of % of max yield.

%WR
B = 0;
WRlev0 = dHpeakmeanWR+B; %dHp (+ any height if pump not at well base) = height at which yield = 0%
WRlevlow = WRlev0+dHtroughmaxWR; %dHp + dHddmax (elevation above which yield will be 100%)

z_WR = 100*ones(1,length(WR_Hg));

for i = 1:length(z_WR)
    if WR_Hg(i) < WRlevlow
        z_WR(i) = 100*(WR_Hg(i)-WRlev0)/(WRlevlow-WRlev0); %(100 being full pumping capacity, 0 being fully out of pumping vol) of yield as % of max yield
        if z_WR(i)<0 %occurs in the case where head is below the WBlev0
            z_WR(i)=0;
        end
    end
end


%WB
B = 0;
WBlev0 = dHpeakmeanWB+B; %dHp (+ any height if pump not at well base) = height at which yield = 0%
WBlevlow = WBlev0+dHtroughmaxWB; %dHp + dHddmax (elevation above which yield will be 100%)

z_WB = 100*ones(1,length(WB_Hg));

for i = 1:length(z_WB)
    if WB_Hg(i) < WBlevlow
        z_WB(i) = 100*(WB_Hg(i)-WBlev0)/(WBlevlow-WBlev0); %gives percentage (100 being full pumping capacity, 0 being fully out of pumping vol) of yield as % of max yield
        if z_WB(i)<0 %occurs in the case where head is below the WBlev0
            z_WB(i)=0;
        end
    end
end

%WC
B = 0; %this is for regional model. obs data needs to be -1
WClev0 = dHpeakmeanWC+B; %dHp (+ any height if pump not at well base) = height at which yield = 0%
WClevlow = WClev0+dHtroughmaxWC; %dHp + dHddmax (elevation above which yield will be 100%)

z_WC = 100*ones(1,length(WC_Hg));

for i = 1:length(z_WC)
    if WC_Hg(i) < WClevlow
        z_WC(i) = 100*(WC_Hg(i)-WClev0)/(WClevlow-WClev0); %(100 being full pumping capacity, 0 being fully out of pumping vol) of yield as % of max yield
        if z_WC(i)<0 %occurs in the case where head is below the WBlev0
            z_WC(i)=0;
        end
    end
end


figure(7)

%WR
xmat = [WR_r_day';WR_r_day'];
ymat = [WR_Hg';WR_Hg'];
z = zeros(size(xmat));
% p = plot(WB_r_day,WB_Hg,'r','LineWidth',3);
color = [z_WR;z_WR];
leg1 = surf(xmat,ymat,z,color,'EdgeColor','interp','LineStyle','-','LineWidth', L);
colormap jet
c=colorbar;
c.Label.String = 'Available Abstraction Yield (%)';
view(2) %//view(0,90)
grid on
hold on

%WB
xmat = [WB_r_day';WB_r_day'];
ymat = [WB_Hg';WB_Hg'];
z = zeros(size(xmat));
% p = plot(WB_r_day,WB_Hg,'r','LineWidth',3);
color = [z_WB;z_WB];
leg2 = surf(xmat,ymat,z,color,'EdgeColor','interp','LineStyle','--','LineWidth', L);
colormap jet
c=colorbar;
c.Label.String = 'Available Abstraction Yield (%';
view(2) %//view(0,90)
grid on

%WC
xmat = [WC_r_day';WC_r_day'];
ymat = [WC_Hg';WC_Hg'];
z = zeros(size(xmat));
% p = plot(WB_r_day,WB_Hg,'r','LineWidth',3);
color = [z_WC;z_WC];
leg3 = surf(xmat,ymat,z,color,'EdgeColor','interp','LineStyle','-.','LineWidth', L);
colormap jet
c=colorbar;
c.Label.String = 'Available Abstraction Yield (%)';
view(2) %//view(0,90)
grid on

legend([leg1 leg2 leg3],{'Well 1', 'Well 2','Well 3'})


%% FIGURE 8 - Normalised Version of Figure 7
%Normalise
%WB
WB_norm = ((WB_Hg-0)./(max(WB_Hg)-0)).*100; %using max head because actual well depth is not known

%WR
WR_norm = ((WR_Hg-0)./(max(WR_Hg)-0)).*100;

%WB
WC_norm = ((WC_Hg-0)./(max(WC_Hg)-0)).*100;

%WR
B = 0;
WRlev0 = dHpeakmeanWR+B; 
WRlevlow = WRlev0+dHtroughmaxWR;

z_WR = 100*ones(1,length(WR_Hg));

for i = 1:length(z_WR)
    if WR_Hg(i) < WRlevlow
        z_WR(i) = 100*(WR_Hg(i)-WRlev0)/(WRlevlow-WRlev0); 
        if z_WR(i)<0 %occurs in the case where head is below the WBlev0
            z_WR(i)=0;
        end
    end
end


%WB
B = 0;
WBlev0 = dHpeakmeanWB+B; 
WBlevlow = WBlev0+dHtroughmaxWB;

z_WB = 100*ones(1,length(WB_Hg));

for i = 1:length(z_WB)
    if WB_Hg(i) < WBlevlow
        z_WB(i) = 100*(WB_Hg(i)-WBlev0)/(WBlevlow-WBlev0); %gives decimal 
        if z_WB(i)<0 %occurs in the case where head is below the WBlev0
            z_WB(i)=0;
        end
    end
end

%WC
B = 0;
WClev0 = dHpeakmeanWC+B; 
WClevlow = WClev0+dHtroughmaxWC;

z_WC = 100*ones(1,length(WC_Hg));

for i = 1:length(z_WC)
    if WC_Hg(i) < WClevlow
        z_WC(i) = 100*(WC_Hg(i)-WClev0)/(WClevlow-WClev0); 
        if z_WC(i)<0 %occurs in the case where head is below the WBlev0
            z_WC(i)=0;
        end
    end
end


figure(8)

%WR
xmat = [WR_r_day';WR_r_day'];
ymat = [WR_norm';WR_norm'];
z = zeros(size(xmat));
% p = plot(WB_r_day,WB_Hg,'r','LineWidth',3);
color = [z_WR;z_WR];
leg1 = surf(xmat,ymat,z,color,'EdgeColor','interp','LineStyle','-','LineWidth', L, 'FaceColor', [1,1,1]);
colormap default
c=colorbar;
c.Limits = [0 100];
c.Label.String = 'Available Abstraction Yield (%)';
view(2) %//view(0,90)
grid on
hold on

%WB
xmat = [WB_r_day';WB_r_day'];
ymat = [WB_norm';WB_norm'];
z = zeros(size(xmat));
% p = plot(WB_r_day,WB_Hg,'r','LineWidth',3);
color = [z_WB;z_WB];
leg2 = surf(xmat,ymat,z,color,'EdgeColor','interp','LineStyle','--','LineWidth', L, 'FaceColor', [1,1,1]);
colormap default
c=colorbar;
c.Limits = [0 100];
c.Label.String = 'Available Abstraction Yield (%)';
view(2) %//view(0,90)
grid on

%WC
xmat = [WC_r_day';WC_r_day'];
ymat = [WC_norm';WC_norm'];
z = zeros(size(xmat));
% p = plot(WB_r_day,WB_Hg,'r','LineWidth',3);
color = [z_WC;z_WC];
leg3 = surf(xmat,ymat,z,color,'EdgeColor','interp','LineStyle',':','LineWidth', L, 'FaceColor', [1,1,1]);
colormap default
c=colorbar;
c.Limits = [0 100];
c.Label.String = 'Available Abstraction Yield (%)';
view(2) %//view(0,90)
grid on

%legend([leg1 leg2 leg3],{'Well 1', 'Well 2','Well 3'})
ylabel('Water Table Elevation in Well (%)')
%xlabel('Date')





%% Figure 9 - 2015/20 Data - Plotting 3 regional models with color bar
% Load Rainfall Data for Recharge, Load Well Bottle Data for Pumping (from pressure transducer) 
load rainfall_2015_20.mat 
load NPD_corr.mat 

% r is rainfall (from TAMSAT)
% ev is evaporation (from AFDM VIC hydrologic model)
% r and ev in [mm]
% Well level in [m]
 
ev_day = ev_day(~isnat(ev_day)); % Removing NaT

% Calculating average rainfall and evaporation
P = mean(r,1);
P = mean(P,2);
P = P(:); % Mean for 1 day
P = P/1000; % convert rainfall to [m]

AE = mean(ev,1);
AE = mean(AE,2);
AE = AE(:); % Mean for 1 day
AE = AE/1000; % convert evap to [m]

% Extracting relevant rainfall data to match well data range
P = P(r_day>=ev_day(1));
r_day = r_day(r_day>=ev_day(1));

P = P(r_day<=ev_day(end));

r_day = r_day(r_day<=ev_day(end));

P=P'; r_day = r_day';

%Add missing rainfall data for 6th May - 10th May 2018
r_day_add = [datetime(2018,05,06):datetime(2018,05,10)];
P_add = zeros(1, length(r_day_add));

add_pos = 1222;

P = [P(1:add_pos-1),P_add,P(add_pos:end)];
r_day = [r_day(1:add_pos-1),r_day_add,r_day(add_pos:end)];

P=P'; r_day = r_day';

%WR calibrated data
%load parameters
top10 = [0.0782621157681867,0.000761632767480204,4.98968952976277,19.2435163604261;0.0773613983015019,0.000759699780420353,3.93808990229348,21.5841634533905;0.0776056909080641,0.000760618578753960,4.29154319639961,20.6448644772879;0.0708213679033230,0.000736585739215261,3.91876537389717,21.6319193459281;0.0825069226042322,0.000775472050339522,3.73407820010035,18.3830374399845;0.0736680005384997,0.000747803952041616,4.96838882347967,21.2352129954467;0.0699665091852476,0.000732336258331342,4.75197254625297,20.3180950185843;0.0702007489108297,0.000732688598737443,4.50167204984012,20.2661749414456;0.0772768856988408,0.000757435986552276,12.0708849812945,19.1584050183270;0.0791761797741086,0.000764060551641140,11.8514068888320,17.9246716778124];

h0 = 1; %0.844 - %CALIBRATED VALUE?? ON JAN 1st 2018 (but SPI from drought monitor is higher for 2015 Jan than 2018 so round up to 3).

SyList = top10(:,1);
kList = top10(:,2);
k_weiList = top10(:,3);
lambdaList = top10(:,4);

Sy = SyList(1);
k = kList(1);
k_wei = k_weiList(1);
lambda = lambdaList(1);

%Generate Groundwater Model for WR for 2015-20
params=input_params(Sy,h0,k,lambda,k_wei);
[Hg,recharge,qg] = gwm(P,AE,r_day,params);

WR_Hg_201520 = Hg;

figure(100)
plot(r_day,Hg, 'LineWidth', L)
title('Regional Model Performance 2015-20')
xlabel('Time [days]')
ylabel('Head [m]')
hold on 

%WB calibrated data
top10 = [0.00928387130382249,9.64078208352426e-05,3.22782798515805,18.3365134701248;0.00948605217901783,9.61223127146807e-05,3.64037367200399,17.8532046475544;0.00927394881614942,9.67608431367860e-05,3.29106982034781,17.0869445492285;0.00914007593019153,9.66801577831544e-05,4.00462165816681,18.4983198330565;0.00907897178370590,9.69622286814286e-05,3.27321307623195,17.5415753955612;0.00942705773682682,9.61674725264506e-05,3.98380142496285,17.4285169207436;0.00920949801685674,9.69041038645278e-05,3.76135764404236,17.2315782500056;0.00954264989886184,9.61570109381180e-05,3.63772897787349,17.5488007547367;0.00887378373882321,9.72503527629193e-05,3.47521707377714,18.4382199857893;0.00943035686762665,9.66245227683171e-05,3.22921985904826,16.8299636288679];

SyList = top10(:,1);
kList = top10(:,2);
k_weiList = top10(:,3);
lambdaList = top10(:,4);

%top performing set - WB
h0 = 5; %selected due to comparible SPI-6 from Princeton Drought monitor in 2017-18 data period
Sy = SyList(1);
k = kList(1);
k_wei = k_weiList(1);
lambda = lambdaList(1);

%Generate Groundwater Model for WB for 2015-20
params=input_params(Sy,h0,k,lambda,k_wei);
[Hg,recharge,qg] = gwm(P,AE,r_day,params);

WB_Hg_201520 = Hg;

figure(100)
plot(r_day,Hg, 'LineWidth', L)
title('Regional Model Performance 2015-20')
xlabel('Time [days]')
ylabel('Head [m]')
hold on 

%WC calibrated data

%load parameters
top10 = [0.0376931949965332,0.000249536573120808,3.81803978188160,12.5542357850392;0.0370260034900043,0.000249193573141525,4.78526675176236,12.5529218242766;0.0360754678371656,0.000248576372335842,3.31914449447999,13.9752914120326;0.0354586535960876,0.000247516737156958,6.56602052912988,13.8909307474014;0.0365769572623101,0.000248359404434551,9.54732053656588,12.8029147968480;0.0353989774881556,0.000247350465149638,4.94086136845015,14.6724625323314;0.0355552690980044,0.000248286341323685,7.45577711663607,12.7970398966790;0.0375337594413243,0.000249152156323307,4.99228413462164,13.4917281514628;0.0354293702032119,0.000247919241378804,8.31959917485537,13.6407807993107;0.0366774992342645,0.000248303790362060,10.1093053029678,13.5967260208647];

h0 = 1.834;%??? % 3.834; %Regional value on Jan 1st 2018 calibrated but round up because SPI is higher 

SyList = top10(:,1);
kList = top10(:,2);
k_weiList = top10(:,3);
lambdaList = top10(:,4);

Sy = SyList(1);
k = kList(1);
k_wei = k_weiList(1);
lambda = lambdaList(1);

%Generate Groundwater Model for WB for 2015-20
params=input_params(Sy,h0,k,lambda,k_wei);
[Hg,recharge,qg] = gwm(P,AE,r_day,params);

WC_Hg_201520 = Hg;

figure(100)
plot(r_day,Hg, 'LineWidth', L)
title('Regional Model Performance 2015-20')
xlabel('Time [days]')
ylabel('Head [m]')
legend('Well 1', 'Well 2', 'Well 3')

%% FIGURE 9 - using normalised method from Figure 8
%Normalise
%WB
WB_norm201520 = ((WB_Hg_201520-0)./(max(WB_Hg_201520)-0)).*100; %using max head because actual well depth is not known (damn)

%WR
WR_norm201520 = ((WR_Hg_201520-0)./(max(WR_Hg_201520)-0)).*100;

%WB
WC_norm201520 = ((WC_Hg_201520-0)./(max(WC_Hg_201520)-0)).*100;

%WR
B = 0;
WRlev0 = dHpeakmeanWR+B; 
WRlevlow = WRlev0+dHtroughmaxWR;

z_WR = 100*ones(1,length(WR_Hg_201520));

for i = 1:length(z_WR)
    if WR_Hg_201520(i) < WRlevlow
        z_WR(i) = 100*(WR_Hg_201520(i)-WRlev0)/(WRlevlow-WRlev0); 
        if z_WR(i)<0 %occurs in the case where head is below the WBlev0
            z_WR(i)=0;
        end
    end
end


%WB
B = 0;
WBlev0 = dHpeakmeanWB+B; 
WBlevlow = WBlev0+dHtroughmaxWB;

z_WB = 100*ones(1,length(WB_Hg_201520));

for i = 1:length(z_WB)
    if WB_Hg_201520(i) < WBlevlow
        z_WB(i) = 100*(WB_Hg_201520(i)-WBlev0)/(WBlevlow-WBlev0); 
        if z_WB(i)<0 %occurs in the case where head is below the WBlev0
            z_WB(i)=0;
        end
    end
end

%WC
B = 0;
WClev0 = dHpeakmeanWC+B; 
WClevlow = WClev0+dHtroughmaxWC;

z_WC = 100*ones(1,length(WC_Hg_201520));

for i = 1:length(z_WC)
    if WC_Hg_201520(i) < WClevlow
        z_WC(i) = 100*(WC_Hg_201520(i)-WClev0)/(WClevlow-WClev0); 
        if z_WC(i)<0 %occurs in the case where head is below the WBlev0
            z_WC(i)=0;
        end
    end
end


figure(9)

%WR
xmat = [r_day';r_day'];
ymat = [WR_norm201520';WR_norm201520'];
z = zeros(size(xmat));
% p = plot(WB_r_day,WB_Hg,'r','LineWidth',3);
color = [z_WR;z_WR];
leg1 = surf(xmat,ymat,z,color,'EdgeColor','interp','LineStyle','-','LineWidth', L, 'FaceColor', [1,1,1]);
colormap default
c=colorbar('FontSize', 12);
c.Limits = [0 100];
c.Label.String = 'Available Abstraction Yield (%)';
view(2) %//view(0,90)
grid on
hold on

%WB
xmat = [r_day';r_day'];
ymat = [WB_norm201520';WB_norm201520'];
z = zeros(size(xmat));
% p = plot(WB_r_day,WB_Hg,'r','LineWidth',3);
color = [z_WB;z_WB];
leg2 = surf(xmat,ymat,z,color,'EdgeColor','interp','LineStyle','--','LineWidth', L, 'FaceColor', [1,1,1]);
colormap default
c=colorbar('FontSize', 12);
c.Limits = [0 100];
c.Label.String = 'Available Abstraction Yield (%)';
view(2) %//view(0,90)
grid on

%WC
xmat = [r_day';r_day'];
ymat = [WC_norm201520';WC_norm201520'];
z = zeros(size(xmat));
% p = plot(WB_r_day,WB_Hg,'r','LineWidth',3);
color = [z_WC;z_WC];
leg3 = surf(xmat,ymat,z,color,'EdgeColor','interp','LineStyle',':','LineWidth', L, 'FaceColor', [1,1,1]);
colormap default
c=colorbar('FontSize', 12);
c.Limits = [0 100];
c.Label.String = 'Available Abstraction Yield (%)';
view(2) %//view(0,90)
grid on

%legend([leg1 leg2 leg3],{'Well 1', 'Well 2','Well 3'})
set(gca, 'YGrid', 'off', 'XGrid', 'on')
ylim([0 100])
ylabel('Water Table Elevation in Well (%)')

% %%export with transparent background using export_fig toolbox
% addpath('C:\Users\wv13\Desktop\Project Code\github_repo');
% 
% set(gca, 'Color', 'none'); % Sets axes background 
% saveas(gcf, 'test.png');
% export_fig test2.png -m2.5 -transparent

%% Figure 12 - Converting Figure 9 to simple yield plot
figure(12)

ax=axes;
hold all

leg3 = plot(r_day,z_WC,'Color',colA, 'LineWidth', L, 'LineStyle', '-');
leg2 = plot(r_day,z_WB,'Color',colB, 'LineWidth', L, 'LineStyle', '--');
leg1 = plot(r_day,z_WR, 'Color',colC, 'LineWidth', L, 'LineStyle', '-.');
hold on

set(gca, 'YGrid', 'off', 'XGrid', 'on')
ylim([0 119])
ylabel('Available Abstraction Yield (%)')

myLines = get(ax,'Children');
% Change the order the data is plotted.
set(ax,'Children',myLines([3 2 1]));

legend([leg1 leg2 leg3],{'Well 1', 'Well 2','Well 3'})

set(ax,'Children',myLines([1 2 3]));



% %% Add SPI-6 to Figure 9 - REALLY TOUGH IN A 2D SURF. Imposed manually instead - Figure 11
% figure(11)
% load spi_2015_20.mat 
% spi6 = mean(spi6,1);
% spi6 = mean(spi6,2);
% spi6 = spi6(:);
% 
% set(gca,'ycolor','w') 
% yyaxis right
% plot(r_day,spi6, '-k', 'LineWidth', 0.25)
% ylabel('SPI-6')
% ylim([-4 4])
% hold on
% set(gca,'ycolor','k') 

% %% Figure 10 - Plotting Consensus Forecasts Data by making rain (25%, 50%, 75%, 100%)
% %x-axis time
% %y-axis yield!
% 
% %This will take GHACOF-44 and GHACOF-45 expectations of below normal
% %conditions to project a 10%, 25%, 50%, 100% of climatic mean scenarios
% %alongside the regional model using the actual TAMSAT records
% 
% %WB calibrated data
% top10 = [0.00928387130382249,9.64078208352426e-05,3.22782798515805,18.3365134701248;0.00948605217901783,9.61223127146807e-05,3.64037367200399,17.8532046475544;0.00927394881614942,9.67608431367860e-05,3.29106982034781,17.0869445492285;0.00914007593019153,9.66801577831544e-05,4.00462165816681,18.4983198330565;0.00907897178370590,9.69622286814286e-05,3.27321307623195,17.5415753955612;0.00942705773682682,9.61674725264506e-05,3.98380142496285,17.4285169207436;0.00920949801685674,9.69041038645278e-05,3.76135764404236,17.2315782500056;0.00954264989886184,9.61570109381180e-05,3.63772897787349,17.5488007547367;0.00887378373882321,9.72503527629193e-05,3.47521707377714,18.4382199857893;0.00943035686762665,9.66245227683171e-05,3.22921985904826,16.8299636288679];
% 
% SyList = top10(:,1);
% kList = top10(:,2);
% k_weiList = top10(:,3);
% lambdaList = top10(:,4);
% 
% %top performing set - WB
% h0 = 5; %selected due to comparible SPI-6 from Princeton Drought monitor in 2017-18 data period
% Sy = SyList(1);
% k = kList(1);
% k_wei = k_weiList(1);
% lambda = lambdaList(1);
% 
% figure(10)
% params=input_params(Sy,h0,k,k_wei,lambda);
% [Hg,r,qg] = gwm(P,AE,r_day,params);
% 
% %Convert to yield
% %WB
% B = 0;
% WBlev0 = dHpeakmeanWB+B; %avg distance from peaks to reg model + 2 (gives the level at which water would run out)
% WBlevlow = WBlev0+dHtroughmaxWB;
% 
% z_WB = 100*ones(1,length(Hg));
% 
% for i = 1:length(z_WB)
%     if Hg(i) < WBlevlow
%         z_WB(i) = 100*(Hg(i)-WBlev0)/(WBlevlow-WBlev0); %gives decimal (0 being full pumping capacity, 1 being fully out of pumping vol) of yield as % of max yield
%         if z_WB(i)<0 %occurs in the case where head is below the WBlev0
%             z_WB(i)=0;
%         end
%     end
% end
% 
% hist_z_WB = z_WB;
% 
% 
% 
% hold on
% plot(r_day,hist_z_WB,'--k','linewidth',1)
% %Plot on to Fig 10
% 
% %MAKE RAINFALL ARRAY FROM 1961-1990 CLIMATIC MEAN DATA 
% 
% %Monthly Volume (Jan - Dec) [mm]
% Pm = [2,11,27,88,65,34,40,55,63,31,7,1]; %From SWALIM 1963-1990 report
% Pm = Pm./1000; %convert to mm
% %Avg no. of >1 mm rain days
% Pd = [1,1,1,2,3,4,2,4,4,2,1,1]; %from German data (1944-1960) ORIGINAL HAS BEEN HALVED: [1,1,2,4,6,8,5,9,8,3,1,1];
% 
% Pm75 = Pm.*(3/4); % 75% %NOTE NUMBER MISLEADING - 75% more useful plot
% Pm25 = Pm./4; % 25%
% Pm50 = Pm./2; % 50%
% 
% %when clipping P, remember that 2016 is leap year with 366 days. Let's do
% %1st Aug 2016 (start of Deyr) through to 1st June 2017 (end of Gu)
% FstJan2015 = datenum(2015,1,01);
% FstAug2016 = datenum(2016,8,01);
% FstJun2017 = datenum(2017,6,01);
% LstDec2017 = datenum(2017,12,31);
% 
% %Program the rainfall regime for each day
% rr_day = r_day(1:LstDec2017-FstJan2015); %Clip R_day 2015-2017
% Hg = Hg(1:length(rr_day)); %delete all extra values from regional model
% P1 = P(1:length(rr_day)); 
% 
% %Now clip R_day_for to 2015-1st Jun 2017
% R_day_for = rr_day(1:FstJun2017-FstJan2015);
% 
% P10_for = P1(1:FstAug2016-FstJan2015);
% Z = zeros(FstJun2017-FstAug2016,1);
% P10_for = vertcat(P10_for,Z);
% 
% P25_for = P1(1:FstAug2016-FstJan2015);
% P25_for = vertcat(P25_for,Z);
% 
% P50_for = P1(1:FstAug2016-FstJan2015);
% P50_for = vertcat(P50_for,Z);
% 
% P100_for = P1(1:FstAug2016-FstJan2015);
% P100_for = vertcat(P100_for,Z);
% 
% month_lengths = [31,28,31,30,31,30,31,31,30,31,30,31];
% 
% % %Monthly Volume (Jan - Dec) [mm]
% % Pm = [2,11,27,88,65,34,40,55,63,31,7,1]; %From SWALIM 1963-1990 report
% % Pm = Pm./1000; %convert to mm
% % %Avg no. of >1 mm rain days
% % Pd = [1,1,2,4,6,8,5,9,8,3,1,1]; %from German data (1944-1960)
% 
% %Create a loop that fills out daily rainfall for each forecast (simple
% %currently) 
% clear day
% 
% for i = (FstAug2016-FstJan2015):(FstJun2017-1-FstJan2015)
%     I = datetime(i, 'ConvertFrom', 'datenum');
%     if month(I) == 1
%         if day(I) == 15
%             P10_for(i) = Pm75(month(I))/Pd(month(I));
%             P25_for(i) = Pm25(month(I))/Pd(month(I));
%             P50_for(i) = Pm50(month(I))/Pd(month(I));
%             P100_for(i) = Pm(month(I))/Pd(month(I));
%         else
%             P10_for(i) = 0;
%             P25_for(i) = 0;
%             P50_for(i) = 0;
%             P100_for(i) = 0;
%         end
%         
%     elseif month(I) == 2
%         if day(I) == 15
%             P10_for(i) = Pm75(month(I))/Pd(month(I));
%             P25_for(i) = Pm25(month(I))/Pd(month(I));
%             P50_for(i) = Pm50(month(I))/Pd(month(I));
%             P100_for(i) = Pm(month(I))/Pd(month(I));
%         else
%             P10_for(i) = 0;
%             P25_for(i) = 0;
%             P50_for(i) = 0;
%             P100_for(i) = 0;
%         end
%     
%      elseif month(I) == 3
%         if day(I) == 15
%             P10_for(i) = Pm75(month(I))/Pd(month(I));
%             P25_for(i) = Pm25(month(I))/Pd(month(I));
%             P50_for(i) = Pm50(month(I))/Pd(month(I));
%             P100_for(i) = Pm(month(I))/Pd(month(I));
%         else
%             P10_for(i) = 0;
%             P25_for(i) = 0;
%             P50_for(i) = 0;
%             P100_for(i) = 0;
%         end  
%         
%      elseif month(I) == 4
%         if day(I) == 10 || day(I) == 20 
%             P10_for(i) = Pm75(month(I))/Pd(month(I));
%             P25_for(i) = Pm25(month(I))/Pd(month(I));
%             P50_for(i) = Pm50(month(I))/Pd(month(I));
%             P100_for(i) = Pm(month(I))/Pd(month(I));
%         else
%             P10_for(i) = 0;
%             P25_for(i) = 0;
%             P50_for(i) = 0;
%             P100_for(i) = 0;
%         end
%         
%      elseif month(I) == 5
%         if day(I) == 10 || day(I) == 20 || day(I) == 5
%             P10_for(i) = Pm75(month(I))/Pd(month(I));
%             P25_for(i) = Pm25(month(I))/Pd(month(I));
%             P50_for(i) = Pm50(month(I))/Pd(month(I));
%             P100_for(i) = Pm(month(I))/Pd(month(I));
%         else
%             P10_for(i) = 0;
%             P25_for(i) = 0;
%             P50_for(i) = 0;
%             P100_for(i) = 0;
%         end
%         
%      elseif month(I) == 6
%         if day(I) == 10 || day(I) == 20 || day(I) == 5 || day(I) == 15 
%             P10_for(i) = Pm75(month(I))/Pd(month(I));
%             P25_for(i) = Pm25(month(I))/Pd(month(I));
%             P50_for(i) = Pm50(month(I))/Pd(month(I));
%             P100_for(i) = Pm(month(I))/Pd(month(I));
%         else
%             P10_for(i) = 0;
%             P25_for(i) = 0;
%             P50_for(i) = 0;
%             P100_for(i) = 0;
%         end
%         
%      elseif month(I) == 7
%         if day(I) == 10 || day(I) == 20 
%             P10_for(i) = Pm75(month(I))/Pd(month(I));
%             P25_for(i) = Pm25(month(I))/Pd(month(I));
%             P50_for(i) = Pm50(month(I))/Pd(month(I));
%             P100_for(i) = Pm(month(I))/Pd(month(I));
%         else
%             P10_for(i) = 0;
%             P25_for(i) = 0;
%             P50_for(i) = 0;
%             P100_for(i) = 0;
%         end
%         
%      elseif month(I) == 8
%         if day(I) == 10 || day(I) == 20 || day(I) == 5 || day(I) == 15 
%             P10_for(i) = Pm75(month(I))/Pd(month(I));
%             P25_for(i) = Pm25(month(I))/Pd(month(I));
%             P50_for(i) = Pm50(month(I))/Pd(month(I));
%             P100_for(i) = Pm(month(I))/Pd(month(I));
%         else
%             P10_for(i) = 0;
%             P25_for(i) = 0;
%             P50_for(i) = 0;
%             P100_for(i) = 0;
%         end
%         
%      elseif month(I) == 9
%         if day(I) == 10 || day(I) == 20 || day(I) == 5 || day(I) == 15 
%             P10_for(i) = Pm75(month(I))/Pd(month(I));
%             P25_for(i) = Pm25(month(I))/Pd(month(I));
%             P50_for(i) = Pm50(month(I))/Pd(month(I));
%             P100_for(i) = Pm(month(I))/Pd(month(I));
%         else
%             P10_for(i) = 0;
%             P25_for(i) = 0;
%             P50_for(i) = 0;
%             P100_for(i) = 0;
%         end
%         
%      elseif month(I) == 10
%         if day(I) == 10 || day(I) == 20
%             P10_for(i) = Pm75(month(I))/Pd(month(I));
%             P25_for(i) = Pm25(month(I))/Pd(month(I));
%             P50_for(i) = Pm50(month(I))/Pd(month(I));
%             P100_for(i) = Pm(month(I))/Pd(month(I));
%         else
%             P10_for(i) = 0;
%             P25_for(i) = 0;
%             P50_for(i) = 0;
%             P100_for(i) = 0;
%         end
%         
%      elseif month(I) == 11
%         if day(I) == 15
%             P10_for(i) = Pm75(month(I))/Pd(month(I));
%             P25_for(i) = Pm25(month(I))/Pd(month(I));
%             P50_for(i) = Pm50(month(I))/Pd(month(I));
%             P100_for(i) = Pm(month(I))/Pd(month(I));
%         else
%             P10_for(i) = 0;
%             P25_for(i) = 0;
%             P50_for(i) = 0;
%             P100_for(i) = 0;
%         end
%       
%      elseif month(I) == 12
%         if day(I) == 15
%             P10_for(i) = Pm75(month(I))/Pd(month(I));
%             P25_for(i) = Pm25(month(I))/Pd(month(I));
%             P50_for(i) = Pm50(month(I))/Pd(month(I));
%             P100_for(i) = Pm(month(I))/Pd(month(I));
%         else
%             P10_for(i) = 0;
%             P25_for(i) = 0;
%             P50_for(i) = 0;
%             P100_for(i) = 0;
%         end
% 
%     end
%     
%     %This version alone would smooth the rainfall across the whole month at
%     %a constant rate (incorrect method):
% %     P10_for(i) = Pm10(month(datetime(i,'ConvertFrom','datenum')))/month_lengths(month(datetime(i,'ConvertFrom','datenum'))); %do average rain spread first for simplicity then modify (leap year effect negligible)
% %     P25_for(i) = Pm25(month(datetime(i,'ConvertFrom','datenum')))/month_lengths(month(datetime(i,'ConvertFrom','datenum')));
% %     P50_for(i) = Pm50(month(datetime(i,'ConvertFrom','datenum')))/month_lengths(month(datetime(i,'ConvertFrom','datenum')));
% %     P100_for(i) = Pm(month(datetime(i,'ConvertFrom','datenum')))/month_lengths(month(datetime(i,'ConvertFrom','datenum')));
% 
% end
% 
% %Clip AE to right length
% AE_for = AE(1:FstJun2017-FstJan2015)
% 
% %Update h0 to equal value of Hg in regional model on FstAug2016
% h0_for = Hg(FstAug2016-FstJan2015);
% 
% %Make Regional Model for the 4 scenarios:
% %Pm100
% params=input_params(Sy,h0_for,k,k_wei,lambda);
% [Hg,r,qg] = gwm(P100_for,AE_for,R_day_for,params);
% 
% Hg100 = Hg;
% recharge100 =r;
% qg100 = qg;
% 
% %Convert to yield
% %WB
% B = 0;
% WBlev0 = dHpeakmeanWB+B; %avg distance from peaks to reg model + 2 (gives the level at which water would run out)
% WBlevlow = WBlev0+dHtroughmaxWB;
% 
% z_WB = 100*ones(1,length(Hg));
% 
% for i = 1:length(z_WB)
%     if Hg(i) < WBlevlow
%         z_WB(i) = 100*(Hg(i)-WBlev0)/(WBlevlow-WBlev0); %gives decimal (0 being full pumping capacity, 1 being fully out of pumping vol) of yield as % of max yield
%         if z_WB(i)<0 %occurs in the case where head is below the WBlev0
%             z_WB(i)=0;
%         end
%     end
% end
% 
% z_WB_100 = z_WB;
% 
% % %Modify to chop off the top bits
% % for x = 1:length(Hg100)
% %     if Hg100(x) > Th
% %         recharge(x) = 0;
% %         qg(x) = k*(Th-params.Hg_min);
% %         Hg100(x) = Th;
% %     end
% % end
% 
% %Pm75
% params=input_params(Sy,h0_for,k,k_wei,lambda);
% [Hg,r,qg] = gwm(P10_for,AE_for,R_day_for,params);
% 
% Hg10 = Hg;
% recharge10 =r;
% qg10 = qg;
% 
% %Convert to yield
% %WB
% B = 0;
% WBlev0 = dHpeakmeanWB+B; %avg distance from peaks to reg model + 2 (gives the level at which water would run out)
% WBlevlow = WBlev0+dHtroughmaxWB;
% 
% z_WB = 100*ones(1,length(Hg));
% 
% for i = 1:length(z_WB)
%     if Hg(i) < WBlevlow
%         z_WB(i) = 100*(Hg(i)-WBlev0)/(WBlevlow-WBlev0); %gives decimal (0 being full pumping capacity, 1 being fully out of pumping vol) of yield as % of max yield
%         if z_WB(i)<0 %occurs in the case where head is below the WBlev0
%             z_WB(i)=0;
%         end
%     end
% end
% 
% z_WB_10 = z_WB;
% 
% % %Modify to chop off the top bits
% % for x = 1:length(Hg10)
% %     if Hg10(x) > Th
% %         recharge(x) = 0;
% %         qg(x) = k*(Th-params.Hg_min);
% %         Hg10(x) = Th;
% %     end
% % end
% 
% %Pm20
% params=input_params(Sy,h0_for,k,k_wei,lambda);
% [Hg,r,qg] = gwm(P25_for,AE_for,R_day_for,params);
% 
% Hg25 = Hg;
% recharge25 =r;
% qg25 = qg;
% 
% %Convert to yield
% %WB
% B = 0;
% WBlev0 = dHpeakmeanWB+B; %avg distance from peaks to reg model + 2 (gives the level at which water would run out)
% WBlevlow = WBlev0+dHtroughmaxWB;
% 
% z_WB = 100*ones(1,length(Hg));
% 
% for i = 1:length(z_WB)
%     if Hg(i) < WBlevlow
%         z_WB(i) = 100*(Hg(i)-WBlev0)/(WBlevlow-WBlev0); %gives decimal (0 being full pumping capacity, 1 being fully out of pumping vol) of yield as % of max yield
%         if z_WB(i)<0 %occurs in the case where head is below the WBlev0
%             z_WB(i)=0;
%         end
%     end
% end
% 
% z_WB_25 = z_WB;
% 
% 
% % %Modify to chop off the top bits
% % for x = 1:length(Hg25)
% %     if Hg25(x) > Th
% %         recharge(x) = 0;
% %         qg(x) = k*(Th-params.Hg_min);
% %         Hg25(x) = Th;
% %     end
% % end
% 
% %Pm50
% params=input_params(Sy,h0_for,k,k_wei,lambda);
% [Hg,r,qg] = gwm(P50_for,AE_for,R_day_for,params);
% 
% Hg50 = Hg;
% recharge50 =r;
% qg50 = qg;
% 
% %Convert to yield
% %WB
% B = 0;
% WBlev0 = dHpeakmeanWB+B; %avg distance from peaks to reg model + 2 (gives the level at which water would run out)
% WBlevlow = WBlev0+dHtroughmaxWB;
% 
% z_WB = 100*ones(1,length(Hg));
% 
% for i = 1:length(z_WB)
%     if Hg(i) < WBlevlow
%         z_WB(i) = 100*(Hg(i)-WBlev0)/(WBlevlow-WBlev0); %gives decimal (0 being full pumping capacity, 1 being fully out of pumping vol) of yield as % of max yield
%         if z_WB(i)<0 %occurs in the case where head is below the WBlev0
%             z_WB(i)=0;
%         end
%     end
% end
% 
% z_WB_50 = z_WB;
% 
% % %Modify to chop off the top bits
% % for x = 1:length(Hg50)
% %     if Hg50(x) > Th
% %         recharge(x) = 0;
% %         qg(x) = k*(Th-params.Hg_min);
% %         Hg50(x) = Th;
% %     end
% % end
% 
% %Plot forecasts
% figure(10);
% plot(R_day_for,z_WB_25);
% hold on
% plot(R_day_for,z_WB_50);
% plot(R_day_for,z_WB_10);
% plot(R_day_for,z_WB_100);
% legend('Historic Rainfall', '25% Forecast', '50% Forecast', '75% Forecast', '100% Forecast');
% xlim([datetime(2016,08,01,00,00,00) datetime(2017,06,01,00,00,00)])
% 
% set(gca,'FontSize',12, 'xminorgrid', 'on')
% ylabel('Yield (%)')
% %add vertical grid
% ax = gca;
% ax.GridLineStyle = '--';




%% Input parameters function
function params=input_params(Sy,h0,k,lambda,k_wei)
% Refer to gwm.m for parameter details
% All Units in [m] unless stated otherwise
params.Sy = Sy; % [no units]
params.k = k; % [1/day] # Changed to final value from Rae's report on page 26.
params.SM_max = 0.005;
params.Hg_min = 0; % Outflow base about aquifer base 
params.SM_i = 0;
params.Hg_i = h0;
params.k_wei = k_wei; % controls the density of function around peak
params.lambda = lambda; % controls the location of the peak
end

%% Input parameters function for uncalibrated AquiMod
function params=input_params_OG(Sy,h0,K,lambda,k_wei)
% Refer to gwm.m for parameter details
% All Units in [m] unless stated otherwise
params.Sy = Sy; % [no units]
params.K = K; % [1/day] # Changed to final value from Rae's report on page 26.
params.SM_max = 0.005;
params.Hg_min = 0; % Outflow base about aquifer base 
params.SM_i = 0;
params.Hg_i = h0;
params.k_wei = k_wei; % controls the density of function around peak
params.lambda = lambda; % controls the location of the peak
end
