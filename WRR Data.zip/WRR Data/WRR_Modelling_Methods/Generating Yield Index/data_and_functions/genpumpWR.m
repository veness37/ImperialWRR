clear; clc; 
close all;
% To generate the parameters required to match the actual abstraction
load ('C:\Users\wv13\Desktop\Project Code\Final_Model_Rae_Veness\Final_Model\Well Level Extraction\NPD_corr.mat','WR');

%% Limit Data
stdate = datetime(2017,07,21,06,15,00); 
enddate = datetime(2018,02,14,16,15,00);
% enddate = stdate + days(21);
% stdate = datetime(2017,12,31,00,00,00); 
% enddate = datetime(2018,01,4,12,00,00);
i1 = find(WR.date == stdate);
i2 = find(WR.date == enddate);
limWR.data = WR.depth(i1:i2);
limWR.date = WR.date(i1:i2);
%% Find abstraction starts
[start.data,start.i] = findpeaks(limWR.data,'MinPeakProminence',0.05);
start.date = limWR.date(start.i);

%By flipping in to negative you get the troughs
[stop.data,stop.i] = findpeaks(-limWR.data,'MinPeakProminence',0.05);
stop.data = -stop.data; %return to positive value
stop.date = limWR.date(stop.i);

% %add starting head as a first peak from first measurement
% start.date = [limWC.date(1), start.date];
% start.data = [limWC.data(1), start.data];

start.date(end) = [];
start.data(end) = [];
start.i(end) = [];

%to make vectors same length (final trough is not recorded by find peaks)
start.date(end-1) = [];
start.data(end-1) = [];
start.i(end-1) = [];

stop.date(1) = [];
stop.data(1) = [];
stop.i(1) = [];

% Removing errors in the identify errors section:
% start.date(21) = [];
% start.data(21) = [];
% start.i(21) = [];
% 
% start.date(91) = [];
% start.data(91) = [];
% start.i(91) = [];
% 
% start.date(93) = [];
% start.data(93) = [];
% start.i(93) = [];
% 
% start.date(98) = [];
% start.data(98) = [];
% start.i(98) = [];
% 
% start.date(98) = [];
% start.data(98) = [];
% start.i(98) = [];
% 
% start.date(98) = [];
% start.data(98) = [];
% start.i(98) = [];
% 
% start.date(100) = [];
% start.data(100) = [];
% start.i(100) = [];
% 
% start.date(104) = [];
% start.data(104) = [];
% start.i(104) = [];
% 
% start.date(105) = [];
% start.data(105) = [];
% start.i(105) = [];
% 
% start.date(129) = [];
% start.data(129) = [];
% start.i(129) = [];

%% Identify and delete errors
% for k1 = 1:length(start.data)-1
%     if start.date(k1+1) < stop.date(k1)
%         start.date(k1+1)
%         error('Multiple start points, k1 = %g\n', k1)
%     end
% end
% 
% for k1 = 1:length(stop.data)-1
%     if stop.date(k1) < start.date(k1)
%         stop.date(k1)
%         error('Multiple stop points k1 = %g\n', k1)
%     end
% end
for runs = 1:20 %run multiple times incase stop to balance any deletes in stops and starts
k1 = 1;
while k1 < length(start.data)
    if start.date(k1+1) < stop.date(k1)
        start.date(k1+1);
        start.date(k1+1) = [];
        start.data(k1+1) = [];
        start.i(k1+1) = [];
        k1=k1-1; %incase there are 3+ repeated start points
    end
    k1=k1+1;
end

k1=1;
while k1 < length(stop.data)
    if stop.date(k1) < start.date(k1)
        stop.date(k1);
        stop.date(k1) = [];
        stop.data(k1) = [];
        stop.i(k1) = [];
        k1=k1-1;
    end
    k1=k1+1;
end

end

%% Plot abstraction starts
figure; hold on; grid on;
plot(limWR.date,limWR.data)
plot(start.date,start.data,'o')
plot(stop.date,stop.data,'o')
% plot(start2.date,start2.data,'.k')
% ctdate = start.date(203);
% xlim([ctdate - days(3), ctdate + days(3)])
legend('Measured','Start Abstraction','End Abstraction')
xlabel('Date')
ylabel('Water elevation [m]')
title('Abstraction times')


%% Find Abstraction duration 
dt = stop.date - start.date;
dh = nan(length(dt),1);
count = 0;
for k1 = 1:length(start.i) %loop through all indices for start peaks
    endp = start.i(k1); % Index of end point of linearisation
    std = start.date(k1); % Start date
    
    stp = endp - 20; % Index of start point of linearisation
    if k1 > 1 && stp < stop.i(k1-1) % If start point is earlier than previous abstraction stop point
        stp = stop.i(k1-1); % Set previous abstration stop point as start point
    end
    
    if k1 == 1 %avoid negative at start 
        stp = endp-1;
    end
    
    % calculating %%assuming this is extrapolation??
    ye = limWR.data(stp:endp);
    xe = datenum(limWR.date(stp:endp)-years(2017));
    
    if length(ye) > 0 %if this isn't satisfied everytime (see count), there is still issue of double peaks
    p = polyfit(xe,ye,1);
    
    xp = xe;
    xp(end+1) = datenum(limWR.date(endp)-years(2017)+dt(k1)); %adds the extrapolation on until the next trough time
    yp = p(1)*xp + p(2); %plot extrapolation line from polyfit
    xp = datetime(xp,'convertfrom','datenum') + years(2017);
    
    if yp(end) < start.data(k1)
        yp(end) = start.data(k1); %no extrapolation if there has been heavy fluctuation in the polyfit period or any error with 'n' for polyfit
    end
    dh(k1) = stop.data(k1) - yp(end); %this calculates head change at each pumping stop point
    
    else
        dh(k1) = stop.data(k1) - start.data(k1);
        count = count + 1; %counts number of times polyfit failed due to 1 or less values to work with - increase number of runs on extra peak deletes (currently 20) to solve this
    end
    % Plotting
    plot(xp,yp,'r-','Linewidth',1.5);
end
count
legend('Measured','Start Abstraction','End Abstraction','Extrapolation')
% dh2 = stop.data - start.data;
absvol = -dh*pi*1.5^2; % [m3] %assuming 2m well radius? %VOLUME
absrate = absvol./datenum(dt); % [m3/day] %PUMPING RATE FOR EVENT
% 
ctdate = datetime(2017,11,06,00,00,00);
figure;
subplot(3,1,1);
bar(start.date,dt) %dt DURATION OF EACH PUMPING EVENT
ylabel('Duration')
title('Abstraction Duration')
% xlim([ctdate-days(3), ctdate + days(3)])

subplot(3,1,2);
bar(start.date,dh)
ylabel('[m]')
title('Change in head')
% xlim([ctdate-days(3), ctdate + days(3)])

subplot(3,1,3)
bar(start.date,absrate)
ylabel('[m3/day]')
title('Abstraction Rate')
% xlim([ctdate-days(3), ctdate + days(3)])
%% Output data
check = input('Save data? Check filename ');
% check = 0;
if check == 1
    abs.startdata = start.data;
    abs.startdate = start.date;
    abs.enddata = stop.data;
    abs.enddate_pump = stop.date;
    abs.pumprate = absrate;
    abs.pumpdur = dt;
    abs.stdate = stdate; %single date
    abs.enddate = enddate; %single date
    save abs_nn1WR.mat abs
%     save('D:\FYP(Com)\SPIDERR\Post Processing\abs_n1.mat','abs')
end
