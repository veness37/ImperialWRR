% Regional Calibration Model File
function [hw_SAFE, t_SAFE] = ModelCall_Well2(PARAMS, P, AE, r_day)


%PARAMS = Sy, k,  k_wei

% %Clear Workspace
% clc
% close all
% clear all


%% Parameters and logarithmic node creation
b = 0; %height of well above base of aquifer (fixed as it is insensitive to outcome)
Sy = PARAMS(1);
k = PARAMS(2);
k_wei = PARAMS(3);
lambda = PARAMS(4);
Rmax = 500;

%Regional Parameters for SAFE
% Refer to gwm.m for parameter details
params.Sy = Sy; % [no units]
params.k = k; % [1/day] # Changed to final value from Rae's report on page 26.
params.SM_max = 0.005;
params.Hg_min = 0; % Outflow base about aquifer base 
params.SM_i = 0;
params.Hg_i = 3; %h0 from manual calibration (alternative would be to do first pumping startdata + dH from manual calibration). 
params.k_wei = k_wei; % controls the density of function around peak
params.lambda = lambda; % controls the location of the peak
params.Rmax = Rmax;


%% Groundwater Model to generate recharge vector
% params=input_params(Sy,h0);

[Hg,r,qg] = gwm(P,AE,r_day,params);
%clip Hg to remove r_day not including pumping data
Hg(isnan(Hg))=[];

hw_SAFE = Hg;
t_SAFE = r_day;

