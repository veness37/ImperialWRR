% This folder provides an application example of the modified AquiMod model and calibration for Well 2 (Bottle) using a
% shallow, large diameter well in Maroodi Jeex, Somaliland

%Guide to folder:
%1. Workflow_WB_regional_single_2021.m = Input parameters to initialise
%automated calibration

%2. ModelCall_Well2.m = File calling groundwater model function (gwm.m) and
%inputting remaining fixed parameters in to Aquimod model

%3. gwm.m = Modified, vertical AquiMod function to simulate a daily value
%of the water table (Hg) during the data collection period

%4. Regional_PostProcessing_WB_2021.m = Post-processing file with objective
%functions (NSE and PBIAS; MultiObj) to evaluate best fitting parameter set to the
%observed data

clear all 
close all
clc

%% Step 1 (add paths)
disp('INITIALISE THE DIRECTORY')

my_dir = pwd;

% Set current directory to 'my_dir' and add path to sub-folders:
cd(my_dir)
addpath(genpath(my_dir))

disp('Done'); disp(' ')

%% Step 2 (setup the Somaliland numerical model)

disp('INITIALISE THE DATA')


%% Load Recharge + Observed Bottle (Well 2) Well Data 
% Rainfall area of roughly 40 x 40 km
% Evaporation area of roughly 55 x 55 km

%Add Necessary Folders to Path (NOTE: Directory updating on different computer) 
%path

% Load Rainfall Data for Recharge, Load Well Bottle Data for Pumping (from pressure transducer) 
load rainfall_endmay.mat 
load NPD_corr.mat 
% r is rainfall (from TAMSAT)
% ev is evaporation (from AFDM VIC hydrologic model)
% r and ev in [mm]
% Well level in [m]
ev_day = ev_day(~isnat(ev_day)); % Removing NaT

% Calculating average rainfall and evaporation
P = mean(r,1);
P = mean(P,2);
P = P(:); % Mean for 1 day
P = P/1000; % convert rainfall to [m]

AE = mean(ev,1);
AE = mean(AE,2);
AE = AE(:); % Mean for 1 day
AE = AE/1000; % convert evap to [m]

% Extracting only peaks of well level
[WBpk.depth,i] = findpeaks(WB.depth);
WBpk.date = WB.date(i);
[WBpk.depth,i] = findpeaks(WBpk.depth);
WBpk.date = WBpk.date(i);

% Extracting relevant rainfall data to match well data range
P = P(r_day>WB.date(1));
r_day = r_day(r_day>WB.date(1));

P = P(r_day<=ev_day(end));

r_day = r_day(r_day<=ev_day(end));

% Extracting relevant evap
AE = AE(ev_day>WB.date(1));
ev_day = ev_day(ev_day>WB.date(1));

% AE = AE(ev_day<WB_pr_date_corr(end));
% ev_day = ev_day(ev_day<WB_pr_date_corr(end));

%% Define inputs:
DistrFun  = 'unif'  ; % Parameter distribution
DistrPar  = { [ 0.0085 0.0105 ]; [ 0.00009 0.0001 ]; [ 3 20 ]; [ 13 20 ] } ; % Parameter ranges (from literature)
x_labels = {'Sy', 'k', 'k_wei', 'lambda'};

% Define output:
myfun = 'ModelCall_Well2' ;

%% Step 3 (sample inputs space)
SampStrategy = 'lhs' ; % Latin Hypercube
N = 10000 ; % Number of samples
M = length(DistrPar) ; % Number of inputs
X = AAT_sampling(SampStrategy,M,DistrFun,DistrPar,N)

% Plot results of the random sampling
figure; parcoor(X,x_labels); % Parallel coordinate plots

%% Step 4 (run the model) 
[hw_SAFE, t_SAFE] = model_evaluation(myfun,X,P,AE,r_day) ;

save('Y10000Well2.mat','hw_SAFE');
% save('t20.mat','t_SAFE');
save('X10000Well2.mat','X');

% %% Step 5a (Regional Sensitivity Analysis with threshold)
% 
% % Visualize input/output samples (this may help finding a reasonable value
% % for the output threshold):
% figure; scatter_plots(X,Y(:,1),[],'rmse',x_labels) ;
% figure; scatter_plots(X,Y(:,2),[],'bias',x_labels) ;
% 
% % Set output threshold:
% rmse_thres = 3   ; %  threshold for the first obj. fun.
% bias_thres = 0.5 ; % behavioural threshold for the second obj. fun.
% 
% % RSA (find behavioural parameterizations):
% threshold = [ rmse_thres bias_thres ] ;
% [mvd,idxb] = RSA_indices_thres(X,Y,threshold) ;
% 
% % Highlight the behavioural parameterizations in the scatter plots:
% figure; scatter_plots(X,Y(:,1),[],'rmse',x_labels,idxb) ;
% figure; scatter_plots(X,Y(:,2),[],'bias',x_labels,idxb) ;
% 
% % Plot parameter CDFs:
% RSA_plot_thres(X,idxb,[],x_labels,{'behav','non-behav'}); % add legend
% 
% % Check the ranges of behavioural parameterizations by
% % Parallel coordinate plot:
% parcoor(X,x_labels,[],idxb)
% 
% % Plot the sensitivity indices (maximum vertical distance between
% % parameters CDFs):
% figure; boxplot1(mvd,x_labels,'mvd')
% 
% % Assess robustness by bootstrapping:
% Nboot = 100;
% [mvd,idxb,mvd_lb,mvd_ub] = RSA_indices_thres(X,Y,threshold,[],Nboot);
% % Plot results:
% boxplot1(mvd,x_labels,'mvd',mvd_lb,mvd_ub)
% 
% % Repeat computations using an increasing number of samples so to assess
% % convergence:
% NN = [ N/5:N/5:N ] ;
% mvd = RSA_convergence_thres(X,Y,NN,threshold) ;
% % Plot the sensitivity measures (maximum vertical distance between
% % parameters CDFs) as a function of the number of samples:
% figure; plot_convergence(mvd,NN,[],[],[],'no of samples','mvd',x_labels)
% 
% % Repeat convergence analysis using bootstrapping to derive confidence
% % bounds:
% Nboot = 100;
% [mvd_mean,mvd_lb,mvd_ub]  = RSA_convergence_thres(X,Y,NN,threshold,[],Nboot) ;
% figure
% plot_convergence(mvd_mean,NN,mvd_lb,mvd_ub,[],'no of samples','mvd',x_labels)
% 
% %% Step 5b (Regional Sensitivity Analysis with groups)
% 
% % RSA (find behavioural parameterizations):
% [stat,idx,Yk] = RSA_indices_groups(X,Y(:,1)) ;
% 
% % Plot parameter CDFs:
% RSA_plot_groups(X,idx,Yk) ;
% % Customize labels and legend:
% RSA_plot_groups(X,idx,Yk,[],x_labels,'rmse'); % add legend

