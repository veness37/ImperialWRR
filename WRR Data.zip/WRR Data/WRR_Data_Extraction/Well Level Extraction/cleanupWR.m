% Cleans up raw data from extract_csv
clear; clc; close all;
%% Loading Data
addpath('..\SPIDERR2\Post Processing\Functions')
load NPD.mat WR
load dipdata2.mat R;
WR.corrdate = WR.corrdate + years(2000);
%% 
figure; hold on; grid on;
plot(WR.date,WR.depth,'.-');
plot(R.dipdate,R.dip,'o');
ylim([0 2])
% ct = R.dipdate(1);
% xlim([ct-days(1) ct+days(1)]);
title('No change to data')
for k1 = 1:length(WR.corrdate)
    plot([WR.corrdate(k1), WR.corrdate(k1)],[0 2],'k--')
end
%% Remove Anomalies
[WR2.depth] = filt_thresh(WR.date, WR.depth, datetime(2017,8,22), datetime(2017,8,22,12,0,0), 0.2, 'SM');
[WR2.depth] = filt_thresh(WR.date, WR2.depth, datetime(2017,09,21), datetime(2017,09,22), 1, 'SM');
WR2.date = WR.date;
WR2.date(isnan(WR2.depth))=[];
WR2.depth(isnan(WR2.depth))=[];


%% Plotting after removing anomalies
figure; hold on; grid on;
plot(WR2.date,WR2.depth);
plot(R.dipdate,R.dip,'o');
ylim([0 2])

title('After Removing Anomalies')

%% Relative Correction
corrdate = [datetime(2017,08,22,9,30,0);
    datetime(2017,9,21,8,45,0);
    datetime(2017,11,27,11,30,0)];
[WR3.depth] = relative_correction(WR2.date,WR2.depth,corrdate);
WR3.date = WR2.date;

%% 
figure;
subplot(2,1,1); hold on; grid on;

plot(WR.date,WR.depth,'.-');
plot(R.dipdate,R.dip,'o');
for k1 = 1:length(WR.corrdate)
    plot([WR.corrdate(k1), WR.corrdate(k1)],[0 2],'k--')
end
ylim([0 2])
title('Original Data')

subplot(2,1,2); hold on; grid on;
plot(WR3.date,WR3.depth,'.-');
plot(R.dipdate,R.dip,'o');
% for k1 = 1:length(WR.corrdate)
%     plot([WR.corrdate(k1), WR.corrdate(k1)],[0 2],'k--')
% end
ylim([0 2])
title('After Relative Correction')
%% Varying views to check correction is correctly done
for k1 = 1:length(corrdate)
    ct = corrdate(k1);
    subplot(2,1,1)
    plot([ct ct],[min(WR3.depth) max(WR3.depth)],'c--')
    xlim([ct - days(0.5),ct + days(0.5)]);
    
    subplot(2,1,2)
    plot([ct ct],[min(WR3.depth) max(WR3.depth)],'c--')
    xlim([ct - days(0.5),ct + days(0.5)]);
end

for k1 = 1:length(WR.corrdate)
    subplot(2,1,1)
    ct = WR.corrdate(k1);
    plot([ct ct],[min(WR3.depth) max(WR3.depth)],'c--')
    xlim([ct - days(0.5),ct + days(0.5)]);
    
    subplot(2,1,2)
    ct = WR.corrdate(k1);
    plot([ct ct],[min(WR3.depth) max(WR3.depth)],'c--')
    xlim([ct - days(0.5),ct + days(0.5)]);
end

for k1 = 1:length(R.dipdate)
    subplot(2,1,1)
    ct = R.dipdate(k1);
    plot([ct ct],[min(WR3.depth) max(WR3.depth)],'c--')
    xlim([ct - days(0.5),ct + days(0.5)]);
    subplot(2,1,2)
    ct = R.dipdate(k1);
    plot([ct ct],[min(WR3.depth) max(WR3.depth)],'c--')
    xlim([ct - days(0.5),ct + days(0.5)]);
end
%% Saving Data
check = input('Save data?');
if check == 1
    WR = WR3;
    save NPD_corr.mat WR -append
end
