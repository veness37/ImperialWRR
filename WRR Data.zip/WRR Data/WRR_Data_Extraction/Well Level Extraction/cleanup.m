% Cleans up raw data from extract_csv
clear; clc; close all;
%% Loading Data
addpath('..\SPIDERR2\Post Processing\Functions')
load NPD.mat
load dipdata2.mat B;
WB.corrdate = WB.corrdate + years(2000);
%% 
figure; hold on; grid on;
plot(WB.date,WB.depth,'.-');
plot(B.dipdate,B.dip,'o');
ylim([0 9])
ct = B.dipdate(1);
% xlim([ct-days(1) ct+days(1)]);
title('No change to data')
%% Remove Anomalies
[WB2.depth] = filt_thresh(WB.date, WB.depth, datetime(2017,8,23), datetime(2017,8,23,10,0,0), 0.2, 'SM');
[WB2.depth] = filt_thresh(WB.date, WB2.depth, datetime(2017,09,21), datetime(2017,09,22), 4.5, 'SM');
[WB2.depth] = filt_thresh(WB.date, WB2.depth, datetime(2017,10,30), datetime(2017,10,31), 2.5, 'SM');
[WB2.depth] = filt_thresh(WB.date, WB2.depth, datetime(2017,11,27), datetime(2017,11,28), 1, 'SM');
[WB2.depth] = filt_thresh(WB.date, WB2.depth, datetime(2017,12,29), datetime(2017,12,30), 2.8, 'LG');
[WB2.depth] = filt_thresh(WB.date, WB2.depth, datetime(2017,9,1,18,15,0), datetime(2017,9,1,19,15,0), 3.65, 'SM');
WB2.date = WB.date;
WB2.date(isnan(WB2.depth))=[];
WB2.depth(isnan(WB2.depth))=[];


%%
figure; hold on; grid on;
plot(WB2.date,WB2.depth);
plot(B.dipdate,B.dip,'o');
ylim([0 9])
ct = B.dipdate(1);
title('After Removing Anomalies')

%% Relative Correction
corrdate = [datetime(2017,08,23,10,00,0);
    datetime(2017,09,01,19,15,0);
    datetime(2017,09,21,12,00,0);
    datetime(2017,10,30,12,30,0);
    datetime(2017,11,27,12,30,0)];
[WB3.depth] = relative_correction(WB2.date,WB2.depth,corrdate);
WB3.date = WB2.date;

%% 
figure;
subplot(2,1,1); hold on; grid on;
plot(WB.date,WB.depth,'.-');
plot(B.dipdate,B.dip,'o');
for k1 = 1:length(WB.corrdate)
    plot([WB.corrdate(k1), WB.corrdate(k1)],[0 2],'k--')
end
ylim([0 9])
title('Original Data')

subplot(2,1,2); hold on; grid on;
plot(WB3.date,WB3.depth,'.-');
plot(B.dipdate,B.dip,'o');
for k1 = 1:length(WB.corrdate)
    plot([WB.corrdate(k1), WB.corrdate(k1)],[0 9],'k--')
end
ylim([0 9])
title('After Relative Correction')

%% Plotting example of well levels
figure; hold on; grid on;
plot(WB3.date,WB3.depth,'.-');
% plot(B.dipdate,B.dip,'r--');
% plot(B.dipdate,B.dip,'k--');
% legend('Observations','Expected recovery without further pumping','Estimated water table','Location','bestoutside');
xlabel('Date'); ylabel('Water Level above Well Base [m]');
ylim([0,2.5]);
st = datetime(2017,07,24);
xlim([st, st+days(2)])
%% Varying views to check correction is correctly done
% for k1 = 1:length(corrdate)
%     ct = corrdate(k1);
%     subplot(2,1,1)
%     plot([ct ct],[min(WB3.depth) max(WB3.depth)],'c--')
%     xlim([ct - days(0.5),ct + days(0.5)]);
%     
%     subplot(2,1,2)
%     plot([ct ct],[min(WB3.depth) max(WB3.depth)],'c--')
%     xlim([ct - days(0.5),ct + days(0.5)]);
% end
% 
% for k1 = 1:length(WB.corrdate)
%     subplot(2,1,1)
%     ct = WB.corrdate(k1);
%     plot([ct ct],[min(WB3.depth) max(WB3.depth)],'c--')
%     xlim([ct - days(0.5),ct + days(0.5)]);
%     
%     subplot(2,1,2)
%     ct = WB.corrdate(k1);
%     plot([ct ct],[min(WB3.depth) max(WB3.depth)],'c--')
%     xlim([ct - days(0.5),ct + days(0.5)]);
% end
% 
% for k1 = 1:length(B.dipdate)
%     subplot(2,1,1)
%     ct = B.dipdate(k1);
%     plot([ct ct],[min(WB3.depth) max(WB3.depth)],'c--')
%     xlim([ct - days(0.5),ct + days(0.5)]);
%     subplot(2,1,2)
%     ct = B.dipdate(k1);
%     plot([ct ct],[min(WB3.depth) max(WB3.depth)],'c--')
%     xlim([ct - days(0.5),ct + days(0.5)]);
% end

%% Plotting Extrapolation 
% close all; clc;
% st = datetime(2017,07,23);
% x1 = [datetime(2017,07,23,09,15,00,00),datetime(2017,07,23,09,15,00,00)];
% x2 = [datetime(2017,07,23,09,45,00,00),datetime(2017,07,23,09,45,00,00)];
% y = [1,2.3];
% 
% ye = WB3.depth(252:266);
% xe = datenum(WB3.date(252:266)-years(2017));
% p = polyfit(xe,ye,1);
% 
% xp = xe; 
% xp(end+1) = datenum(WB3.date(266)-years(2017)+hours(0.5));
% yp = p(1)*xp + p(2);
% xp = datetime(xp,'convertfrom','datenum') + years(2017);
%% Plotting Abstraction overview
% figure; hold on; grid on;
% plot(WB3.date,WB3.depth,'.-')
% plot(x1,y,'k-.');
% plot(x2,y,'k--');
% plot(xp,yp,'r-','Linewidth',1.5);
% xlabel('Date')
% ylabel('Water level above well base [m]')
% legend('Well Level','Start of Abstraction','End of Abstraction','Linearisation','Location','bestoutside')
% xlim([st + hours(0), st + days(1)])
% ylim([1 2.3])
%% Plotting zoomed in
% figure; hold on; grid on;
% plot(WB3.date,WB3.depth,'.-')
% plot(x1,y,'k-.');
% plot(x2,y,'k--');
% plot(xp,yp,'r-','Linewidth',1.5);
% xlabel('Date')
% ylabel('Water level above well base [m]')
% legend('Well Level','Start of Abstraction','End of Abstraction','Linearisation','Location','bestoutside')
% xlim([st + hours(6), st + hours(12)])
% ylim([1.6 2])


%% Saving Data
% check = input('Save data?');
check = 0;
if check == 1
    WB = WB3;
    save NPD_corr.mat WB -append
%     save NPD_corr.mat WB 
end
