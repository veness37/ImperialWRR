% Correction assuming dip is from bottom of the well
clear; clc; close all;
%% Loading
load NPD_corr.mat 
% addpath('D:\FYP(Com)\SPIDERR2\Post Processing')
addpath('..\SPIDERR2\Post Processing')
load dipdata2.mat

%% Removing points for Covered Well
C2 = C;
C2.dip(3) = [];
C2.dipdate(3) = [];
B2.dip = B.dip(1);
B2.dipdate = B.dipdate(1);

% B2.dip = B.dip(1);
% B2.dipdate = B.dipdate(1);
%% Correcting
[WB.data,WBd] = correction(WB.date,WB.depth,B);
title('Bottle Well')
[WR.data,WRd] = correction(WR.date,WR.depth,R);
title('Road Well')
[WC.data,WCd] = correction(WC.date,WC.depth,C2);
title('Covered Well')

%% Assigning dates
WB.date = WB.date;
WR.date = WR.date;
WC.date = WC.date;

%% Plotting final figure
figure; 
subplot(3,1,1); hold on; grid on;
plot(WB.date,WB.data,'.-');
plot(B.dipdate,B.dip,'r*');
title('Bottle Well')
ylabel('[m]')
axis tight

subplot(3,1,2); hold on; grid on;
plot(WR.date,WR.data,'.-');
plot(R.dipdate,R.dip,'r*');
title('Road Well')
ylabel('[m]')
axis tight

subplot(3,1,3); hold on; grid on;
plot(WC.date,WC.data,'.-');
plot(C.dipdate,C.dip,'r*');
title('Covered Well')
ylabel('[m]')
axis tight

%% Plotting data without correction
figure; hold on; grid on;
% subplot(3,1,1); hold on; grid on;
plot(WB.date,WB.depth,'.-');
plot(B.dipdate,B.dip,'r*');
% title('Bottle Well')
ylabel('Water level above well base [m]')
xlabel('Date')
axis tight
ylim([0 3])
xlim([datetime(2017,07,21,00,00,00),datetime(2017,07,21,00,00,00) + days(2)]);
% legend('Pressure Transducer Data','Manual Measurements')
%%
figure; hold on; grid on;
% subplot(3,1,2); hold on; grid on;
plot(WR.date,WR.depth,'.-');
plot(R.dipdate,R.dip,'r*');
% title('Road Well')
axis tight
ylim([0 2])
ylabel('Water level above well base [m]')
xlabel('Date')

legend('Pressure Transducer Data','Manual Measurements')

figure; hold on; grid on;
% subplot(3,1,3); hold on; grid on;
plot(WC.date,WC.depth,'.-');
plot(C2.dipdate,C2.dip,'r*');
% title('Covered Well')
axis tight
ylim([0 5])
ylabel('Water level above well base [m]')
xlabel('Date')

legend('Pressure Transducer Data','Manual Measurements')
%%
figure; grid on; hold on;
plot(WB.date,WB.data,'.-');
plot(B.dipdate,B.dip,'r*');
title('Bottle Well')
ylabel('[m]')
axis tight
%% Correcting for - ve elevations
R.base = -(1.18 + 1.57);
B.base = -(6.73 + 1.71);
C.base = -(3.06 + 2.67);

figure; hold on; grid on;
WB.data2 = WB.data + B.base;

h1 = plot(WB.date,WB.data2);
%plot(B.dipdate,B.dip,'r*');
title('Bottle Well')
ylabel('Abstraction Well Head [m]')
axis tight

xlim([datetime(2017,08,15) datetime(2017,08,15)+days(1)])
% For abstraction example
i1 = [2505,2475,];
i2 = [2503,2472];
y = [-7 -9];
for k1 = 1:length(i1)
    h2 = plot([WB.date(i1(k1)),WB.date(i1(k1))],y,'k-');
    h3 = plot([WB.date(i2(k1)),WB.date(i2(k1))],y,'k--');
end

legend([h1,h2,h3],'Well head','Start of abstraction','End of abstraction')
%% Functions
function [errt] = f(delta,well_date,well_level,B)
% Determines the correction required
    WB2 = well_level - delta;
    err = zeros(length(B.dip)-1,1);
    k2e = length(B.dip)-1;
    if k2e == 0
        k2e = 1;
    end
    for k2 = 1:k2e
        [~,i] = min(abs(datenum(well_date) - datenum(B.dipdate(k2))));
        
        err(k2) = B.dip(k2) - WB2(i);
    end
    errt = abs(sum(err));
end

function [WL2,deltaf] = correction(well_date,well_level,B)
fun = @(delta) f(delta,well_date,well_level,B);
deltaf = fminsearch(fun,0);

WL2 = well_level - deltaf;
figure; hold on; grid on;
plot(well_date,WL2,'.-','Markersize',0.1)
plot(B.dipdate,B.dip,'r*')
end