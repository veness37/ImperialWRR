% Cleans up raw data from extract_csv
clear; clc; close all;
%% Loading Data
addpath('..\SPIDERR2\Post Processing\Functions')
load NPD.mat WC
load dipdata2.mat C;
WC.corrdate = WC.corrdate + years(2000);
C.dipdate(3) = [];
C.dip(3) = [];
%% 
figure; hold on; grid on;
plot(WC.date,WC.depth,'.-');
plot(C.dipdate,C.dip,'o');
ylim([0 4])
title('Original data')
for k1 = 1:length(WC.corrdate)
    plot([WC.corrdate(k1), WC.corrdate(k1)],[0 4],'k--')
end
%% Remove Anomalies
[WC2.depth] = filt_thresh(WC.date, WC.depth, datetime(2017,9,21), datetime(2017,9,21,12,0,0), 3, 'SM');
[WC2.depth] = filt_thresh(WC.date, WC2.depth, datetime(2017,10,30), datetime(2017,10,31), 2, 'SM');
[WC2.depth] = filt_thresh(WC.date, WC2.depth, datetime(2017,11,27,6,0,0), datetime(2017,11,27,12,0,0), 2, 'SM');
[WC2.depth] = filt_thresh(WC.date, WC2.depth, datetime(2017,11,27,10,30,0), datetime(2017,11,27,11,30,0), 2.8245, 'SM');

WC2.date = WC.date;
WC2.date(isnan(WC2.depth))=[];
WC2.depth(isnan(WC2.depth))=[];


%% Plotting after removing anomalies
figure; hold on; grid on;
plot(WC2.date,WC2.depth,'.-');
plot(C.dipdate,C.dip,'o');
ylim([0 4])
for k1 = 1:length(WC.corrdate)
    plot([WC.corrdate(k1), WC.corrdate(k1)],[0 4],'k--')
end

title('After Removing Anomalies')

%% Relative Correction
corrdate = [datetime(2017,08,22,11,30,0);
    datetime(2017,9,21,10,30,0);
    datetime(2017,10,30,12,00,0);
    datetime(2017,11,27,11,30,0)];
[WC3.depth] = relative_correction(WC2.date,WC2.depth,corrdate);
WC3.date = WC2.date;

%% 
figure;
subplot(2,1,1); hold on; grid on;

plot(WC.date,WC.depth,'.-');
plot(C.dipdate,C.dip,'o');
for k1 = 1:length(WC.corrdate)
    plot([WC.corrdate(k1), WC.corrdate(k1)],[0 2],'k--')
end
ylim([0 4])
title('Original Data')

subplot(2,1,2); hold on; grid on;
plot(WC3.date,WC3.depth,'.-');
plot(C.dipdate,C.dip,'o');
% for k1 = 1:length(WC.corrdate)
%     plot([WC.corrdate(k1), WC.corrdate(k1)],[0 2],'k--')
% end
ylim([0 4])
title('After Relative Correction')
%% Varying views to check correction is correctly done
for k1 = 1:length(corrdate)
    ct = corrdate(k1);
    subplot(2,1,1)
    plot([ct ct],[min(WC3.depth) max(WC3.depth)],'c--')
    xlim([ct - days(0.5),ct + days(0.5)]);
    
    subplot(2,1,2)
    plot([ct ct],[min(WC3.depth) max(WC3.depth)],'c--')
    xlim([ct - days(0.5),ct + days(0.5)]);
end

for k1 = 1:length(WC.corrdate)
    subplot(2,1,1)
    ct = WC.corrdate(k1);
    plot([ct ct],[min(WC3.depth) max(WC3.depth)],'c--')
    xlim([ct - days(0.5),ct + days(0.5)]);
    
    subplot(2,1,2)
    ct = WC.corrdate(k1);
    plot([ct ct],[min(WC3.depth) max(WC3.depth)],'c--')
    xlim([ct - days(0.5),ct + days(0.5)]);
end

for k1 = 1:length(C.dipdate)
    subplot(2,1,1)
    ct = C.dipdate(k1);
    plot([ct ct],[min(WC3.depth) max(WC3.depth)],'c--')
    xlim([ct - days(0.5),ct + days(0.5)]);
    subplot(2,1,2)
    ct = C.dipdate(k1);
    plot([ct ct],[min(WC3.depth) max(WC3.depth)],'c--')
    xlim([ct - days(0.5),ct + days(0.5)]);
end

%% Plotting for paper
figure;
ct = [datetime(2017,11,27,11,0,0)-days(0.5) datetime(2017,11,27,11,0,0)+days(0.5)];

subplot(2,1,1); hold on; grid on;
plot(WC.date,WC.depth,'.-');
plot(C.dipdate,C.dip,'o');
xlim(ct);
ylim([0 4])
title('Original Data')
xlabel('Well water depth [m]')
ylabel('Date')

subplot(2,1,2); hold on; grid on;
plot(WC3.date,WC3.depth,'.-');
plot(C.dipdate,C.dip,'o');
xlim(ct);
ylim([0 4])
title('After Correction')
xlabel('Well water depth [m]')
ylabel('Date')
%% Saving Data
% check = input('Save data?');
% if check == 1
%     WC = WC3;
%     save NPD_corr.mat WC -append
% end
