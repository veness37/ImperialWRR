% Extracts evaporation data for the desired area
clear; clc; close all;
%% File Setup
% folder = 'D:\FYP(Com)\Final Model\Satellite Data\Evapotranspiration\2017';
folder = '..\Satellite Data\Evapotranspiration\2017';
d=dir(folder); 
s = 0; %for saving

%% Area Required
% For plotting
y = 9.685352; % lat
x = 43.730027; % lon
dx = 20; % Distance in x direction (in one direction (+/-))
dy = 20; % Distance in y direction (in one direction (+/-))
[rx,ry] = ll_solve(y,x,dx,dy);

%% Loop
count = 0;
day_plot = NaT(numel(d),1);
numel(d)

for k = 3:numel(d)-1
    count = count+1;
    % Reading Data
    filename = fullfile(folder, d(k).name);
    lon = ncread(filename,'lon');
    lat = ncread(filename,'lat');
    if count ==1 
        evap = NaN(length(lon),length(lat),numel(d)-2);
    end
    ncread(filename,'evap');
    evap(:,:,count) = ncread(filename,'evap'); % [mm]
    
    % Saving the date of the file
    day_att = ncreadatt(filename,'t','units');
    day_att = strsplit(day_att,' '); % Splitting to remove the unwanted bits
    day_plot(count) = datetime(day_att{3}); %
    
    clearvars -except lon lat evap day_plot s f k folder count d
end

%% Plotting
figure;
a1 = min(evap(:)); a2 = max(evap(:));
for k = 1:size(evap,3)
    h = surf(lat,lon,evap(:,:,k));
    set(h,'LineStyle','none')
    colorbar;
    caxis([a1,a2]); zlim([a1,a2]); 
    ylim([min(lon(:)), max(lon(:))]);
    xlim([min(lat(:)), max(lat(:))]);
    title(datestr(day_plot(k)))
    drawnow;
    pause(0.1);
end
%% Saving
check = input('Save?\n');
if check ~= 1
    return
end

ev = evap;
ev_day = day_plot;
ev_lat = lat;
ev_lon = lon;
save('rainfall_2016.mat','ev','ev_day','-append');
save('rainfall_2016.mat','ev_lon','ev_lat','-append');
%%
% This section compares the area covered by the rainfall and evaporation
% dataset
clear
load('rainfall_20x20.mat')

figure;
subplot(1,2,1);
[X,Y] = meshgrid(r_lon,r_lat);
plot(X,Y,'o');
title('rain')
plot_google_map

subplot(1,2,2);
[X,Y]   = meshgrid(ev_lon,ev_lat);
plot(X,Y,'o');
title('evap')
plot_google_map

%% 
[~,dx] = lldistkm([lat(1),lon(1)],[lat(1),lon(end)]);
[~,dy] = lldistkm([lat(1),lon(1)],[lat(end),lon(1)]);
area = dx*dy;
evap = evap/area; % [mm/km2];











