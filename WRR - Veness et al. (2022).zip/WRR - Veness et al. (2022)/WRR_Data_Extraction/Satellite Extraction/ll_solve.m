% Latlon solver
% Solves for required coordinate away from a point (long,lat) for a desired
% distance in each direction
% Makes use of lldist

% rx is the required coordinate for the distance between [long + rx] and
% [long - rx] equals to dx
function [rx,ry] = ll_solve(y,x,dx,dy)
%% 
funy = @(r) ydist(y,x,r,dy);
ry = fzero(funy,1);

funx = @(r) xdist(y,x,r,dx);
rx = fzero(funx,1);

% Checks
checkx = lldistkm([y,x],[y,x+rx])-dx; % [km]
checky = lldistkm([y,x],[y+ry,x])-dy; % [km]
if checkx > 1e-4
    fprintf('Longtitude failed\n')
end
if checky > 1e-4
    fprintf('Latitude failed\n')
end



   function [ddist] = ydist(y,x,r,dy)
        % y and x are lat and long respectively 
        % r is the coordinate away from y
        % dy is the desired distance from y,x
        % dist is the difference between the (distance between y and
        % y+r) and dy
        % Thus when dist = 0, r is equal to r required for dy
        ddist = lldistkm([y,x],[y+r,x])-dy;
    end

    function [ddist] = xdist(y,x,r,dx)
        % y and x are lat and long respectively 
        % r is the coordinate away from y
        % dy is the desired distance from y,x
        % dist is the difference between the (distance between y-r and
        % y+r)- dy
        % Thus when dist = 0, r is equal to r required for dy
        ddist = lldistkm([y,x],[y,x+r])-dx;
    end

end
