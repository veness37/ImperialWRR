% Extract HOBO data from cvs
clear; clc; close all;
%% File Setup
folder = '..\Well Level Data\Well - Bottle\WB - Pressure\Pressure';
d=dir(folder); 
s=0;

%% Dip Data
if strcmp(folder,'..\Well Level Data\Well - Road\WR - Pressure\Pressure')
    dip = [1.06,1.54,1.05,0.54,0.33];
    dipdate = [datetime('08/22/2017 9:11:00 AM'),...
        datetime('09/21/2017 8:55:00 AM'),...
        datetime('10/30/2017 12:59:00 PM'),...
        datetime('11/22/2017 9:28:00 AM'),...
        datetime('02/22/2018 9:11:00 AM')];
elseif strcmp(folder,'..\Well Level Data\Well - Bottle\WB - Pressure\Pressure')
    dip = [1.63,5.46,3.2,1.89,0.66];
    dipdate = [datetime('08/23/2017 9:03:00 AM'),...
        datetime('09/21/2017 11:39:00 AM'),...
        datetime('10/30/2017 10:24:00 AM'),...
        datetime('11/22/2017 12:31:00 PM'),...
        datetime('02/22/2018 12:31:00 PM')];
elseif strcmp(folder,'..\Well Level Data\Well - Covered\WC - Pressure\Pressure')
    dip = [2.77, 3.56, 5.39, 2.24, 1.23];
    dipdate = [datetime('08/22/2017 11:34:00 AM'),...
        datetime('09/21/2017 9:53:00 AM'),...
        datetime('10/30/2017 10:24:00 AM'),...
        datetime('11/22/2017 10:58:00 AM'),...
        datetime('02/22/2018 10:19:00 AM')];
end
%% Loop
corrdate = NaT(numel(d)-2,1);

for k = 3:numel(d)
%     close all; 
    clearvars -except folder f d k sensor save_date save_depth s dip dipdate corrdate
    s=s+1; % Counter for saving
%     fprintf('File location is '); fprintf(d(k).name); fprintf('\n');
    file = fullfile(folder, d(k).name);
    % Reading Data
    T=readtable(file); %,'format','%{MM/dd/uuuu HH:mm:ss }D %f%f%f%f%f%f%f%f%f%f%f' );    % Assigning Data
    data_date = table2array(T(:,2));
    depth = table2array(T(:,5));
    corrdate(k-2)=data_date(end); % Saving correction dates

    % Conversions
    data_date = data_date + years(2000); % Conversion to 2017
    data_date(isnan(depth))=[]; % Removal of 
    depth(isnan(depth))=[];

    %% Plotting  
    figure; 
    subplot(2,1,1); hold on; grid on;
    plot(data_date,depth,'.-');
    plot(dipdate,dip,'o');
%     n = c(1); %dipdate require
%     xlim([dipdate(n)-days(0.5) dipdate(n)+days(0.5)]);
    ylabel('Level [m]');
    xlabel('Date');
%     Saving
    if s == 1
        save_date = data_date;
        save_depth = depth; % After translation
    else
        save_date(end+1:end+length(data_date)) = data_date;
        save_depth(end+1:end+length(data_date)) = depth;
    end
end

%% Plotting All (Without Correction)
figure; hold on; grid on;
plot(save_date,save_depth,'.-');
plot(dipdate,dip,'o');
xlabel('Date');
ylabel('Level');
title('Well Depth');
legend('Pressure Transducer Data','Manual Measurements')

%% Saving
check = input('Overwrite saved data? Do check save name\n');
if check == 1
    if strcmp(folder,'..\Well Level Data\Well - Road\WR - Pressure\Pressure')
        WR.date = save_date;
        WR.depth = save_depth;
        WR.corrdate = corrdate;
        save('NPD.mat','WR','-append');
    elseif strcmp(folder,'..\Well Level Data\Well - Bottle\WB - Pressure\Pressure')
        WB.date = save_date;
        WB.depth = save_depth;
        WB.corrdate = corrdate;
        save('NPD.mat','WB','-append');
    elseif strcmp(folder,'..\Well Level Data\Well - Covered\WC - Pressure\Pressure')
        WC.date = save_date;
        WC.depth = save_depth;
        WC.corrdate = corrdate;
        save('NPD.mat','WC','-append');
    end
end
%% 
