clear; clc; close all;
file = 'D:\FYP(Com)\Organised Data\Well - Bottle\WB - Pressure\Pressure\20113004_baro.csv';
file2 = 'D:\FYP(Com)\Organised Data\Well - Bottle\WB - Pressure\Pressure\20113004.csv';
T = readtable(file);
T2 = readtable(file2);
%% Assigning Data
baro.date = table2array(T(:,2));
baro.pressure = table2array(T(:,3));
baro.depth = table2array(T(:,6));
baro.baro = table2array(T(:,5));

abs.date = table2array(T2(:,2));
abs.pressure = table2array(T2(:,3));
abs.depth = table2array(T2(:,6));
abs.baro = table2array(T2(:,5));

%%
% cpr = mean(baro.baro,'omitnan');
figure; hold on; grid on;
plot(baro.date,baro.depth,'.-');
plot(abs.date,abs.depth,'.-');

%%
i = find(baro.date == abs.date(1));
i2 = find(baro.date == abs.date(end));
baro.depth2 = baro.depth(i:i2);
err = baro.depth2-abs.depth;

figure; 
plot(err);
title('Absolute Error')
mean(err,'omitnan');

% if check = 1
%     save 
% perr = err./baro.depth;
figure; plot(perr); 
title('Percentage Error')

%% 
% addpath('D:\FYP(Com)\SPIDERR2\Post Processing\Functions')
% load pressure_data_3.mat WB_pr_date_og WB_pr_og
% 
% figure; hold on; grid on;
% corr = 86.1*1e3/(9.97*1e3)
% plot(WB_pr_date_og,WB_pr_og-corr);
