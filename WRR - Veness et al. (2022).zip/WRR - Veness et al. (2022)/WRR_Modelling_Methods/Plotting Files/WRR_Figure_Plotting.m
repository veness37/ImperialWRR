%NDVI MODIS L3 16-day - The Vegetation Index (L3, 16-Day) layer is created from the Aqua Moderate Resolution Imaging Spectroradiometer (MODIS) Vegetation Indices (MYD13Q1) data which are generated every 16 days at 250 meter (m) spatial resolution as a Level 3 product. The MYD13Q1 product provides Normalized Difference Vegetation Index (NDVI) which is referred to as the continuity index to the existing National Oceanic and Atmospheric Administration-Advanced Very High Resolution Radiometer (NOAA-AVHRR) derived NDVI. The algorithm chooses the best available pixel value from all the acquisitions from the 16-day period. The criteria used is low clouds, low view angle, and the highest NDVI value.
%The MODIS Normalized Difference Vegetation Index (NDVI) complements NOAA's Advanced Very High Resolution Radiometer (AVHRR) NDVI products and provides continuity for time series historical applications. The MODIS NDVI product is computed from surface reflectances corrected for molecular scattering, ozone absorption, and aerosols.

%SMAP Radiometer Soil Moisture 9 km L3 Passive Day - The Soil Moisture Active Passive (SMAP) "Soil Moisture 9 km (L3, Passive, Day)" layers display a daily global composite of surface soil moisture in cm3/cm3 derived from the Single Channel Algorithm V-Pol (SCA-V), the baseline soil moisture algorithm, for the 6:00 a.m. descending (Day) half-orbit passes of the SMAP radiometer. To enhance the grid resolution, Backus-Gilbert optimal interpolation techniques are used to extract maximum information from SMAP antenna temperatures and convert them to brightness temperatures, which are posted to the 9 km EASE-Grid 2.0. The SMAP radiometer measures natural thermal emission emanating from the soil surface. The variation in the intensity of this radiation depends on the dielectric properties and temperature of the target medium, which for the near surface soil layer is a function of the amount of moisture present.
%The SMAP spacecraft carries two instruments, a radar (active) and a radiometer (passive), that together make global measurements of land surface soil moisture and freeze/thaw state. It is useful for monitoring and predicting natural hazards such as floods and droughts, understanding the linkages between Earth�s water, energy and carbon cycles, and reducing uncertainties in predicting weather and climate.
clc
close all
clear all
%% Script to extract data for Gabiley, Somaliland from NASA Worldview & plot against calibrated models

%Section 1 - Loading/Extraction of Data from Sources
%Section 2 - Well 2 Simulation with Calibrated Parameters
%Section 3 - Plotting Well 2 (Calibrated & Uncalibrated)
%Section 4 - Indicators Plot
%Section 5 - Plotting Well 1 (WR)

%% Data Details

%NDVI (July 20th 2017 - Feb 15th 2018)
%SMAP (July 20th 2017 - Feb 15th 2018)
%Daily SPI-3 from Princeton African Drought Monitor (July 20th 2017 - Feb 15th 2018)

%Link - https://worldview.earthdata.nasa.gov/?v=32.4177,4.5139609375,54.9177,15.2190390625&l=MODIS_Aqua_L3_NDVI_16Day,SMAP_L3_Passive_Enhanced_Day_Soil_Moisture,SMAP_L3_Active_Soil_Moisture,Reference_Labels_15m(hidden),Reference_Features_15m(hidden),Coastlines_15m,VIIRS_NOAA20_CorrectedReflectance_TrueColor(hidden),VIIRS_SNPP_CorrectedReflectance_TrueColor(hidden),MODIS_Aqua_CorrectedReflectance_TrueColor(hidden),MODIS_Terra_CorrectedReflectance_TrueColor(hidden)&lg=true&s=43.6677,9.8665&t=2017-02-18-T22%3A00%3A00Z
%Well 2 Coordinates in Arabsiyo Used - 9.687680�S 43.786205�E

%% Section 1 - Extract NDVI & SMAP from NASA Worldview. SPI-3 from Princeton African Drought Monitor (Sheffield et al., 2014)
%NDVI (0-1)

NDVI = [0.235,0.235,0.235,0.235,0.235,0.235,0.235,0.235,0.235,0.235,0.235,0.235,0.235,0.235,0.235,0.235,0.235,0.235,0.235,0.235,0.235,0.235,0.235,0.235,0.235,...
    0.235,0.235,0.235,0.235,0.235,0.235,0.235,0.215,0.215,0.215,0.215,0.215,0.215,0.215,0.215,0.215,0.215,0.215,0.215,0.215,0.215,0.215,0.215,...
    0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.275,0.275,0.275,0.275,0.275,0.275,0.275,0.275,0.275,0.275,0.275,0.275,0.275,0.275,0.275,0.275,...
    0.265,0.265,0.265,0.265,0.265,0.265,0.265,0.265,0.265,0.265,0.265,0.265,0.265,0.265,0.265,0.265,0.270,0.270,0.270,0.270,0.270,0.270,0.270,0.270,0.270,0.270,0.270,0.270,0.270,0.270,0.270,0.270,...
    0.260,0.260,0.260,0.260,0.260,0.260,0.260,0.260,0.260,0.260,0.260,0.260,0.260,0.260,0.260,0.260,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,...
    0.265,0.265,0.265,0.265,0.265,0.265,0.265,0.265,0.265,0.265,0.265,0.265,0.265,0.265,0.265,0.265,0.255,0.255,0.255,0.255,0.255,0.255,0.255,0.255,0.255,0.255,0.255,0.255,0.255,0.255,0.255,0.255,...
    0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,0.245,...
    0.240,0.240,0.240];

%SMAP (0 - >0.6 cm3/cm3)

SMAP = [NaN, 0.104, NaN, NaN, 0.087, NaN, 0.144, NaN, NaN, 0.104, NaN, NaN, 0.076, NaN, 0.097, NaN,NaN,0.170,NaN,NaN,0.162,NaN,0.182,NaN,NaN,...
    0.168,NaN,NaN,0.085,NaN,0.175,NaN,NaN,0.130,NaN, NaN,0.172,NaN,0.241,NaN,NaN,0.177,NaN,NaN,0.220,NaN,0.158,NaN,...
    NaN,0.208,NaN,NaN,0.191,NaN,0.161,NaN,NaN,0.156,NaN,NaN,0.142,NaN,0.206,NaN,NaN,0.146,NaN,NaN,0.118,NaN,0.120,NaN,NaN,0.139,NaN,NaN,0.085,NaN,0.087,NaN,...
    NaN,0.097,NaN,NaN,0.087,NaN,0.076,NaN,NaN,0.087,NaN,NaN,0.073,NaN,0.076,NaN,NaN,0.085,NaN,NaN,0.097,NaN,0.087,NaN,NaN,0.085,NaN,NaN,0.080,NaN,0.085,NaN,...
    NaN,0.097,NaN,NaN,0.080,NaN,0.080,NaN,NaN,0.066,NaN,NaN,0.080,NaN,0.087,NaN,NaN,0.073,NaN,NaN,0.085,NaN,0.076,NaN,NaN,0.076,NaN,NaN,NaN,NaN,0.085,NaN,...
    NaN,0.085,NaN,NaN,0.073,NaN,0.085,NaN,NaN,0.087,NaN,NaN,0.080,NaN,0.087,NaN,NaN,0.073,NaN,NaN,0.080,NaN,0.085,NaN,NaN,0.073,NaN,NaN,0.080,...
    NaN,0.076,NaN,NaN,0.085,NaN,NaN,0.085,NaN,0.087,NaN,NaN,0.085,NaN,NaN,0.085,NaN,0.080,NaN,NaN,0.073,NaN,NaN,0.073,NaN,0.073,NaN,NaN,0.073,NaN,NaN,NaN,...
    NaN,0.087,NaN,NaN,0.080,NaN];

%SPI-3
load spi_2015_20.mat 
spi3 = mean(spi3,1);
spi3 = mean(spi3,2);
spi3 = spi3(:);

%Pre processing for plotting
a=datenum(2018,02,15);
b=datenum(2017,07,20);
X = b:1:a;
date = datetime(X, 'ConvertFrom', 'datenum');
c=datenum(2015,01,01);
spi3index = (b-c); %index to start on in spi3
spi3=spi3(spi3index:(spi3index+length(date)-1));
removeNaN = isnan(SMAP);
date1 = date(removeNaN==0);
SMAP1 = SMAP(removeNaN==0);


%Convert to Percentage for Figure 1 Indicators Plot
NDVIpct = 100*(NDVI-min(NDVI))/(max(NDVI)-min(NDVI));
SMAPpct = 100*(SMAP1-min(SMAP1))/(max(SMAP1)-min(SMAP1));
spi3pct = 100*(spi3-min(spi3))/(max(spi3)-min(spi3));

%Loading up observed data
load abs_nn1.mat

% Load Recharge + Observed Well 2 Data
% Rainfall area of roughly 40 x 40 km
% Evaporation area of roughly 55 x 55 km

%Add Necessary Folders to Path (NOTE: Directory updating on different computer) 
%path

% Load Rainfall Data for Recharge, Load Well Bottle Data for Pumping (from pressure transducer) 
load rainfall_endmay.mat 
load NPD_corr.mat 
% r is rainfall (from TAMSAT)
% ev is actual evaporation (from AFDM VIC hydrologic model)
% r and ev in [mm]
% Well level in [m]
ev_day = ev_day(~isnat(ev_day)); % Removing NaT

% Calculating average rainfall and evaporation
P = mean(r,1);
P = mean(P,2);
P = P(:); % Mean for 1 day
P = P/1000; % convert rainfall to [m]

AE = mean(ev,1);
AE = mean(AE,2);
AE = AE(:); % Mean for 1 day
AE = AE/1000; % convert evap to [m]

% Extracting only peaks of well level
[WBpk.depth,i] = findpeaks(WB.depth);
WBpk.date = WB.date(i);
[WBpk.depth,i] = findpeaks(WBpk.depth);
WBpk.date = WBpk.date(i);

% Extracting relevant rainfall data to match well data range
P = P(r_day>WB.date(1));
r_day = r_day(r_day>WB.date(1));

P = P(r_day<=ev_day(end));

r_day = r_day(r_day<=ev_day(end));

% Extracting relevant evap
AE = AE(ev_day>WB.date(1));
ev_day = ev_day(ev_day>WB.date(1));

% AE = AE(ev_day<WB_pr_date_corr(end));
% ev_day = ev_day(ev_day<WB_pr_date_corr(end));

%Allocate Relevant Pumping Data to Variables to use in Model
stdate = abs.stdate; %First pumping event datetime
enddate = abs.enddate; %Final pumping event datetime
pumpdate = abs.startdate; %Array of datetimes denoting start of each pumping event
pumprate = abs.pumprate; %Array of values denoting rate (m3/day) of each pumping event
pumpdur = abs.pumpdur; %Array of values denoting length (days) of each pumping event
startdata = abs.startdata; %Array of groundwater levels at start of each pumping event
enddata = abs.enddata; %Array of groundwater levels at end of each pumping event



%% Section 2 - AquiMod Simulation for Well 2

%Set Aquifer Parameters from calibration
h0 = 1.9; %from manual; % Initial groundwater level above aquifer base prior to pumping [m]
Sy = 0.0076288; 
k = 9.9825356e-05;
k_wei = 5.1879233;
lambda = 23.382369;
b = 0; %height of base of well above base of aquifer

%run aquimod model (gwm.m)
params=input_params(Sy,h0,k,lambda,k_wei);
[Hg,recharge,qg] = gwm(P,AE,r_day,params);
Hg=Hg(1:length(date));

%Normalise to pct - NOTE observed data needs to be normalised to
%daily maximum values
load('WBpeaks.mat');
WBcaltarg = caltarg;
Hg_pct=100*(Hg-min(Hg))/(max(Hg)-min(Hg));
WB.depthnorm=100*(WB.depth-min(WBcaltarg))/(max(WBcaltarg)-min(WBcaltarg)); %also modifying rest of observed data according to scaling of calibration targets
WBcaltargpct=100*(WBcaltarg-min(WBcaltarg))/(max(WBcaltarg)-min(WBcaltarg));

%Reset Aquifer Parameters to plot uncalibrated AquiMod
h0 = 1.9; %from manual; % Initial groundwater level above aquifer base prior to pumping [m]
Sy = 0.1; %lowest suggested level by Lohmann 
K = 25 ; %k is replaced by hydraulic conductivity K in original model as it uses length and width of aquifer!
k_wei = 3.5;
lambda = 3.5;
b = 0; %height of base of well above base of aquifer

%plot uncalibrated (researched parameter values) AquiMod model
params=input_params_OG(Sy,h0,K,lambda,k_wei);
[Hg_un,recharge,qg] = gwm_OG(P,AE,r_day,params);

%normalized
Hg_un_pct=100*(Hg_un-min(Hg_un))/(max(Hg_un)-min(Hg_un));

%% Section 3 - Plotting Well 2

figure(1)
%Plot regional model with calibrated values
leg1=plot(date,Hg,'-', 'LineWidth', 1.5);
hold on
%Plot regional model with uncalibrated values
leg6 = plot(r_day,Hg_un,'LineWidth', 1.5);
leg2=plot(maxvaltimes,WBcaltarg,'k.', 'MarkerSize', 12);
leg3=plot(WB.date,WB.depth,'k.', 'LineWidth', 1, 'MarkerSize', 1);
xlim([datetime(2017,07,20,00,00,00) datetime(2018,02,15,00,00,00)])
ylabel('Groundwater Level (m)');
ylim([0 8.5]);

line = 0:1:100;
Xaxis = NaT(1,length(line));
T=isnat(Xaxis);
Xaxis(T==1) = date(1,49);
leg5=plot(Xaxis,line,'k--','LineWidth',0.5);
set(gca,'FontSize',16)
lgd=legend([leg1 leg6 leg3 leg2],{'Locally Calibrated Model', 'Uncalibrated Model','Observed Levels', 'Daily Observed Max.'}, 'FontSize', 16)
lgd.Title.String = 'Well 2' ;
lgd.Title.FontSize = 16;

%% Section 4 - Indicators Plot
%Figure 2 - Percentage Plot
figure(2)
leg1=plot(date,spi3pct, 'LineWidth', 1.5)
hold on
leg2=plot(date1,SMAPpct, 'LineWidth', 1.5)
leg3=plot(date,NDVIpct, 'LineWidth', 1.5)
leg4=plot(maxvaltimes,WBcaltargpct,'k--.', 'MarkerSize', 14);
set(gca,'FontSize',16)
ylabel('Normalised Indicators & Groundwater Level (%)')
xlim([datetime(2017,07,20,00,00,00) datetime(2018,02,15,00,00,00)])
lgd = legend([leg1 leg2 leg3 leg4],{'SPI-3','Soil Moisture', 'NDVI', 'Observed Data'}, 'FontSize', 16)

lgd.Title.String = 'Indicators' ;
lgd.Title.FontSize = 16;

%% Section 5 - Plotting Well 1 (WR)
% Load Recharge + Observed Bottle Well Data 
% Rainfall area of roughly 40 x 40 km
% Evaporation area of roughly 55 x 55 km

%Add Necessary Folders to Path (NOTE: Directory updating on different computer) 
%path

% Load Rainfall Data for Recharge, Load Well Bottle Data for Pumping (from pressure transducer) 
load rainfall_endmay.mat 
load NPD_corr.mat 
% r is rainfall (from TAMSAT)
% ev is evaporation (from AFDM VIC hydrologic model)
% r and ev in [mm]
% Well level in [m]
ev_day = ev_day(~isnat(ev_day)); % Removing NaT

% Calculating average rainfall and evaporation
P = mean(r,1);
P = mean(P,2);
P = P(:); % Mean for 1 day
P = P/1000; % convert rainfall to [m]

AE = mean(ev,1);
AE = mean(AE,2);
AE = AE(:); % Mean for 1 day
AE = AE/1000; % convert evap to [m]

% Extracting only peaks of well level
[WRpk.depth,i] = findpeaks(WR.depth);
WRpk.date = WR.date(i);
[WRpk.depth,i] = findpeaks(WRpk.depth);
WRpk.date = WRpk.date(i);

% Extracting relevant rainfall data to match well data range
P = P(r_day>WR.date(1));
r_day = r_day(r_day>WR.date(1));

P = P(r_day<=ev_day(end));

r_day = r_day(r_day<=ev_day(end));

% Extracting relevant evap
AE = AE(ev_day>WR.date(1));
ev_day = ev_day(ev_day>WR.date(1));

% AE = AE(ev_day<WB_pr_date_corr(end));
% ev_day = ev_day(ev_day<WB_pr_date_corr(end));

%% Load Pumping Data saved from genpump.m file 
load abs_nn1WR.mat
%Allocate Relevant Pumping Data to Variables to use in Model
stdate = abs.stdate;
enddate = abs.enddate;
pumpdate = abs.startdate;
pumprate = abs.pumprate;
pumpdur = abs.pumpdur;
startdata = abs.startdata;
enddata = abs.enddata;


%% Regional Model WR

%Set Aquifer Parameters from calibration
h0 = 1.13; %from manual; % Initial groundwater level above aquifer base prior to pumping [m]
Sy = 0.0751473; 
k = 0.00076429414;
k_wei = 3.8228205;
lambda = 19.089578;
b = 0; %height of base of well above base of aquifer

params=input_params(Sy,h0,k,lambda,k_wei);
[Hg,recharge,qg] = gwm(P,AE,r_day,params);
Hg=Hg(1:length(date));

%normalise to pct - NOTE observed data needs to be normalised to
%daily maximum values
load('WRpeaks.mat');
WRcaltarg = caltarg

Hg_pct=100*(Hg-min(Hg))/(max(Hg)-min(Hg));
WR.depthnorm=100*(WR.depth-min(WRcaltarg))/(max(WRcaltarg)-min(WRcaltarg)); %also modifying rest of observed data according to scaling of calibration targets
plot(date,Hg,'-k', 'LineWidth', 1.5)
WRcaltargpct=100*(WRcaltarg-min(WRcaltarg))/(max(WRcaltarg)-min(WRcaltarg));

% calibration line and bottom-out line
Z = zeros(1,length(date));
leg4=plot(date,Z,'k--','LineWidth',0.5);

line = 0:1:100;
Xaxis = NaT(1,length(line));
T=isnat(Xaxis);
Xaxis(T==1) = date(1,49);
leg5=plot(Xaxis,line,'k--','LineWidth',0.5);

%Reset Aquifer Parameters to plot uncalibrated AquiMod
h0 = 1.16; %from manual; % Initial groundwater level above aquifer base prior to pumping [m]
Sy = 0.1; %lowest suggested level by Lohmann 
K = 25; %k is replaced by hydraulic conductivity K in original model as it uses length and width of aquifer!
k_wei = 3.5;
lambda = 3.5;
b = 0; %height of base of well above base of aquifer

%plot uncalibrated (researched parameter values) AquiMod model
params=input_params_OG(Sy,h0,K,lambda,k_wei);
[Hg_un,recharge,qg] = gwm_OG(P,AE,r_day,params);
Hg_un_pct=100*(Hg_un-min(Hg_un))/(max(Hg_un)-min(Hg_un));

figure(3)
leg1=plot(date,Hg,'-', 'LineWidth', 1.5)
hold on

%Plot regional model with calibrated values
leg6 = plot(r_day,Hg_un,'LineWidth', 1.5)

leg2=plot(maxvaltimes,WRcaltarg,'k.', 'MarkerSize', 12);

leg3=plot(WR.date,WR.depth,'k.', 'LineWidth', 1, 'MarkerSize', 1);
xlim([datetime(2017,07,20,00,00,00) datetime(2018,02,15,00,00,00)])
ylabel('Groundwater Level (m)');
ylim([0 2]);

line = 0:1:100;
Xaxis = NaT(1,length(line));
T=isnat(Xaxis);
Xaxis(T==1) = date(1,49);
leg5=plot(Xaxis,line,'k--','LineWidth',0.5);
set(gca,'FontSize',16)
lgd=legend([leg1 leg6 leg3 leg2],{'Locally Calibrated Model', 'Uncalibrated Model','Observed Levels', 'Daily Observed Max.'}, 'FontSize', 16)
lgd.Title.String = 'Well 1' ;
lgd.Title.FontSize = 16;
%% Section 2 - Plotting Well 3 (WC)

figure(4)
%% Load Recharge + Observed Bottle Well Data 
% Rainfall area of roughly 40 x 40 km
% Evaporation area of roughly 55 x 55 km

%Add Necessary Folders to Path (NOTE: Directory updating on different computer) 
%path

% Load Rainfall Data for Recharge, Load Well Bottle Data for Pumping (from pressure transducer) 
load rainfall_endmay.mat 
load NPD_corr.mat 
% r is rainfall (from TAMSAT)
% ev is evaporation (from AFDM VIC hydrologic model)
% r and ev in [mm]
% Well level in [m]
ev_day = ev_day(~isnat(ev_day)); % Removing NaT

% Calculating average rainfall and evaporation
P = mean(r,1);
P = mean(P,2);
P = P(:); % Mean for 1 day
P = P/1000; % convert rainfall to [m]

AE = mean(ev,1);
AE = mean(AE,2);
AE = AE(:); % Mean for 1 day
AE = AE/1000; % convert evap to [m]

% Extracting only peaks of well level
[WCpk.depth,i] = findpeaks(WC.depth);
WCpk.date = WC.date(i);
[WCpk.depth,i] = findpeaks(WCpk.depth);
WCpk.date = WCpk.date(i);

% Extracting relevant rainfall data to match well data range
P = P(r_day>WC.date(1));
r_day = r_day(r_day>WC.date(1));

P = P(r_day<=ev_day(end));

r_day = r_day(r_day<=ev_day(end));

% Extracting relevant evap
AE = AE(ev_day>WC.date(1));
ev_day = ev_day(ev_day>WC.date(1));

% AE = AE(ev_day<WB_pr_date_corr(end));
% ev_day = ev_day(ev_day<WB_pr_date_corr(end));


%% Load Pumping Data saved from genpump.m file 
load abs_nn1WC.mat

%Allocate Relevant Pumping Data to Variables to use in Model
stdate = abs.stdate;
enddate = abs.enddate;
pumpdate = abs.startdate;
pumprate = abs.pumprate;
pumpdur = abs.pumpdur;
startdata = abs.startdata;
enddata = abs.enddata;

%CORRECTION FIRST
WC.depth = WC.depth-1;

%% Regional Model WC

%Set Aquifer Parameters from calibration
h0 = 1.9; %from manual; % Initial groundwater level above aquifer base prior to pumping [m]
Sy = 0.0336242; 
k = 0.00027631220;
k_wei = 19.741250;
lambda = 13.701575;
b = 0; %height of base of well above base of aquifer

params=input_params(Sy,h0,k,lambda,k_wei);
[Hg,recharge,qg] = gwm(P,AE,r_day,params);
Hg=Hg(1:length(date));

%normalise to pct - NOTE observed data needs to be normalised to
%daily maximum values
load('WCpeaks.mat');
WCcaltarg = caltarg;

Hg_pct=100*(Hg-min(Hg))/(max(Hg)-min(Hg));
WC.depthnorm=100*(WC.depth-min(WCcaltarg))/(max(WCcaltarg)-min(WCcaltarg)); %also modifying rest of observed data according to scaling of calibration targets
WCcaltargpct=100*(WCcaltarg-min(WCcaltarg))/(max(WCcaltarg)-min(WCcaltarg));

%calibration line and bottom-out line
Z = zeros(1,length(date));
line = 0:1:100;
Xaxis = NaT(1,length(line));
T=isnat(Xaxis);
Xaxis(T==1) = date(1,43);

%UNCALIBRATED
h0 = 1.65; %from manual; % Initial groundwater level above aquifer base prior to pumping [m]
Sy = 0.1; %lowest suggested level by Lohmann 
K = 25; %k is replaced by hydraulic conductivity K in original model as it uses length and width of aquifer!
k_wei = 3.5;
lambda = 3.5;
b = 0; %height of base of well above base of aquifer

%plot uncalibrated (researched parameter values) AquiMod model
params=input_params_OG(Sy,h0,K,lambda,k_wei);
[Hg_un,recharge,qg] = gwm_OG(P,AE,r_day,params);
Hg_un_pct=100*(Hg_un-min(Hg_un))/(max(Hg_un)-min(Hg_un));

%normalise to pct - NOTE observed data needs to be normalised to
%daily maximum values
load('WCpeaks.mat');
%Set Aquifer Parameters from calibration
Hg=Hg(1:length(date));

leg1=plot(date,Hg,'-', 'LineWidth', 1.5)
hold on


%Plot regional model with calibrated values
leg6 = plot(r_day,Hg_un,'LineWidth', 1.5)


leg2=plot(maxvaltimes,WCcaltarg,'k.', 'MarkerSize', 12);

leg3=plot(WC.date,WC.depth,'k.', 'LineWidth', 1, 'MarkerSize', 1);
xlim([datetime(2017,08,07,00,00,00) datetime(2018,02,15,00,00,00)])
ylabel('Groundwater Level (m)');
ylim([0 3.5]);

line = 0:1:100;
Xaxis = NaT(1,length(line));
T=isnat(Xaxis);
Xaxis(T==1) = date(1,49);
leg5=plot(Xaxis,line,'k--','LineWidth',0.5);
set(gca,'FontSize',16)
lgd=legend([leg1 leg6 leg3 leg2],{'Locally Calibrated Model', 'Uncalibrated Model','Observed Levels', 'Daily Observed Max.'}, 'FontSize', 16)
lgd.Title.String = 'Well 3' ;
lgd.Title.FontSize = 16;









%% Input parameters function
function params=input_params(Sy,h0,k,lambda,k_wei)
% Refer to gwm.m for parameter details
% All Units in [m] unless stated otherwise
params.Sy = Sy; % [no units]
params.k = k; % [1/day] # Changed to final value from Rae's report on page 26.
params.SM_max = 0.005;
params.Hg_min = 0; % Outflow base about aquifer base 
params.SM_i = 0;
params.Hg_i = h0;
params.k_wei = k_wei; % controls the density of function around peak
params.lambda = lambda; % controls the location of the peak
end


%% Input parameters function for uncalibrated AquiMod
function params=input_params_OG(Sy,h0,K,lambda,k_wei)
% Refer to gwm.m for parameter details
% All Units in [m] unless stated otherwise
params.Sy = Sy; % [no units]
params.K = K; % [1/day] # Changed to final value from Rae's report on page 26.
params.SM_max = 0.005;
params.Hg_min = 0; % Outflow base about aquifer base 
params.SM_i = 0;
params.Hg_i = h0;
params.k_wei = k_wei; % controls the density of function around peak
params.lambda = lambda; % controls the location of the peak
end






