%% Somaliland SAFE Post Processing WB

% Files:

%workflow_somaliland.m runs the generation of matrix Y outputs, after
%sampling input matrix X 

%WV_Veness_AB_SAFE_Cal.m runs the model as a function called by the
%workflow files

%Somaliland_PostProcessing_WB loads Matrix Y and performs post-processing
%against the observed data set

clear all
close all
clc
%% Load Matrices X and Y
load('Y10000WBRegShortRMSE.mat') %variable hw_SAFE
load('X10000WBRegShortRMSE.mat') %variable X

X_Labels = {'Sy', 'Tau', 'k(Weibull)', 'lambda'};
M = length(X_Labels);
N = length(hw_SAFE(:,1));

%% Load Recharge + Observed Bottle Well Data From Rae's Handover
% Rainfall area of roughly 40 x 40 km
% Evaporation area of roughly 55 x 55 km

%Add Necessary Folders to Path (NOTE: Directory updating on different computer) 
%path

% Load Rainfall Data for Recharge, Load Well Bottle Data for Pumping (from pressure transducer) 
load rainfall_endmay.mat 
load NPD_corr.mat 
% r is rainfall (from TAMSAT)
% ev is evaporation (from AFDM VIC hydrologic model)
% r and ev in [mm]
% Well level in [m]
ev_day = ev_day(~isnat(ev_day)); % Removing NaT

% Calculating average rainfall and evaporation
P = mean(r,1);
P = mean(P,2);
P = P(:); % Mean for 1 day
P = P/1000; % convert rainfall to [m]

AE = mean(ev,1);
AE = mean(AE,2);
AE = AE(:); % Mean for 1 day
AE = AE/1000; % convert evap to [m]

% Extracting only peaks of well level
[WBpk.depth,i] = findpeaks(WB.depth);
WBpk.date = WB.date(i);
[WBpk.depth,i] = findpeaks(WBpk.depth);
WBpk.date = WBpk.date(i);

% Extracting relevant rainfall data to match well data range
P = P(r_day>WB.date(1));
r_day = r_day(r_day>WB.date(1));

P = P(r_day<=ev_day(end));

r_day = r_day(r_day<=ev_day(end));

% Extracting relevant evap
AE = AE(ev_day>WB.date(1));
ev_day = ev_day(ev_day>WB.date(1));

% AE = AE(ev_day<WB_pr_date_corr(end));
% ev_day = ev_day(ev_day<WB_pr_date_corr(end));

%% Load Pumping Data saved from genpump.m file 
%(which originally inputted to geninput1.m for SPIDERR model):
load abs_nn1.mat

%Allocate Relevant Pumping Data to Variables to use in Model
stdate = abs.stdate;
enddate = abs.enddate;
pumpdate = abs.startdate; %start of each pumping event
pumpend = abs.enddate; %end of each pumping event
pumprate = abs.pumprate;
pumpdur = abs.pumpdur;

%load also the data at start and end of each pumping event
startdata = abs.startdata;
enddata = abs.enddata;

B = 0; %height of pump above aquifer base (sitting 1 m above well base so model doesn't collapse when h --> 11.5

%CORRECT HEIGHT OF STARTDATA TO HEIGHT ABOVE AQUIFER
startdata = startdata+B;
enddata = enddata+B;

%abs.startdata and abs.enddata not needed as rate and duration
%already have been calculated in genpump.m

%clear abs to enable the abs() function later in script
clear abs
%% Plot Observed WB Data 
figure(1)
plot(WB.date,WB.depth+B,'k.-');
title('Observed Well Head vs Time')
xlabel('Time [days]')
ylabel('Head [m]')

%% Post Processing Manual

warmup = 0 ; % warmup period to be discarded (first 30 peaks/troughs)

%Model results recording relevant peaks and troughs (starts with a peak at
%start of first pumping event then alternates trough-peak-trough-peak, with
%end = peak)
Hw = hw_SAFE(:, warmup+1:end); 

length(Hw(1,:))
% length(startdata)
% length(enddata)

% %Observed Data unpacking peaks and troughs only - obs vector alternates
% obs = startdata(:)';
% obs = obs(:); %column vec
% %MAKE SURE DUPLICATE ADDITION ABOVE WELL BASE ISN'T HERE FOR OTHER WELLS 
% 
% %clip obs
% obs = obs(warmup+1:end);
% length(obs) %does not need to be the same length as Hw. Loop below sorts
% obs=obs';

% daycount = 1;
% %open vector for storage
% calibheight = zeros(1,length(obs));
% i = 1;
% newobs = obs;
% p=1; %Pumpdate counter
% 
% %HEIGHT TO MINIMISE TO FROM MANUAL CAL
% Z = 0;
% 
% while i <= length(obs)
%     if floor(datenum(pumpdate(p))) == floor(datenum(r_day(daycount))) %if still the same day
%         if calibheight(daycount) == 0 %and if there has been no observation on this day yet
%             calibheight(daycount) = obs(i) + Z; %add 1 m for now while setting up (but later use mean of manual calibration to work this out) - this is the height to calibrate to on that day
%         else
%             if obs(i) > calibheight(daycount)-Z %only replace if there is a bigger value on that day (retains highest head pumping event)
%            calibheight(daycount) = obs(i) + Z; %replace
%             end
%         end
%     else
%         
%         daycount = daycount + (floor(datenum(pumpdate(p)))-floor(datenum(r_day(daycount)))); %add number of days elapsed
%         
%         if calibheight(daycount) == 0
%             calibheight(daycount) = obs(i) + Z;
%         end
%     end
%     i=i+1;
%     p=p+1;
% end
% 
% calibheight = calibheight(calibheight>0); %remove extra data from the end where no pumping data exists
% %calibheight is the vector of heads that the regional model is aiming to
% %minimise to
% 


   
% %run minimising objective functions using Root Mean Squared Error (RMSE)
% RMSE = zeros(1,10000);
% % BIAS = zeros(1,10000);
% for i = 1:10000
%     
% RMSE(i) = sqrt(mean((Hw(i,:) - obs).^2));  % RMSE
% BIAS(i) = abs(mean(Hw(i,:) - obs))       ; % BIAS
% end
% RMSE;
% BIAS;

load('WBpeaks.mat')
calibheight7wk = caltarg(1:49); %caltarg from WBpeaks
Hw_calib = hw_SAFE(:, 1:length(maxvaltimes));%maxvaltimes corresponding times to max heads daily
Hw_calib7wk = Hw_calib(:,1:49);


%% MultiObj Fcn from Ochoa-Tocachi et al.(2019)
disp('MULTIOBJECTIVE SETUP AND REGIONAL SENSITIVITY ANALYSIS')

% Statistics
% hydro_nse = NSE(Hw_calib7wk,calibheight7wk); %may need transpose
% hydro_pbias = PBIAS(Hw_calib7wk,calibheight7wk);
hydro_rmse = RMSE(Hw_calib7wk,calibheight7wk);
% hydro_kge = KGE(Hw_calib,obs);
% Transformed objectives for minimisation
%hydro_RMSEmod = 1 - (hydro_rmse); % 1-NSE to minimise
% hydro_PBIASmod = abs(hydro_pbias); % abs(PBIAS) to minimise
% hydro_KGEmod = 1 - (hydro_kge); % 1-KGE to minimise

% Visualize input/output samples (this may help finding a reasonable value
% for the output threshold):
 figure; scatter_plots(X,hydro_rmse,[],'RMSE',X_Labels);
% figure; scatter_plots(X,hydro_pbias,[],'PBIAS',X_Labels);
% figure; scatter_plots(X,hydro_kge,[],'KGE',X_Labels);

% Set user-defined output thresholds
% nse_thres = 0.7; % behavioural threshold for NSE
% pbias_thres = 5; % behavioural threshold for PBIAS
% kge_thres = 0.8; % % behavioural threshold for KGE, or same as NSE

% OR: Define the thresholds from the best values of each Obj
hydro_rmse_sortindx = [];% hydro_pbias_sortindx = []; %hydro_kge_sortindx = [];
[hydro_rmse_sortindx(:,1),hydro_rmse_sortindx(:,2)] = sort(hydro_rmse);
%[hydro_pbias_sortindx(:,1),hydro_pbias_sortindx(:,2)] = sort(hydro_PBIASmod);
% [hydro_kge_sortindx(:,1),hydro_kge_sortindx(:,2)] = sort(hydro_KGEmod);
% Extract thresholdsmvd
hydro_rmse_thres = hydro_rmse_sortindx(ceil(N*0.05));
%hydro_pbias_thres = abs(hydro_pbias_sortindx(ceil(N*0.05)));
% hydro_kge_thres = 1-hydro_kge_sortindx(ceil(N*0.05));

% Best fit using criteria:
% NSE
hydro_rmse_sortset = X(hydro_rmse_sortindx(:,2),:);
hydro_rmse_bestObj = [hydro_rmse(hydro_rmse_sortindx(1,2),:)];
% PBIAS
%hydro_pbias_sortset = X(hydro_pbias_sortindx(:,2),:);
%hydro_pbias_bestObj = [hydro_nse(hydro_pbias_sortindx(1,2),:) hydro_pbias(hydro_pbias_sortindx(1,2),:)];
% KGE
% hydro_kge_sortset = X(hydro_kge_sortindx(:,2),:);
% hydro_kge_bestObj = [hydro_nse(hydro_kge_sortindx(1,2),:) hydro_pbias(hydro_kge_sortindx(1,2),:) hydro_kge(hydro_kge_sortindx(1,2),:)];
% MULTI
% Normalise the objectives
hydro_RMSEnorm   = (hydro_rmse-min(hydro_rmse))/(max(hydro_rmse)-min(hydro_rmse));
%hydro_PBIASnorm = (hydro_PBIASmod-min(hydro_PBIASmod))/(max(hydro_PBIASmod)-min(hydro_PBIASmod));
% hydro_KGEnorm = (hydro_KGEmod-min(hydro_KGEmod))/(max(hydro_KGEmod)-min(hydro_KGEmod));
% hydro_multi = hydro_RMSEnorm; %CALCULATE MULTIOBJ FCN
% % Best fit using Multi criteria
% hydro_multi_sortindx = [];
% [hydro_multi_sortindx(:,1),hydro_multi_sortindx(:,2)] = sort(hydro_multi);
%Will = sort(hydro_multi);
% hydro_multi_sortset = X(hydro_multi_sortindx(:,2),:); %SORTED LIST OF PARAMETER COMBINATIONS FROM BEST TO WORST
% hydro_multi_bestObj = [hydro_rmse(hydro_multi_sortindx(1,2),:)]; %VALUE OF EACH OF THE OBJS FOR BEST PARAMETERS

%figure; scatter_plots(X,hydro_multi,[],'MultiObj',X_Labels);

% % Simulations that comply with Moriasi et al. (2007) recommendations
% hydro_M2007 = hydro_rmse>0.5; % location
% hydro_M2007n = 100*sum(hydro_M2007)/N; % percentage

disp('Done'); disp(' ')
%% 7. RSA USING NSE, PBIAS, AND KGE AS OBJECTIVE FUNCTIONS
disp('RSA USING NSE, PBIAS, AND KGE AS OBJECTIVE FUNCTIONS')

% RSA (find behavioural parameterizations):
hydro_threshold = [hydro_rmse_thres];
[hydro_mvd_rsa,hydro_idxb_rsa] = RSA_indices_thres(X,[hydro_rmse],hydro_threshold);
hydro_Xbeh = X(hydro_idxb_rsa,:);

hydro_top5n = 100*sum(hydro_idxb_rsa)/N; % percentage of top 5% behavioural

% % Highlight the behavioural parameterizations in the scatter plots:
% figure; scatter_plots(X,hydro_rmse,[],'RMSE',X_Labels,hydro_idxb_rsa);
% for i=1:M
%     subplot(ceil(M/5),5,i)
%     plot(hydro_rmse_sortset(1,i),hydro_rmse_bestObj(1),'vk','MarkerSize',10,'MarkerFaceColor',0.8*[1 1 1])
%     %plot(hydro_pbias_sortset(1,i),hydro_pbias_bestObj(1),'^k','MarkerSize',10,'MarkerFaceColor',0.8*[1 1 1])
% %     plot(hydro_kge_sortset(1,i),hydro_kge_bestObj(1),'sk','MarkerSize',10,'MarkerFaceColor',0.8*[1 1 1])
%     %plot(hydro_multi_sortset(1,i),hydro_multi_bestObj(1),'ok','MarkerSize',10,'MarkerFaceColor',0.8*[1 1 1])
% end
% legend('Parameter population','Better than threshold','Best NSE set','Best PBIAS set','Best KGE set')

% figure; scatter_plots(X,hydro_pbias,[],'PBIAS',X_Labels,hydro_idxb_rsa);
% for i=1:M
%     subplot(ceil(M/5),5,i)
%     plot(hydro_nse_sortset(1,i),hydro_nse_bestObj(2),'vk','MarkerSize',10,'MarkerFaceColor',0.6*[1 1 1])
%     plot(hydro_pbias_sortset(1,i),hydro_pbias_bestObj(2),'^k','MarkerSize',10,'MarkerFaceColor',0.7*[1 1 1])
% %     plot(hydro_kge_sortset(1,i),hydro_kge_bestObj(2),'sk','MarkerSize',10,'MarkerFaceColor',0.8*[1 1 1])
%     plot(hydro_multi_sortset(1,i),hydro_multi_bestObj(2),'ok','MarkerSize',10,'MarkerFaceColor',0.8*[1 1 1])
% end
% legend('Parameter population','Better than threshold','Best NSE set','Best PBIAS set','Best KGE set')

% figure; scatter_plots(X,hydro_kge,[],'KGE',X_Labels,hydro_idxb_rsa);
% for i=1:M
%     subplot(ceil(M/5),5,i)
%     plot(hydro_nse_sortset(1,i),hydro_nse_bestObj(3),'vk','MarkerSize',10,'MarkerFaceColor',0.6*[1 1 1])
%     plot(hydro_pbias_sortset(1,i),hydro_pbias_bestObj(3),'^k','MarkerSize',10,'MarkerFaceColor',0.7*[1 1 1])
%     plot(hydro_kge_sortset(1,i),hydro_kge_bestObj(3),'sk','MarkerSize',10,'MarkerFaceColor',0.8*[1 1 1])
%     plot(hydro_multi_sortset(1,i),hydro_multi_bestObj(3),'ok','MarkerSize',10,'MarkerFaceColor',0.8*[1 1 1])
% end
% legend('Parameter population','Better than threshold','Best NSE set','Best PBIAS set','Best KGE set','Best set overall')

% Plot parameter CDFs:
[xx,CDFb,CDFnb]=RSA_plot_thres(X,hydro_idxb_rsa,[],X_Labels,{'behavioural','non-behavioural'}); % add legend
save('WB7wkRMSEcdf_rd1redo.mat','xx', 'CDFb', 'CDFnb')


disp('Done'); disp(' ')
% %% 8. SENSITIVITY INDICES (MVD) USING NSE, PBIAS, AND KGE
% disp('SENSITIVITY INDICES (MVD) USING NSE, PBIAS, AND KGE')
% 
% mvd: maximum vertical distance between parameters CDFs

% Assess robustness by bootstrapping:
% Nboot = 100;
% [hydro_mvd,hydro_idxb,hydro_mvd_lb,hydro_mvd_ub] = RSA_indices_thres(X,[hydro_rmse],hydro_threshold,1,Nboot);
% %[hydro_spread,~,hydro_spread_lb,hydro_spread_ub] = RSA_indices_thres(X,[hydro_rmse],hydro_threshold,2,Nboot);
% % Plot results:
% figure; boxplot1(hydro_mvd,X_Labels,'mvd',hydro_mvd_lb,hydro_mvd_ub)
% %figure; boxplot1(hydro_spread,X_Labels,'spread',hydro_spread_lb,hydro_spread_ub)
% set(gca,'YLimMode','auto')
% % 
% disp('Done'); disp(' ')

% % 9. SCATTER PLOT BETWEEN NSE AND PBIAS
% disp('SCATTER PLOT BETWEEN NSE AND PBIAS')
% 
% figure
% Plot all simulations:
% a = plot(hydro_nse,hydro_pbias,'o','MarkerSize',3,'Color',[.5 .5 .5]);
% hold on
% b = plot(hydro_nse(hydro_idxb_rsa),hydro_pbias(hydro_idxb_rsa),'ok','MarkerSize',3,'MarkerFaceColor','k');
% Threshold
% c = plot([hydro_nse_thres hydro_nse_thres],hydro_pbias_thres*[-1 1],'--k');
% plot([hydro_nse_thres 1],[hydro_pbias_thres hydro_pbias_thres],'--k');
% plot([hydro_nse_thres 1],-1*[hydro_pbias_thres hydro_pbias_thres],'--k');
% Plot best predictions:
% d = plot(hydro_nse_bestObj(1),hydro_nse_bestObj(2),'vk','MarkerSize',10,'MarkerFaceColor',0.8*[1 1 1]);
% e = plot(hydro_pbias_bestObj(1),hydro_pbias_bestObj(2),'^k','MarkerSize',10,'MarkerFaceColor',0.8*[1 1 1]);
% f = plot(hydro_kge_bestObj(1),hydro_kge_bestObj(2),'sk','MarkerSize',10,'MarkerFaceColor',0.8*[1 1 1]);
% g = plot(hydro_multi_bestObj(1),hydro_multi_bestObj(2),'ok','MarkerSize',10,'MarkerFaceColor',0.8*[1 1 1]);
% Manual optima
% h = plot(manual_hydro_nse(1),manual_hydro_pbias(1),'xk','MarkerSize',10);
% text(manual_hydro_nse(1),manual_hydro_pbias(1),'  Engda et al. (2012)')
% plot(manual_hydro_nse(2),manual_hydro_pbias(2),'xk','MarkerSize',10)
% text(manual_hydro_nse(2),manual_hydro_pbias(2),'  Tilahun et al. (2013a, 2013b)')
% plot(manual_hydro_nse(3),manual_hydro_pbias(3),'xk','MarkerSize',10)
% text(manual_hydro_nse(3),manual_hydro_pbias(3),'  Guzman et al. (2017b)')
% Customise plot
% % set(gca,'XLim',[0.5 1],'YLim',[-15 15],'XTick',(0:0.05:1),'YTick',(-50:10:50))
% set(gca,'FontName','Helvetica','FontSize',12)
% xlabel('NSE [-]'); ylabel('PBIAS [%]')
% title('Multi-Objective Parameter Optimisation')
% box on
% grid on
% grid minor
% legend('location','northeast')
% legend([a b c d e g],'Parameter population','Better than threshold','Threshold','Best NSE set','Best PBIAS set','Best set overall')
% legend('boxoff')
% clear a b c d e f g h
% legend('off')

%% Validation Procedure

Hw_val = Hw_calib(:,50:end);
valheight = caltarg(50:end);

disp('MULTIOBJECTIVE SETUP FOR VALIDATION')

%manual values if top parameter set already noted...

% Statistics
hydro_rmse_val = RMSE(Hw_val,valheight); %may need transpose
% hydro_pbias = PBIAS(Hw_val,valheight);
% hydro_kge = KGE(Hw_calib,obs);
% Transformed objectives for minimisation
hydro_RMSEmod = 1 - (hydro_rmse); % 1-NSE to minimise
% hydro_PBIASmod = abs(hydro_pbias); % abs(PBIAS) to minimise
% hydro_KGEmod = 1 - (hydro_kge); % 1-KGE to minimise

% Visualize input/output samples (this may help finding a reasonable value
% for the output threshold):
% figure; scatter_plots(X,hydro_nse,[],'NSE',X_Labels);
% figure; scatter_plots(X,hydro_pbias,[],'PBIAS',X_Labels);
% figure; scatter_plots(X,hydro_kge,[],'KGE',X_Labels);

% Set user-defined output thresholds
% nse_thres = 0.7; % behavioural threshold for NSE
% pbias_thres = 5; % behavioural threshold for PBIAS
% kge_thres = 0.8; % % behavioural threshold for KGE, or same as NSE

% OR: Define the thresholds from the best values of each Obj
hydro_rmse_sortindx_val = []; %hydro_pbias_sortindx_val = []; %hydro_kge_sortindx = [];
[hydro_rmse_sortindx_val(:,1),hydro_rmse_sortindx_val(:,2)] = sort(hydro_rmse_val);
% [hydro_pbias_sortindx_val(:,1),hydro_pbias_sortindx_val(:,2)] = sort(hydro_PBIASmod);
% [hydro_kge_sortindx(:,1),hydro_kge_sortindx(:,2)] = sort(hydro_KGEmod);
% Extract thresholds
hydro_rmse_thres_val = hydro_rmse_sortindx_val(ceil(N*0.05));
%hydro_pbias_thres_val = abs(hydro_pbias_sortindx_val(ceil(N*0.05)));
% hydro_kge_thres = 1-hydro_kge_sortindx(ceil(N*0.05));

% Best fit using criteria:
% NSE
hydro_rmse_sortset_val = X(hydro_rmse_sortindx_val(:,2),:);
hydro_rmse_bestObj_val = [hydro_rmse(hydro_rmse_sortindx_val(1,2),:)];






% PBIAS
% hydro_pbias_sortset_val = X(hydro_pbias_sortindx_val(:,2),:);
% hydro_pbias_bestObj_val = [hydro_nse(hydro_pbias_sortindx_val(1,2),:) hydro_pbias(hydro_pbias_sortindx_val(1,2),:)];
% KGE
% hydro_kge_sortset = X(hydro_kge_sortindx(:,2),:);
% hydro_kge_bestObj = [hydro_nse(hydro_kge_sortindx(1,2),:) hydro_pbias(hydro_kge_sortindx(1,2),:) hydro_kge(hydro_kge_sortindx(1,2),:)];
% MULTI
% Normalise the objectives;
% hydro_PBIASnorm = (hydro_PBIASmod-min(hydro_PBIASmod))/(max(hydro_PBIASmod)-min(hydro_PBIASmod));
% hydro_KGEnorm = (hydro_KGEmod-min(hydro_KGEmod))/(max(hydro_KGEmod)-min(hydro_KGEmod));
%hydro_multi_val = sqrt(hydro_NSEnorm.^2 + hydro_PBIASnorm.^2); %CALCULATE MULTIOBJ FCN
% Best fit using Multi criteria
%hydro_multi_sortindx_val = [];
% [hydro_multi_sortindx_val(:,1),hydro_multi_sortindx_val(:,2)] = sort(hydro_multi_val);
% Will = sort(hydro_multi_val);
% hydro_multi_sortset_val = X(hydro_multi_sortindx_val(:,2),:); %SORTED LIST OF PARAMETER COMBINATIONS FROM BEST TO WORST
% hydro_multi_bestObj_val = [hydro_nse(hydro_multi_sortindx_val(1,2),:) hydro_pbias(hydro_multi_sortindx_val(1,2),:)]; %VALUE OF EACH OF THE OBJS FOR BEST PARAMETERS




%--------------------------------------------------------







% %% 10. PLOT BEST PARAMETER SET
% % Numerical Model for 2017/18 Somaliland Data
% 
% %This file loads pumping and rainfall data from Somaliland 21st July 2017 -
% %15th Feb 2018, and runs a numerical model of 1D transient radial flow that
% %models drawdown over this period of time. 
% %ODE15s is used to solve the function efficiently.
% 
% %Clear Workspace
% clc
% close all
% clear all
% 
% 
% %% Parameters and logarithmic node creation
% 
% %Set Aquifer Parameters
% Th = 20; %total aquifer thickness
% h0 = 15.5; % Initial groundwater level above aquifer base prior to pumping [m]
% K = 0.118716810766630; % Hydraulic conductivity [m]
% T = K*h0;
% Sy = 0.0122902531818716; % From Rae's report page 26.
% S = Sy;
% k = 8.60085746804029e-05;
% b = 11; %height of base of well above base of aquifer
% 
% %Set Geometric Radial Distance of Nodes
% rw = 1.0; % well radius [m]
% Rmin = rw; % location of first node from well centre [m]
% Rmax = 250; % maximum radius [m]
% n = 50; % number of radial nodes
% log_base = 1.01; %set base of log for node spacing
% 
% %set logarithmic spacing of 'n' nodes. [Rmin, 1.005, ...., Rmax] 
% %note: uses log rule of division to set the base
% rad = [log_base.^(linspace(log(Rmin)/log(log_base),log(Rmax)/log(log_base),n))]
% 
% %Alternative radial spacing (less logarithmic)
% % rad = zeros(1,n);
% % rad(1) = Rmin;
% % rad(end) = Rmax;
% % Rholder = linspace(Rmin,Rmax,n);
% % for R = 2:n-1
% %     rad(R) = Rholder(R)*(R/n)+1;
% % end
% 
% %Calculate Area of Each Annulus for Recharge
% area = zeros(1,length(rad));
% %area of well
% area(1) = pi*Rmin^2;
% %other annulus areas
% for a = 2:length(rad)
%     area(a) = pi*rad(a)^2 - area(a-1);
% end
% 
% %% Load Recharge + Observed Bottle Well Data From Rae's Handover
% % Rainfall area of roughly 40 x 40 km
% % Evaporation area of roughly 55 x 55 km
% 
% %Add Necessary Folders to Path (NOTE: Directory updating on different computer) 
% %path
% 
% % Load Rainfall Data for Recharge, Load Well Bottle Data for Pumping (from pressure transducer) 
% load rainfall_endmay.mat 
% load NPD_corr.mat 
% % r is rainfall (from TAMSAT)
% % ev is evaporation (from AFDM VIC hydrologic model)
% % r and ev in [mm]
% % Well level in [m]
% ev_day = ev_day(~isnat(ev_day)); % Removing NaT
% 
% % Calculating average rainfall and evaporation
% P = mean(r,1);
% P = mean(P,2);
% P = P(:); % Mean for 1 day
% P = P/1000; % convert rainfall to [m]
% 
% AE = mean(ev,1);
% AE = mean(AE,2);
% AE = AE(:); % Mean for 1 day
% AE = AE/1000; % convert evap to [m]
% 
% % Extracting only peaks of well level
% [WBpk.depth,i] = findpeaks(WB.depth);
% WBpk.date = WB.date(i);
% [WBpk.depth,i] = findpeaks(WBpk.depth);
% WBpk.date = WBpk.date(i);
% 
% % Extracting relevant rainfall data to match well data range
% P = P(r_day>WB.date(1));
% r_day = r_day(r_day>WB.date(1));
% 
% P = P(r_day<=ev_day(end));
% 
% r_day = r_day(r_day<=ev_day(end));
% 
% % Extracting relevant evap
% AE = AE(ev_day>WB.date(1));
% ev_day = ev_day(ev_day>WB.date(1));
% 
% % AE = AE(ev_day<WB_pr_date_corr(end));
% % ev_day = ev_day(ev_day<WB_pr_date_corr(end));
% 
% 
% %% Plotting P and AE
% figure(1); hold on; grid on;
% plot(r_day,P*1000);
% plot(r_day,AE*1000);
% % title('Rainfall and Evapotranspiration')
% legend('Precipitation','Actual Evapotranspiration')
% xlabel('Date')
% ylabel('[mm/day]')
% axis tight
% 
% %% Groundwater Model to generate recharge vector
% params=input_params(Sy,h0);
% [Hg,recharge,qg] = gwm(P,AE,r_day,params);
% figure(3)
% plot(r_day,Hg)
% title('GWL vs Time')
% xlabel('Time [days]')
% ylabel('Head [m]')
% hold on
% figure(4)
% plot(r_day,qg)
% hold on
% plot(r_day,recharge)
% hold on
% plot(r_day,recharge-qg)
% title('Groundwater Drain (qg) vs Time')
% xlabel('Time [days]')
% ylabel('Head [m]')
% legend('qg','recharge','net recharge')
% %gwlplot(r_day,GWL,P,AE,recharge,Qg,WBpk.date,WBpk.depth,params);
% 
% %% Load Pumping Data saved from genpump.m file 
% %(which originally inputted to geninput1.m for SPIDERR model):
% load abs_nn1.mat
% 
% %Allocate Relevant Pumping Data to Variables to use in Model
% stdate = abs.stdate;
% enddate = abs.enddate;
% pumpdate = abs.startdate;
% pumprate = abs.pumprate;
% pumpdur = abs.pumpdur;
% %abs.startdata and abs.enddata, abs.enddate not needed as rate and duration
% %already have been calculated in genpump.m
% 
% % To test a period with pumping turned off:
% % for X = 1:length(pumprate)
% %     if X > length(pumprate) - 30
% %         pumprate(X) = 0;
% %     end
% % end
% 
% %% Plot Observed WB Data Against Regional Model
% B = 12; %height of pump above aquifer base (sitting 1.5 m above well base so model doesn't collapse when h --> 11.5
% figure(3)
% plot(WB.date,WB.depth+B,'k.-');
% hold on
% figure(5)
% plot(WB.date,WB.depth+B,'k.-');
% hold on
% %% Implement Model
% 
% %Pumping data runs 21st July 2017 (00:00:00) - 15th Feb 2018 (12:30:00)
% %Recharge data available 21st July 2017 - 28th Apr 2017
% 
% %Model sets up a while loop, which iterates each time the pump turns on
% %(the recovery following pumping is run within this same iteration)
% %NOTE: Recharge currently updates each time a new day starts - this is inaccurate
% h0 = Hg(1); %set h0 to average regional groundwater level for day 1 (instead of previous h0 value defined as the value for the start of day 1) - avoids initial system perturbation by h0 and GWL difference
% H_r = h0*ones(1, length(rad)); %initialise head for each timestep 
% count = 1; %used to index pumping data, updated on each loop iteration
% time = pumpdate(count); %model starts on the first pump (21st July 2017)
% days = 1; %(day counter to update the daily recharge rate)
% W = recharge(days); %initial recharge rate on day 1
% qg_rate = qg(days);
% pumpingvol = zeros(1, length(pumprate)-1);
% wellhead = zeros(1, length(pumprate)-1);
% 
% %couple the regional and model starting heads at exact time of pumpdate(1)
% H_r = H_r + (W/Sy - qg_rate/Sy)*(datenum(time) - floor(datenum(time)));
% 
% while count <= length(pumpdate)
%     
%     %State the Start Datetime for the Pumping Event
%     starttime = time;
%     
%     %PUMPING EVENT--------------------------------------------------------
%     %Set Pumping Rate
%     Qw = pumprate(count,1); %[m^3/d]
%     
%     %Using Start time and Duration, Define Length of the Pumping Event (in
%     %Serial Date Units for the Solver [days])
%     ode_t = datenum(time);
%     duration = minutes(pumpdur(count,1));
%     
%     %avoid 0 value if event starts at midnight, and add an extra day
%     if ceil(ode_t) - ode_t == 0
%         ode_t = ode_t + 1e-9;
%         days = days + 1;
%         
%         %Change days, W and qg to run in else section of loop
%         W = recharge(days);
%         qg_rate = qg(days) + (h(end,end)-Hg(days))*1e-2;
%     end
%         
%     if duration/1440 > ceil(ode_t) - ode_t %If scenario ensures that W and Qg rates are updated when they change at midnight to match the regional GWL
%         ode_end_t = ceil(ode_t); %addition to avoid 0 value
%         
%         %Run the Groundwater Model for this Defined Length of Time
%         [t,h] = gw_model_uc(H_r,ode_t, ode_end_t,rad,Sy,K,Qw,W,qg_rate,b,days);
%         H_r = h(end,:); %update head at end of pumping for all nodes 'r'
%         
%         %Calculate Groundwater Model Head at the Well for Plotting
%         t_w = t;
%         t_w = datetime(t_w,'ConvertFrom','datenum');
%         hw_t = h(:,1);
%         
%         %Plot Changing Head in the Well
%         figure(5)
%         plot(t_w,hw_t,'.r')
%         
%         %Plot changing head in observation well at the boundary
%         h_end_t = h(:,end);
%         plot(t_w,h_end_t,'.b')
%         title('Well level against time')
%         xlabel('Time [days]')
%         ylabel('Head [m]')
%         hold on
%         
%         %Plot Head vs Distance from the Well at this Timestep
%         if count == 1 || rem(count,20) == 0
%             figure(6)
%             plot(rad,H_r);
%             title('Head values at each hour of pumping')
%             xlabel('Distance [m]')
%             ylabel('Head [m]')
%             xlim([0 Rmax])
%             hold on
%         end
%         
%         %calculate number of days elapsed
%         daychange = 1;
%         
%         %Convert Back to Datetime
%         time = datetime(ode_end_t,'ConvertFrom','datenum');
%         
%         %Update Recharge Rate to that New Day's Value
%         days = days + daychange;
%         W = recharge(days);
%         qg_rate = qg(days) + (h(end,end)-Hg(days))*1e-2;
%         
%         %Run the pumping event for the remainder of its duration with the updated W and qg values
%         ode_end_t_new = datenum(starttime) + duration/1440;
%         
%         %Run the Groundwater Model for this Defined Length of Time
%         [t,h] = gw_model_uc(H_r,ode_end_t,ode_end_t_new,rad,Sy,K,Qw,W,qg_rate,b,days);
%         H_r = h(end,:); %update head at end of pumping for all nodes 'r'
%         
%         %Calculate Groundwater Model Head at the Well for Plotting
%         t_w = t;
%         t_w = datetime(t_w,'ConvertFrom','datenum');
%         hw_t = h(:,1);
%         
%         %Plot Changing Head in the Well
%         figure(5)
%         plot(t_w,hw_t,'.r')
%         hold on
%         %Plot changing head in observation well at the boundary
%         h_end_t = h(:,end);
%         plot(t_w,h_end_t,'.b')
%         title('Well level against time')
%         xlabel('Time [days]')
%         ylabel('Head [m]')
%         hold on
%         
%         %Plot Head vs Distance from the Well at this Timestep
%         if count == 1 || rem(count,20) == 0
%             figure(6)
%             plot(rad,H_r);
%             title('Head values at each hour of pumping')
%             xlabel('Distance [m]')
%             ylabel('Head [m]')
%             xlim([0 Rmax])
%             hold on
%         end
%         
%         %Update Pumping Counter Ready for Next Event
%         count = count + 1;
%         
%         %Convert Back to Datetime
%         time = datetime(ode_end_t_new,'ConvertFrom','datenum');
% 
%         %--------------
%     else
%         ode_end_t = ode_t + duration/1440; %convert to serial date units (days)
%         
%         %Run the Groundwater Model for this Defined Length of Time
%         [t,h] = gw_model_uc(H_r,ode_t, ode_end_t,rad,Sy,K,Qw,W,qg_rate,b,days);
%         H_r = h(end,:); %update head at end of pumping for all nodes 'r'
%         
%         
%         %Calculate Groundwater Model Head at the Well for Plotting
%         t_w = t;
%         t_w = datetime(t_w,'ConvertFrom','datenum');
%         hw_t = h(:,1);
%         
%         %Plot Changing Head in the Well
%         figure(5)
%         plot(t_w,hw_t,'.r')
%         hold on
%         %Plot changing head in observation well at the boundary
%         h_end_t = h(:,end);
%         plot(t_w,h_end_t,'.b')
%         title('Well level against time')
%         xlabel('Time [days]')
%         ylabel('Head [m]')
%         hold on
%         
%         %Plot Head vs Distance from the Well at this Timestep
%         if count == 1 || rem(count,20) == 0
%             figure(6)
%             plot(rad,H_r);
%             title('Head values at each hour of pumping')
%             xlabel('Distance [m]')
%             ylabel('Head [m]')
%             xlim([0 Rmax])
%             hold on
%         end
%         
%         
%         %Convert Back to Datetime
%         time = datetime(ode_end_t,'ConvertFrom','datenum');
%         %Update Pumping Counter Ready for Next Event
%         count = count + 1;
%         
%     end
%     
%     %RECOVERY EVENT--------------------------------------------------------
%     
%     %Command to End Loop and Not Run Recovery if Pumping Data has Finished
%     if count > length(pumpdate)
%         fprintf('Model Complete');
%     else
%         
%         %State the Start Datetime for the Recovery Event
%         starttime = time;
%         
%         %Pumping Rate set to 0 as the Pump is Turned Off
%         Qw = 0;
%         
%         %Using Start time and Duration, Define Length of the Recovery Event (in
%         %Serial Date Units for the Solver [days])
%         ode_t = datenum(time);
%         ode_end_t = datenum(pumpdate(count));  %recovery ends when next pumping datetime starts
%         
%         %avoid 0 value if event starts at midnight, and add an extra day
%         if ceil(ode_t) - ode_t == 0
%             ode_t = ode_t + 1e-9;
%             days = days + 1;
%             W = recharge(days);
%             qg_rate = qg(days) +(h(end,end)-Hg(days))*1e-2;
%             
%         end
%         
%         if ode_end_t > ceil(ode_t) %If scenario ensures that W and Qg rates are updated when they change at midnight to match the regional GWL
%             
%             final_day = floor(ode_end_t);
%             day_change = final_day - floor(ode_t); %calculates number of days elapsed during recovery (usually 1 but may last multiple days)
%             ode_end_t_X = ceil(ode_t+1e-12); % set first run to end at the end of first day
%             
%             for X = 1:day_change %run ode solver with updated values of W and qg for each day of recovery
%                 
%                 %Run the Groundwater Model for this Defined Length of Time
%                 [t,h] = gw_model_uc(H_r,ode_t, ode_end_t_X,rad,Sy,K,Qw,W,qg_rate,b,days);
%                 H_r = h(end,:); %head at end for all r
%                 
%                 %Groundwater Model head at the well for Plotting
%                 t_w = t;
%                 t_w = datetime(t_w,'ConvertFrom','datenum');
%                 hw_t = h(:,1);
%                 
%                 %Update Well Head Plot
%                 figure(5)
%                 plot(t_w,hw_t,'.r')
%                 
%                 %Plot changing head in observation well at the boundary
%                 h_end_t = h(:,end);
%                 plot(t_w,h_end_t,'.b')
%                 
%                 title('Well level against time')
%                 xlabel('Time [days]')
%                 ylabel('Head [m]')
%                 hold on
%                 
%                 %Update Head vs Distance Plot
%                 if count == 2 || rem(count-1,20) == 0
%                     figure(6)
%                     plot(rad,H_r);
%                     title('Head values at each hour of pumping')
%                     xlabel('Distance [m]')
%                     ylabel('Head [m]')
%                     xlim([0 Rmax])
%                 end
%                 
%                 %Update day counter and recharge/qg values for the new day
%                 days = days + 1;
%                 W = recharge(days);
%                 qg_rate = qg(days) +(h(end,end)-Hg(days))*1e-2;
%                 
%                 %update times for next iteration
%                 ode_t = ode_end_t_X;
%                 ode_end_t_X = ode_end_t_X + 1;
%                 
%             end
%             
%             %then finish off the recovery duration to the actual recovery
%             %end
%             
%             %Run the Groundwater Model for this Defined Length of Time
%             [t,h] = gw_model_uc(H_r,ode_t, ode_end_t,rad,Sy,K,Qw,W,qg_rate,b,days);
%             H_r = h(end,:); %head at end for all r
%             
%             %Groundwater Model head at the well for Plotting
%             t_w = t;
%             t_w = datetime(t_w,'ConvertFrom','datenum');
%             hw_t = h(:,1);
%             
%             %Update Well Head Plot
%             figure(5)
%             plot(t_w,hw_t,'.r')
%             
%             %Plot changing head in observation well at the boundary
%             h_end_t = h(:,end);
%             plot(t_w,h_end_t,'.b')
%             
%             title('Well level against time')
%             xlabel('Time [days]')
%             ylabel('Head [m]')
%             hold on
%             
%             %Update Head vs Distance Plot
%             if count == 2 || rem(count-1,20) == 0
%                 figure(6)
%                 plot(rad,H_r);
%                 title('Head values at each hour of pumping')
%                 xlabel('Distance [m]')
%                 ylabel('Head [m]')
%                 xlim([0 Rmax])
%             end
%             
%             %Update Time to the Start of the Next Pumping Event for the Next Loop
%             %Iteration
%             time = pumpdate(count);
%              
%         else
%             
%             %Run the Groundwater Model for this Defined Length of Time
%             [t,h] = gw_model_uc(H_r,ode_t, ode_end_t,rad,Sy,K,Qw,W,qg_rate,b,days);
%             H_r = h(end,:); %head at end for all r
%             
%             %Groundwater Model head at the well for Plotting
%             t_w = t;
%             t_w = datetime(t_w,'ConvertFrom','datenum');
%             hw_t = h(:,1);
%             
%             %Update Well Head Plot
%             figure(5)
%             plot(t_w,hw_t,'.r')
%             
%             %Plot changing head in observation well at the boundary
%             h_end_t = h(:,end);
%             plot(t_w,h_end_t,'.b')
%             
%             title('Well level against time')
%             xlabel('Time [days]')
%             ylabel('Head [m]')
%             hold on
%             
%             %Update Head vs Distance Plot
%             if count == 2 || rem(count-1,20) == 0
%                 figure(6)
%                 plot(rad,H_r);
%                 title('Head values at each hour of pumping')
%                 xlabel('Distance [m]')
%                 ylabel('Head [m]')
%                 xlim([0 Rmax])
%             end
%             
%             %Update Time to the Start of the Next Pumping Event for the Next Loop
%             %Iteration
%             time = pumpdate(count);
%             
%         end
%         
%         
%     end
%     
%     
%     %Plot of Head vs Upcoming Pumped Volume (Rate * Duration)
%     if count <= length(pumprate)
%     pumpingvol(count-1) = datenum(pumpdur(count))*pumprate(count);
%     wellhead(count-1) = hw_t(1)
%     end
% end
% 
% figure(7)
% plot(wellhead, pumpingvol, 'rx');
% title('Head vs Pumping Volume the Following Event')
% xlabel('Head [m]')
% ylabel('Pumping Volume [m3]')
% hold on
% %line of best fit
% p = polyfit(wellhead,pumpingvol,1);
% yplot = p(1)*wellhead + p(2);
% plot(wellhead,yplot)
% %Plot Rsquared (TBD when method is improved)
% 
% %Plot Regional Model
% figure(5)
% plot(r_day,Hg,'--k')
% title('Well Model vs Regional Model')
% xlabel('Time [days]')
% ylabel('Head [m]')
% ylim([11.5 15])
% xlim(datetime(2017,[7 7],[21 30]))
% hold on
% % figure(5)
% % plot(t_w,hw_t,'.b')
% % title('Well level against time')
% % xlabel('Time [days]')
% % ylabel('Head [m]')
% %
% % figure(6)
% % plot(rad,H_r);
% % title('Head values at each hour of pumping')
% % xlabel('Distance [m]')
% % ylabel('Head [m]')
% % xlim([0 50])
% 
% % 
% 
% 
% %% FUNCTIONS - ODE15s solution of groundwater model for annulus head with time
% 
% function [t,h] = gw_model_uc(h0,tstart,tend,rad,S,T,Qw,W,qg_rate,b,days)
% %Qw = 0; %To test without pumping perturbation
% %qg_rate = 0; W = 0; % To test without any change in GWL (well head remains flat after initial perturbation. Perturbation can be resolved by passing Hg(1) in to this function to get a flat h0 for day 1)
% 
% % if h0(1) <= 11.75
% %     Qw = 0;
% % end
% options = odeset('RelTol',1e-6,'AbsTol',1e-9, 'Events', @negHeadEvent);
% [t,h] = ode15s(@model_uc,[tstart tend],h0,options,rad,S,T,Qw,W,qg_rate,b,days);
% 
% %run ode solver to the end of the pumping/recovery event
% while t(end) < tend
%     h0(1) = b; %corrects erroneous negative head to minimum water level
%     Qw = 0; %turns off pumping for remainder of event
%     [t,h] = ode15s(@model_uc,[t(end) tend],h0,options,rad,S,T,Qw,W,qg_rate,b,days);
% end
% end
% %% Groundwater unconfined model function
% 
% function dhdt = model_uc(~,h,rad,Sy,K,Qw,W,qg_rate,b,days)
% %Define annulus boundary distances from well
% r12 = rhalf(rad);
% %Number of radial nodes
% nr = length(rad);
% %Initialise flow rates across each annulus' boundary and node head changes
% Q = zeros(1,nr);
% dhdt = zeros(nr,1);
% 
% 
% %avoid pumping below the well base
% if h(1) <= 11 %turn pumping off and set negative values to infinitessimal head if a node falls below 0
%     Qw = 0;
%     
% end
% 
% 
% %Equation for volume flowing in to the well
% Q(1) = 2*pi*r12(1)*K*((h(1)-b)+pi*rad(1)^2)*(h(2)-h(1))/(rad(2)-rad(1)); %b factors non-fully-penetrating nature of well %MODIFIED FROM MODELLING REPORT
% 
% %Head Change in well: Assuming r(1) = well radius (rw) and set S = 1
% dhdt(1) = (Q(1) - Qw)/(pi*rad(1)^2); %assuming well is covered from direct recharge
% 
% 
% %Calculate head change for all of the annuli
% for i = 2:nr
%     
%     if i == nr
%         Q(i) = 0; %no flow boundary
% %         if Q(i-1) < 0
% %             Q(i-1) = 0
% %         end
%          dhdt(i) = (Q(i) - Q(i-1))/(Sy*pi*(rad(i)^2-r12(i-1)^2)) + (W-qg_rate)/Sy;
% 
%     else
%         Q(i) = 2*pi*r12(i)*K*((h(i)+h(i+1))/2)*(h(i+1)-h(i))/(rad(i+1)-rad(i));
%         dhdt(i) = (Q(i) - Q(i-1))/(Sy*pi*(r12(i)^2-r12(i-1)^2)) + (W-qg_rate)/Sy;
%     end
%         
% end
% end
% %% Half distances
% 
% function r12 = rhalf(rad)
% nr = length(rad);
% r12 = zeros(1,nr);
% r12(1) = rad(1);
% for i = 2:nr-1
%     r12(i) = (rad(i) + rad(i+1))/2; 
% end
% end
% 
% 
% %% Parameters for regional GWM and recharge
% 
% function params=input_params(Sy,h0)
% % Refer to gwm.m for parameter details
% % All Units in [m] unless stated otherwise
% params.Sy = Sy; % [no units]
% params.k = 8.60085746804029e-05; % [1/day] # Changed to final value from Rae's report on page 26.
% params.SM_max = 0.00457372365550534;
% params.Hg_min = 10; % Outflow base about aquifer base 
% params.SM_i = 0;
% params.Hg_i = h0;
% params.k_wei = 23.9138427442419; % controls the density of function around peak
% params.lambda = 15.4149196700565; % controls the location of the peak
% end
% 
% %% ODE Event Function to Prevent Negative Head
% function [value,isterminal,direction] = negHeadEvent(t,h,rad,S,T,Qw,W,qg_rate,b,days)
% % dDSQdt is the derivative of the equation for current distance. Local
% % minimum/maximum occurs when this value is zero.
% value = h(1) - b;
% isterminal = 1;         % stop at local minimum
% direction  = -1;         % [local minimum, local maximum]
% end





