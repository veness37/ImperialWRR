clear; clc; 
close all;
% To generate the parameters required to match the actual abstraction
load ('C:\Users\wv13\Desktop\Project Code\Final_Model_Rae_Veness\Final_Model\Well Level Extraction\NPD_corr.mat','WB');

%% Limit Data
stdate = datetime(2017,07,21,00,00,00); 
enddate = datetime(2018,02,15,12,30,00);
% enddate = stdate + days(21);
% stdate = datetime(2017,12,31,00,00,00); 
% enddate = datetime(2018,01,4,12,00,00);
i1 = find(WB.date == stdate);
i2 = find(WB.date == enddate);
limWB.data = WB.depth(i1:i2);
limWB.date = WB.date(i1:i2);
%% Find abstraction starts
[start.data,start.i] = findpeaks(limWB.data,'MinPeakProminence',0.05);
start.date = limWB.date(start.i);

%By flipping in to negative you get the troughs
[stop.data,stop.i] = findpeaks(-limWB.data,'MinPeakProminence',0.05);
stop.data = -stop.data; %return to positive value
stop.date = limWB.date(stop.i);
% 
start.date(end) = [];
start.data(end) = [];
start.i(end) = [];
% stop.date(1) = [];
% stop.data(1) = [];
% 
start.date(269) = [];
start.data(269) = [];
start.i(269) = [];

start.date(321) = [];
start.data(321) = [];
start.i(321) = [];

%% Plot abstraction starts
figure; hold on; grid on;
plot(limWB.date,limWB.data)
plot(start.date,start.data,'o')
plot(stop.date,stop.data,'o')
% plot(start2.date,start2.data,'.k')
% ctdate = start.date(203);
% xlim([ctdate - days(3), ctdate + days(3)])
legend('Measured','Start Abstraction','End Abstraction')
xlabel('Date')
ylabel('Water elevation [m]')
title('Abstraction times')

%% Identify errors
for k1 = 1:length(start.data)-1
    if start.date(k1+1) < stop.date(k1)
        start.date(k1+1)
        error('Multiple start points, k1 = %g\n', k1)
    end
end

for k1 = 1:length(stop.data)-1
    if stop.date(k1) < start.date(k1)
        stop.date(k1)
        error('Multiple stop points k1 = %g\n', k1)
    end
end
%% Find Abstraction duration 
dt = stop.date - start.date;
dh = nan(length(dt),1);
for k1 = 1:length(start.i) %loop through all indices for start peaks
    endp = start.i(k1); % Index of end point of linearisation
    std = start.date(k1); % Start date
    
    stp = endp - 20; % Index of start point of linearisation
    if k1 > 1 && stp < stop.i(k1-1) % If start point is earlier than previous abstraction stop point
        stp = stop.i(k1-1); % Set previous abstration stop point as start point
    end
    
    % calculating %%assuming this is extrapolation??
    ye = limWB.data(stp:endp);
    xe = datenum(limWB.date(stp:endp)-years(2017));
    p = polyfit(xe,ye,1);
    
    xp = xe;
    xp(end+1) = datenum(limWB.date(endp)-years(2017)+dt(k1));
    yp = p(1)*xp + p(2); %plot extrapolation
    xp = datetime(xp,'convertfrom','datenum') + years(2017);
    
    dh(k1) = stop.data(k1) - yp(end); %this calculates head change at each pumping stop point
    
    % Plotting
    plot(xp,yp,'r-','Linewidth',1.5);
end
legend('Measured','Start Abstraction','End Abstraction','Extrapolation')
% dh2 = stop.data - start.data;
absvol = -dh*pi*1^2; % [m3] %assuming 2m well radius? %VOLUME
absrate = absvol./datenum(dt); % [m3/day] %PUMPING RATE FOR EVENT
% 
ctdate = datetime(2017,11,06,00,00,00);
figure;
subplot(3,1,1);
bar(start.date,dt) %dt DURATION OF EACH PUMPING EVENT
ylabel('Duration')
title('Abstraction Duration')
% xlim([ctdate-days(3), ctdate + days(3)])

subplot(3,1,2);
bar(start.date,dh)
ylabel('[m]')
title('Change in head')
% xlim([ctdate-days(3), ctdate + days(3)])

subplot(3,1,3)
bar(start.date,absrate)
ylabel('[m3/day]')
title('Abstraction Rate')
% xlim([ctdate-days(3), ctdate + days(3)])
%% Output data
check = input('Save data? Check filename ');
% check = 0;
if check == 1
    abs.startdata = start.data;
    abs.startdate = start.date;
    abs.enddata = stop.data;
    abs.enddate_pump = stop.date;
    abs.pumprate = absrate;
    abs.pumpdur = dt;
    abs.stdate = stdate;
    abs.enddate = enddate;
    save abs_nn1.mat abs
%     save('D:\FYP(Com)\SPIDERR\Post Processing\abs_n1.mat','abs')
end
