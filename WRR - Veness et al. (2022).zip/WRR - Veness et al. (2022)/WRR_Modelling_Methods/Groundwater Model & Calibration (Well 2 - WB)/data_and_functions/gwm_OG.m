function [Hg,r,qg] = gwm_OG(P,EA,r_day,params)
% My groundwater model
% Edited from rain_trend.mat 
% Changes:
    % Additional soil moisture bucket
    % Free outflow reservoir for drain
% 
% Inputs:
    % P [m] - rainfall
    % EA [m] - evapotranspiration
    % r_day - date (both rainfall and evapotranspiration should have the same
        % date
    % Sy [no units] - specific yield
    % k [1/day] - time constant affecting rate of groundwater drain
    % SM_max [m] - maximum level for soil moisture
    % Hg_min [m] - minimum level for GWL
    % SM_i [m] - initial level for soil moisture
    % Hg_i [m] - initial level for GWL
    % k_wei - parameter for weibull function, controls the density of
        % function around peak
    % lambda - parameter for weibull function, controls the location of the
        % peak
% 
% Components
    % SM - soil moisture
    % Hg - groundwater level
    % SD - soil drainage
% 
% Output
    % Hg [m] - GWL 
    % R [m] - recharge
    % qg [m] - net drain of groundwater
%% Assigning Parameters
Sy = params.Sy; % Specific yield
K = params.K; % [m/day] %K is hydraulic conductivity here instead of time constant tau!
SM_max = params.SM_max;
Hg_min = params.Hg_min; % 
SM_i = params.SM_i;
Hg_i = params.Hg_i;
k_wei = params.k_wei;
lambda = params.lambda;

x_width = 500; %enter manually here
y_length = 500; 
%% Checks 
if min(size(P))~=1
    error('Rainfall needs to be a vector')
end

if min(size(EA))~=1
    error('Evapotranspiration needs to be a vector')
end

if min(size(r_day))~=1
    error('Date needs to be a vector')
end

if length(P) ~= length(EA)
    error('Rainfall and Evapotranspiration needs to have the same length')
end

if length(P) ~= length(r_day)
    error('Date vector not the same length as rainfall')
end
%% Model
% Preallocaton
% Index are +1 due to initial value
Hg = NaN(length(P)+1,1); 
SM = Hg;
SD = Hg; 
Qg = Hg;
% Initial values
SM(1) = SM_i;
Hg(1) = Hg_i; 
SD(1) = 0;
% Model
for k1 = 1:length(r_day)
    %% 1st bucket
    % Represents the soil moisture
    % Assumes that if soil moisture exceeds a fixed value, the excess
    % becomes recharge
    SM(k1+1) = SM(k1) + P(k1) - EA(k1);
    if SM(k1+1) < 0
        SM(k1+1) = 0;
    end
    
    % Overflow becomes recharge
    if SM(k1+1) > SM_max
        SD(k1+1)= SM(k1+1) - SM_max;
        SM(k1+1) = SM_max;
    else
        SD(k1+1) = 0;
    end
end
%R = UNSAT? Is this a weibull function not listed in the comments? Yes see the file  
r = unsat(lambda,k_wei,length(r_day),SD);
r = r';
% figure(2)
% plot(r_day,SM(2:end),'b',r_day,r,'r')

for k1 = 1:length(r_day)
    %% Drain
        % Drain is based on the GWL of the previous time step
        % Assume a free outflow reservoir
        if Hg(k1) - Hg_min > 0
            h = Hg(k1) - Hg_min;
        else
            h = 0;
        end
        Qg(k1+1) = K*h*y_length*(h/(0.5*x_width)); % GW outflow TOTAL [m^3/d]
            % For a free outflow reservoir discharge is directly
            % proportional to sqrt(h)
            % A is a constant that dictates outflow

            %%%%%%%k is usually a time-constant (1/day) but is now
            %%%%%%%hydraulic conductivity K.
    %% 2nd Bucket
    Hg(k1+1) = Hg(k1) + r(k1)/Sy - Qg(k1+1)/(Sy*x_width*y_length); % Bucket index is +1 due to initial bucket level

end

% Removing Initial Value
Hg = Hg(1:end-1); 
% recharge = recharge(1:end); should be written as R. 1:end as it did not
% have initial value
Qg = Qg(2:end); 
qg = Qg/(x_width*y_length);




