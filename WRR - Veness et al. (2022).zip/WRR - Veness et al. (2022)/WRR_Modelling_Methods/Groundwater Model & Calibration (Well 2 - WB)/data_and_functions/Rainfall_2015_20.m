%Rainfall 2015-2020
% Extracts rainfall data for the desired area
clear; clc; close all;
%% File Setup
% folder = 'D:\FYP(Com)\Final Model\Satellite Data\Rainfall';
folder = 'C:\Users\wv13\Desktop\Project Code\Will_Model\Satellite Extraction Veness\TAMSAT\2015_20';
d=dir(folder)
s = 0; %for saving

%% Area Required
% For plotting
y = 9.685352; % lat
x = 43.730027; % lon
dx = 20; % Distance in x direction (in one direction (+/-))
dy = 20; % Distance in y direction (in one direction (+/-))
[rx,ry] = ll_solve(y,x,dx,dy);

%% Loop
preal = datenum(datetime(2019, 11, 04)) - datenum(datetime(2015,01,01));
count = 0; 
day_plot = NaT(preal,1);

numel(d)

for k = 3:numel(d)
%     close all; 
    clearvars -except x y r* s d f d2 f2 k k2 folder old_* count i* local* day_plot preal
%     fprintf('File location is '); fprintf(d(k).name); fprintf('\n'); 
    f2 = fullfile(folder, d(k).name);
    d2 = dir(f2);
    for k2 = 3:numel(d2)
        count = count+1;
        % Reading Data
        filename = fullfile(f2, d2(k2).name);
%         ncdisp(filename);
        lon = ncread(filename,'lon');
        lat = ncread(filename,'lat');
        ppt = ncread(filename,'rfe');
        
        % Saving the date of the file
        day_att = ncreadatt(filename,'time','units');
        day_att = strsplit(day_att,' '); % Splitting to remove the unwanted bits
        day_plot(count) = datetime(day_att{3}); % 
        
        % Extracting local index
        if count == 1
            [~,i1] = min(abs(lon-(x-rx)));
            [~,i2] = min(abs(lon-(x+rx)));
            [~,i3] = min(abs(lat-(y+ry)));
            [~,i4] = min(abs(lat-(y-ry)));
            local_lon = lon(i1:i2);
            local_lat = lat(i3:i4);
            local_ppt = zeros(i4-i3+1,i2-i1+1,preal); % Preallocation
        end
               
        % Extracting Local Data     
        local_ppt(:,:,count) = ppt(i1:i2,i3:i4)';
    end
end
beep

%% Drawnow of rainfall
figure;
a1 = round(min(local_ppt(:))); a2 = round(max(local_ppt(:)));
day_plot = day_plot(~isnat(day_plot)); % Removing NaT
for k = 1:size(local_ppt,3)
    h = surf(local_lon,local_lat,local_ppt(:,:,k));
    set(h,'LineStyle','none')
    colorbar;
    caxis([a1,a2]); zlim([a1,a2]); 
    xlim([min(local_lon(:)), max(local_lon(:))]);
    ylim([min(local_lat(:)), max(local_lat(:))]);
    title(datestr(day_plot(k)))
    drawnow;
    pause(0.1);
end
%% Saving
% check = input('Overwrite saved data? Do check save name\n');
% if check == ~1
%     return
% end

r_day = day_plot;
r = local_ppt;
r_lon = local_lon;
r_lat = local_lat;

save('rainfall_2015_20.mat','r_lon','r_lat','r','r_day');
%save('rainfall_2016.mat','r_lon','r_lat','r','r_day','-append');


% %% Plotting Rainfall
% 
% figure; hold on;
% subplot(2,1,1)
% bar(r_2_day,r_2);
% ylabel('[mm]')
% axis tight
% title('Rainfall')
% subplot(2,1,2)
% bar(ev_2_day,ev_2);
% ylabel('[mm]')
% axis tight
% title('Evapotranspiration')
