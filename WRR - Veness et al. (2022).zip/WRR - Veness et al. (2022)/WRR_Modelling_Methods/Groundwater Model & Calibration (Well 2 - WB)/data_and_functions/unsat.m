function R=unsat(lambda,k,Nts,SD)
% calculate weibull weights
% Corresponds to eqn (7)
% Inputs
% SD - soil drainage, aka "overflow" without delay applied
% Nts - No. time steps, corresponds to the length of date vector
% k and lambda - parameters controlling Weibull distribution 

R=zeros(1,Nts);
[Nw,w]=weibull(lambda,k); 
    % Nw - the number of days weibull distribute the timestep over
    % w - alpha * sum("f") in eqn (6)
for i = 1:Nts % Considering rainfall from each rainfall time step 
   for j=1:Nw % Sum over the time step weibull distributes the "unit rainfall" over
       if (i+j-1) <= Nts % Only calculate recharge for number of days that exist?
           R(i+j-1)=R(i+j-1)+SD(i)*w(j);
       end
   end
end
end