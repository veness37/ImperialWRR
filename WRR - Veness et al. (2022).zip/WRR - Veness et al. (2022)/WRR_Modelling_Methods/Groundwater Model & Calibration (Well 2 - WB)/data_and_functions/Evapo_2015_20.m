%Evapo_2015_20.m 
% Extracts evaporation data for the desired area
clear all; clc; close all;
%% File Setup
% folder = 'D:\FYP(Com)\Final Model\Satellite Data\Evapotranspiration\2017';
folder = 'C:\Users\wv13\Desktop\Project Code\Will_Model\Satellite Extraction Veness\Princeton\Evap';
d=dir(folder); 
s = 0; %for saving

%% Area Required
% For plotting
y = 9.685352; % lat
x = 43.730027; % lon
dx = 20; % Distance in x direction (in one direction (+/-))
dy = 20; % Distance in y direction (in one direction (+/-))
[rx,ry] = ll_solve(y,x,dx,dy);

%% Loop

count = 0;
numel(d)
preal = datenum(datetime(2019, 11, 04)) - datenum(datetime(2015,01,01)); %number of days
day_plot = NaT(preal,1);

for k = 3:numel(d)
    f2 = fullfile(folder, d(k).name);
    d2 = dir(f2);
    
    for k2 = 3:numel(d2)
        count = count+1;
        % Reading Data
        filename = fullfile(f2, d2(k2).name);
        lon = ncread(filename,'lon');
        lat = ncread(filename,'lat');
        if count ==1
            evap = NaN(length(lon),length(lat),preal);
        end
        ncread(filename,'evap');
        evap(:,:,count) = ncread(filename,'evap'); % [mm]
        
        % Saving the date of the file
        day_att = ncreadatt(filename,'t','units');
        day_att = strsplit(day_att,' '); % Splitting to remove the unwanted bits
        day_plot(count) = datetime(day_att{3}); %
        
        
    end
end
%% Plotting
figure;
a1 = min(evap(:)); a2 = max(evap(:));
for k = 1:size(evap,3)
    h = surf(lat,lon,evap(:,:,k));
    set(h,'LineStyle','none')
    colorbar;
    caxis([a1,a2]); zlim([a1,a2]); 
    ylim([min(lon(:)), max(lon(:))]);
    xlim([min(lat(:)), max(lat(:))]);
    title(datestr(day_plot(k)))
    drawnow;
    pause(0.1);
end
%% Saving
check = input('Save?\n');
if check ~= 1
    return
end

ev = evap;
ev_day = day_plot;
ev_lat = lat;
ev_lon = lon;
save('rainfall_2015_20.mat','ev','ev_day','-append');
save('rainfall_2015_20.mat','ev_lon','ev_lat','-append');

