function [Nw,w]=weibull(lambda,k)
% calculates weights for weibull distribution
% Implements eqn (6) and part of (7)

% Inputs:
% k and lambda - parameters controlling Weibull distribution 

% Outputs:
% Nw - the number of days weibull distribute the timestep over (decided in
% this code)
% w - alpha*f in eqn (7)

%% Calculating Weibull Distribution
Nw=5; % Dictates the number of days where the probability distribution is significant enough to be considered for calculation
% Ideally you want a check function that varies Nw until it is 
% sufficient (but what would be the criteria?)
for k1 = 1:15
    x=1:Nw;
    f = (k/lambda).*(x/lambda).^(k-1).*exp(-(x/lambda).^k);
    
    % Checks for Nw
    c_1 = f(end)/max(f)<= 1e-3; % Check that peak has passed and is sufficiently small compared to peak
    if c_1 ~=1
        Nw = Nw + 5;
    else
        break
    end
    
%     figure;
%     plot(f);
    
    if k1 == 10
        fprintf('Nw not sufficiently large in weibull.m, k = %g, lambda = %g\n', k, lambda)
    end
end

% Calculating w
alpha = 1/sum(f); % Scaling to ensure that area of w is = 1 (to represent cdf)
w = alpha*f;

% %% Plotting distribution 
% figure
% plot(x,f,'-xb')
% axis([0 Nw 0 max(f)]);
% xlabel('x')
% ylabel('f')
% title('Weibull plot')
% 
% %% Plot Bar
% figure
% hold on;
% bar(0.5,1);
% bar(x,f)
% 
% % axis([0 Nw 0 max(f)])
% legend('Soil Drainage','Recharge')
% xlabel('x [days]')
% ylabel('Proportion')
end