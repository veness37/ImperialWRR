%% ODE Event Function to Prevent Negative Head
function [value,isterminal,direction] = negHeadEvent(t,h,rad,S,T,Qw,W,qg_rate,b,days)
% dDSQdt is the derivative of the equation for current distance. Local
% minimum/maximum occurs when this value is zero.
value = h(1) - 11.5;
isterminal = 1;         % stop at local minimum
direction  = -1;         % [local minimum, local maximum]
end